<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 $config['config'] = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'ssl://smtp.googlemail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'info@assetswatch.com', 
                    'smtp_pass' => 'Jireh@321',//my valid email password
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1',
                    'wordwrap' => TRUE
					
                  );
?>

