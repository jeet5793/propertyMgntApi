<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['partnerkey']		= 'C7ACD5D2-9C32-4F17-A04E-FBAC9BEEDD2A';
$config['partnerid']		= 'asset_93379';
$config['transactiontype']			= 'auth'; 


