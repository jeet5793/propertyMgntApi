<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['twitter_consumer_token']		= 'gGq0AHDW8RSBQnjdjueTpotDT';
$config['twitter_consumer_secret']		= 'GvVbqnt2g70zd5hJSnOPLZMi42G9JS3tbnEQ1gXhGhSQMk87hZ';
$config['twitter_access_token']			= '1003584230222282752-uBafJ0SABtRMc8pS0Rmdpk7xEV8v7Y'; // Optional
$config['twitter_access_secret']		= 'iOs9NYFZ4Vwu0krDLiLOv6BiMeBJULvtJ9mQQehHrktCV'; // Optional
/* End of file twitter.php */
/* Location: ./application/config/twitter.php */