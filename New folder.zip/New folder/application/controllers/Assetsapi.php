<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
//header("Access-Control-Allow-Headers: *");

require APPPATH .'third_party/SingularApi-php/autoload.php';
// require APPPATH .'third_party/dompdf/dompdf_config.inc.php';
require_once APPPATH .'third_party/dompdf/autoload.inc.php';
require_once APPPATH .'third_party/tcpdf/tcpdf.php';

// uncomment below to enable debugging
 //SingularApi\Configuration::getDefaultConfiguration()->setDebug(TRUE);

require APPPATH."libraries/lib/autoload.php";
use Abraham\TwitterOAuth\TwitterOAuth;

class Assetsapi extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    public function __construct() {
        parent::__construct();
         $this->load->library(array('session','facebook','MyCustomPDFWithWatermark','google','email'));//'google',
        //$this->load->library(array('session','facebook'));
        $this->load->database();
        $this->load->model('assetsapi_model');
        $this->load->helper(array('url','file'));
		$this->load->helper('download');
        $this->load->library('form_validation');
		$this->load->config('linkedin');
		 $this->load->config('twitter');
		  $this->load->config('singular_payment');
		  //include_once APPPATH."libraries/twitter-oauth-php/twitteroauth.php";

    }
	 
	public function index()
	{
		//google login url
         $data['googleloginURL'] = $this->google->loginURL();
         //linkedin
		 $data['linkedinURL'] = $this->config->item('linkedin_redirect_url').'?oauth_init=1';
		 $data['fblogoutURL'] = $this->facebook->logout_url();
          $data['fbauthURL'] =  $this->facebook->login_url();
		   $data['twitterUrl'] = base_url().'assetsapi/twitter';
        //load google login view
        $this->load->view('welcome_message',$data);
	}

//===========================================================LOGIN===============================================================================================	
    public function login()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$email = $request['email'];
		$hashPassword = $this->assetsapi_model->encrypt_decrypt('encrypt',$request['password']);
		$password = $hashPassword;
		$assets_type = $request['assets_type'];
		$agent_type = array_key_exists('agent_type',$request)?$request['agent_type']:'';
		$userData = array(
			'email' => $email,
			'password' => $password,
			'assets_type' =>$assets_type,
			'agent_type'=>$agent_type
		);
		
		
        $result = $this->assetsapi_model->login($userData);
        $retres=array();
        if($result)
        { 
			if($result['status']=='0'){
				$retres['Success']=0;
				$retres['msg']='Your account is not activated.';
				$retres['userdata']=$result;					
			}else{
				$retres['Success']=1;
				if($result['plan_id']==null && $result['agentType']!='Service Provider')
				{
					$result2 = $this->assetsapi_model->plan_by_assetstype($result['assetsTypeId']);
					if($result2)
					{
						$retres['userdata']=$result;
						$retres['plan']= $result2;
					}else
					{  $retres['userdata']=$result;
						$retres['msg']='Login Successfully. No plan available.!!!';
					}
				}else{
					
					$retres['msg']='Login Successfully';	
					$retres['userdata']=$result;	
				}
			}
            
			
        }
        else
        {
			$rslt = $this->assetsapi_model->another_type_login($userData);
			if($rslt)
			{	
				$retres['Success']=2;
				// $assetsType = $this->assetsapi_model->getAssetsType($assets_type);
				// $retres['msg']='Do you want to continue as '.$assetsType.'?';
				// $retres['userdata']=$rslt;	
				// $retres['assetsType']=strtolower($assetsType);
				
				$query1 = $this->db->get_where('registration_tb',array('email'=>$request['email'],'password'=>$password,'status'=>'1'));
				$rslt1 = $query1->result_array();
				// print_r($rslt1);
				foreach($rslt1 as $val)
				{
					// $type[] = $val['assets_type'];
					$type[] = $this->assetsapi_model->getAssetsType($val['assets_type']);
					// $assets_id[] = $val['assets_id'];
					// $session_id[] = $val['session_id'];
					
				}
				 if(count($type)>1){
					 // foreach($type as $tval){
						 
						// $assetsT[] = $tval." and "; 
					 // }
					 $separated = implode(" and ", $type);
					$assetsType  = $separated;
				}else{
					$assetsType = $type[0];
				}
				$retres['msg']='You have already registered as a '.$assetsType;
				$retres['userdata']=$rslt;	
				$retres['assetsType']=$type;
				// $retres['assets_id']=$assets_id;
				// $retres['session_id']=$session_id;
				// $registerData = $this->assetsapi_model->register($userData);
				// if($registerData){
					// if($result['agentType']!='Service Provider')
					// {
						// $result2 = $this->assetsapi_model->plan_by_assetstype($request['assets_type']);
						// if($result2)
						// {
							// $retres['plan']= $result2;
						// }else
						// {
							// $retres['msg']='Registered Successfully. No plan available.!!!';
						// }
					// }else{
						// $retres['msg']='Registered Successfully';
					// }
				// }
			}else{
					$retres['Success']=0;
					$retres['msg']='Invalid Email or Password';
				}
            
				
        }
		
        $retres=json_encode($retres);
        echo $retres;
    }


//===============================================================Register Start====================================================================================		
    public function register()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		
		$email = $request['email'];
		$assets_type = $request['assets_type'];
		if($assets_type=='2'){
			$agentType = $request['agent_type'];
			$sqlcont="SELECT * FROM registration_tb WHERE (email = '$email' AND assets_type = '$assets_type' AND agent_type = '$agentType')";
			
		}else{
			$sqlcont="SELECT * FROM registration_tb WHERE (email = '$email' AND assets_type = '$assets_type')";
		}
		
		$query =$this->db->query($sqlcont);
		$result=$query->result_array();
		if(count($result)==0){
			if($request['owner_type']==2)
			{
				$company_name = $request['company_name'] ;
				$website_url =  $request['website_url'] ;
			}else
			{
				$company_name = '';
				$website_url =  '';
			}
				
			if($request['assets_type']==2)
			{
				$agent_type = isset($request['agent_type']) ? $request['agent_type'] : '';
				
			}else
			{
				$agent_type = '';
				
			}
			
			$randNumber = mt_rand(100000, 999999);
				$hashPassword = $this->assetsapi_model->encrypt_decrypt('encrypt',$request['password']);
			$userData = array(
				'owner_type' => $request['owner_type'],
				'first_name' => $request['first_name'],
				'last_name' => $request['last_name'],
				'email' => $request['email'],
				'password' => $hashPassword,
				'city' => $request['city'],
				'state' => $request['state'],
				'country' => $request['country'],
				'zip_code' => $request['zip_code'],
				'mobile_no' => $request['mobile_no'],
				'landline_no' => $request['landline_no'],
				'assets_type' => $request['assets_type'],
				'company_name' => $company_name,
				'website_url' => $website_url,
				'agent_type' =>$agent_type,
				'account_id' =>$randNumber,
				'status' =>0
			);
			$result = $this->assetsapi_model->register($userData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']='Registered Successfully';
				 $retres['user']= $result;
				
				$assets_id = $result['assets_id'];
				$result1 = $this->assetsapi_model->profile($assets_id);
				
				
				$assets_type = $result1['assets_type'];
				
				$fullName = $result1['first_name']." ".$result1['last_name'];
				$to_email = $result1['email'];
				
				
				if($result['agentType']!='Service Provider')
				{
					$result2 = $this->assetsapi_model->plan_by_assetstype($request['assets_type']);
					if($result2)
					{
						$retres['plan']= $result2;
					}else
					{
						$retres['msg']='Registered Successfully. No plan available.!!!';
						//========================Mail=================================================
						$to_email = $email;
						$from_email = "info@assetswatch.com";
						$RegFilename = 'registration_template.txt';
						$RegTemplate = read_file('assets/email_template/'.$RegFilename);
						$RegSubject = "Registration";
						
						$reacturl = $this->config->item('reacturl');
						$url = "<br/><a href='".$reacturl."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Login</a>";

						$RegTokensArr = array(
						'USER_NAME' => $fullName,
						 'USER_EMAIL'=> $to_email,
						 'URL'=> trim($url)
						);
						$RegMail = $this->send_mail($from_email,$to_email,$RegSubject,$RegTokensArr,$RegTemplate);
						if($RegMail){
							$update = $this->db->update('registration_tb',array('status'=>1),array('assets_id'=>$assets_id));
						}
				// ========================Mail======================================================================
					}
				}else{
					$retres['msg']='Registered Successfully. No plan available.!!!';
						//========================Mail=================================================
						$to_email = $email;
						$from_email = "info@assetswatch.com";
						$RegFilename = 'registration_template.txt';
						$RegTemplate = read_file('assets/email_template/'.$RegFilename);
						$RegSubject = "Registration";
						
						$reacturl = $this->config->item('reacturl');
						$url = "<br/><a href='".$reacturl."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Login</a>";

						$RegTokensArr = array(
						'USER_NAME' => $fullName,
						 'USER_EMAIL'=> $to_email,
						 'URL'=> trim($url)
						);
						$RegMail = $this->send_mail($from_email,$to_email,$RegSubject,$RegTokensArr,$RegTemplate);
						if($RegMail){
							$update = $this->db->update('registration_tb',array('status'=>1),array('assets_id'=>$assets_id));
						}
				}
				
			}
			else
			{
				$retres['success']=0;            
			}
		}else{
			$retres['success']=0;
			$retres['msg']='Email Already Exist, Please Try Again !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
//===============================================================Register End====================================================================================		
//=================================================================================================================================================================	


//=================================================================== Testimonial Start==============================================================================
    public function testimonial()
    {
		$result = $this->assetsapi_model->testimonial();
		if($result){
			$retres['success']=1;
			$retres['testimonial']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No testimonial found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
//=================================================================== Testimonial End==============================================================================
//=================================================================================================================================================================	


//==============================================================Blog Start===================================================================================	
    public function blog()
    {
		//$filename = 'blog.txt';
		//$result = read_file('textfiles/'.$filename);
		$result = $this->assetsapi_model->blog();
		if($result){
			$retres['success']=1;
			$retres['blog']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No blog found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function blog_details($id)
    {
		$result = $this->assetsapi_model->blog_details($id);
		if($result){
			$retres['success']=1;
			$retres['blog']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No blog found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function blog_views_update()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$blog_id = $request['blog_id'];
		$result = $this->assetsapi_model->blog_views_update($blog_id);
		$retres=array();
		if($result)
		{
			$retres['success']=1;
			$retres['msg']="Blog view count added successfully";
			$retres['blog']=$result;
		}
		else
		{
			$retres['success']=0;
			$retres['msg']='Something went wrong. Please try again !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function blog_comment_insert()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$blogCmtData = array(
			'blog_id' => $request['blog_id'],
			'name' => $request['name'],
			'email' => $request['email'],
			'status' => 1,
			'comment' => $request['comment']
		);
		$result = $this->assetsapi_model->blog_comment_insert($blogCmtData);
		$retres=array();
		if($result)
		{
			$retres['success']=1;
			$retres['msg']="Blog comment added successfully";
			$retres['blog_comment']=$result;
		}
		else
		{
			$retres['success']=0;
			$retres['msg']='Something went wrong. Please try again !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function blog_comment_tb($id)
    {
		$result = $this->assetsapi_model->blog_comment_tb($id);
		if($result){
			$retres['success']=1;
			$retres['blog']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No blog comments found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
//========================================================Blog End=====================================================================================	
//=================================================================================================================================================================	


//=================================================================Advertisement Start==========================================================================	
	public function advertisement()
    {
		$result = $this->assetsapi_model->advertisement();
		if($result){
			$retres['success']=1;
			$retres['advertisement']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No advertisement found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
//=================================================================Advertisement End==========================================================================	
//=============================================================================================================================================================		


//================================================================Property Start======================================================================	
	public function add_property()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		
		
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->add_property($request);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Property added successfully !!!";
				$retres['property']=$result;
			}
			else
			{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
			}
		}else
			{
				$retres['success']=0;
				$retres['msg']='Unauthorised access !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
    }
	
	public function edit_property()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$total_amount = isset($request['total_amount'])?$request['total_amount']:'';
		$rent = isset($request['rent'])?$request['rent']:'';
		$propertyData = array(
			'owner_id' => $request['owner_id'],
			'title' => $request['title'],
			'address' => $request['address'],
			'city' => $request['city'],
			'state' => $request['state'],
			'country' => $request['country'],
			'zip_code' => $request['zip_code'],
			'property_type' => $request['property_type'],
			'property_status' => $request['property_status'],
			'description' => $request['description'],
			'geo_location' => $request['geo_location'],
			'square_feet' => $request['square_feet'],
			'bedroom' => $request['bedroom'],
			'bathroom' => $request['bathroom'],
			'total_amount' => $total_amount,
			'rent' => $rent,
			'advance' => $request['advance'],
			'owner_details' => $request['owner_details'],
			'img_path' => $request['img_path'],
			'property_id' => $request['property_id'],
			'agent_perc'=>$request['agent_perc'],
			'status' => 1,
			'property_access'=>$request['property_access']
			
		);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		$retres=array();
		if($validate)
		{
			$result = $this->assetsapi_model->edit_property($propertyData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Property edited successfully !!!";
				$retres['property']=$result;
			}
			else
			{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
			}
		}else
		{
			$retres['success']=0;
			$retres['msg']='Unauthorised access !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
	public function delete_property()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$propertyData = array(
			'property_id' => $request['property_id']
		);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->delete_property($propertyData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']='Property deleted successfully !!!';
			}
			else
			{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
			}
	}else
			{
				$retres['success']=0;
				$retres['msg']='Unauthorised access !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function property()
    {
		$result = $this->assetsapi_model->property();
		$retres=array();
		if($result){
			$retres['success']=1;
			$retres['property']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No property found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	public function property_by($id,$session_id)
    {
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->property_by($id);
			$retres=array();
			if($result){
				$retres['success']=1;
				$retres['property']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No property found !!!';
			}
		}else{
			$retres['success']=0;
			$retres['msg']='Unauthorised access !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
    public function property_details($id)
    {
		$result = $this->assetsapi_model->property_details($id);
		$retres=array();
		if($result){
			$retres['success']=1;
			$retres['property']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No property found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	/* Property  End*/
	
	/* Property Search start*/
	 
	 public function property_search()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$keyword = isset($request['keyword']) ? $request['keyword'] : '';
		$property_type = isset($request['property_type']) ? $request['property_type'] : '';
		$city = isset($request['city']) ? $request['city'] : '';
		$property_status = isset($request['property_status']) ? $request['property_status'] : '';
		$area = isset($request['area']) ? $request['area'] : '';
		$min_price = isset($request['min_price']) ? $request['min_price'] : '';
		$max_price = isset($request['max_price']) ? $request['max_price'] : '';
		
		$propertyData = array(
			'keyword' => $keyword,
			'city' => $city,
			'property_type' => $property_type,
			'property_status' => $property_status,
			'area' => $area,
			'min_price' => $min_price,
			'max_price' => $max_price,
			'status' => 1,
			
		);
		$result = $this->assetsapi_model->property_search($propertyData);
		$retres=array();
		if($result){
			$retres['success']=1;
			$retres['property_search']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No property found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	 /* Property Search End*/
	 
	  /*  Statics Count Start*/
	  
	public function statics_count()
    {
		$result = $this->assetsapi_model->statics_count();
		$retres=array();
		if($result){
			$retres['success']=1;
			$retres['statics_count']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No statics found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	   /*  Statics Count End*/
	 
	 /* property status Type */
	public function property_status()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$retres=array();
		$propertyStatus = array(
			'property_status' => $request['property_status'],
			);
		$result = $this->assetsapi_model->property_status($propertyStatus);
		if($result){
			$retres['success']=1;
			$retres['property_status']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No property found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	 /* property status Type End */
//==============================================================Property End========================================================================	
//=============================================================================================================================================================	
	 
	 /*  Our Agent */
	public function our_agent()
    {
		$result = $this->assetsapi_model->our_agent();
		$retres=array();
		if($result){
			$retres['success']=1;
			$retres['our_agent']=$result;
		}else{
			$retres['success']=0;
			$retres['msg']='No agent found !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
	public function contact()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$contactData = array(
			'name' => $request['name'],
			'email' => $request['email'],
			'phone' => $request['phone'],
			'subject' => $request['subject'],
			'message' => $request['message'],
			'contactfor' => $request['contactfor'],
			'attachement' => $request['attachement']
			
			
		);
		$result = $this->assetsapi_model->contact($contactData);
		$retres=array();
		if($result){
			$retres['success']=1;
			// $retres['contact']=$result;
			$retres['msg']='Details submitted successfully.';
		}else{
			$retres['success']=0;
			$retres['msg']='Something went wrong. Please try later.!!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	  /*  Our Agent end*/
	 

	/*  Profile Start*/
	public function profile($id,$session_id)
    { 
		//$SESSION_ID = $this->session->userdata('session_id');
		//$seesid = $SESSION_ID."::".$session_id;
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		$retres=array();
		if($validate)
		{
			$result = $this->assetsapi_model->profile($id);
			if($result){
				$retres['success']=1;
				$retres['profile']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No profile found !!!';
			}
		}else{
			$retres['success']=0;
			$retres['msg']='Unauthorised User !!!';
		}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function statics_count_by($id,$session_id)
    { 
		//$SESSION_ID = $this->session->userdata('session_id');
		//$seesid = $SESSION_ID."::".$session_id;
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		$retres=array();
		if($validate)
		{
			$result = $this->assetsapi_model->statics_count_by($id);
			if($result){
				$retres['success']=1;
				$retres['statics']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No statics found !!!';
			}
		}else{
				$retres['success']=0;
				$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	public function profile_contact_list($id,$session_id)
    {
		//$SESSION_ID = $this->session->userdata('session_id');
		//$seesid = $SESSION_ID."::".$session_id;
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		$retres=array();
		if($validate)
		{
			$result = $this->assetsapi_model->profile_contact_list($id);
			if($result){
				$retres['success']=1;
				$retres['contactlist']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
			}
		}else{
				$retres['success']=0;
				$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	public function recent_added_property($id,$session_id)
    {
		//$SESSION_ID = $this->session->userdata('session_id');
		//$seesid = $SESSION_ID."::".$session_id;
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		$retres=array();
		if($validate)
		{
			$result = $this->assetsapi_model->recent_added_property($id);
			if($result){
				$retres['success']=1;
				$retres['property']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
			}
		}else{
				$retres['success']=0;
				$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	/*  Profile End*/	
	
	 	// =====================================Settings Start=====================================================================
	 public function setting_profile()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		
		//$SESSION_ID = $this->session->userdata('session_id');
		// $seesid = $SESSION_ID."::".$request['session_id'];
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			
			
			$result = $this->assetsapi_model->setting_profile($request);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Profile edited successfully !!!";
				$retres['profile']=$result;
			}
			else
			{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
				
			}
		}else{
			$retres['success']=0;
			$retres['msg']='Unauthorised User !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
    }
	
	  /* Settings Edit End */
	  
	  /* Settings  Password Edit */
	  public function setting_password()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$passwordData = array(
				'assets_id'=>$request['assets_id'],
				'old_password' => $request['old_password'],
				'new_password' => $request['new_password'],
				'confirm_password' => $request['confirm_password'],
				'email' => $request['email']
				
				
			);
		//$SESSION_ID = $this->session->userdata('session_id');
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
				$query = $this->db->get_where('registration_tb', array('assets_id' => $request['assets_id']));
				$data = $query->result_array();

				$old_password =  $this->assetsapi_model->encrypt_decrypt('decrypt',$data[0]['password']);
				if($old_password==$request['old_password'])
				{
					if($request['new_password']==$request['confirm_password'])
					{
						$result = $this->assetsapi_model->setting_password($passwordData);
						$retres=array();
						if($result)
						{
							$retres['success']=1;
							$retres['msg']="Password changed successfully !!!";
							$retres['profile']=$result;
						}
						else
						{
							$retres['success']=0;
							$retres['msg']='Something went wrong. Please try again !!!';
						}
					}else
					{
						$retres['success']=0;
						$retres['msg']='New password not matched !!!';
					}
					
				}else
					{
						$retres['success']=0;
						$retres['msg']='old password not matched !!!';
					}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		$retres=json_encode($retres);
			echo $retres;
		
    }
	// =====================================Settings End=====================================================================
	 
	 
		// =====================================Notification Start=====================================================================
	public function notification($receiver,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true); 
		
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->notification($receiver);
			if($result){
				$retres['success']=1;
				$retres['notification']=$result;
			}else{
				$retres['success']=0;
				$retres['msg']='No notification found !!!';
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	public function notification_alert($receiver,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true); 
		
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->notification_alert($receiver);
			if($result){
				$retres['success']=1;
				$retres['notification']=$result['result'];
				$retres['notifyCnt']=$result['result1'];
			}else{
				$retres['success']=0;
				$retres['msg']='No notification found !!!';
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	public function send_notification()
    {
	 $request = json_decode(file_get_contents('php://input'), true);
		$notificationData = array(
				'sender'=>$request['sender'],
				'receiver' => $request['receiver'],
				'assets_type' => $request['assets_type'],
				'message' => $request['message']
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->send_notification($notificationData);
				
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Notification send successfully !!!";
					$retres['notification']=$result;
				}
				else
				{
					$retres['success']=0;
					$retres['msg']='Something went wrong. Please try again !!!';
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
				$retres=json_encode($retres);
				echo $retres;
		
	}
	public function delete_notification($notify_id,$session_id)
    {
	 // $request = json_decode(file_get_contents('php://input'), true);
		// $NotifyData = array(
			// 'notify_id' =>  $request['notify_id']
		// );
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->delete_notification($notify_id);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']='Notification deleted successfully !!!';
			}
			else
			{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
		
	}
	public function notification_status_change($receiver,$session_id){
	
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
		
			 $upd_status = $this->db->update('notification_tb',array('status'=>'1'),array('receiver'=>$receiver));
			if($upd_status){
				$retres['success']=1;
				$retres['msg']='Status updated !!!';
			}else{
				$retres['success']=0;
				$retres['msg']='Somthing went wrong. !!!';
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
        $retres=json_encode($retres);
        echo $retres;
	}
	// =====================================Delete Notification End=================================================================
	// =====================================Notification End=====================================================================
	
	
	// =====================================Agent/Tenant/Owner Start=====================================================================
	// =====================================dropdown for invite request start=====================================================================
	public function invite_request($userid,$assets_type,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true);
		// $requestData = array(
				
				// 'assets_type' => $request['assets_type']
				
			// );
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->invite_request($userid,$assets_type);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['invitation']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	// =====================================dropdown for invite request end=====================================================================
	
	
	// =====================================Send Invite Request Start=====================================================================
	public function invite()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$prop = (isset($request['property_id']))?$request['property_id']:'';
		$inviteData = array(
				'assets_id'=>$request['assets_id'],
				'invite_id' => $request['invite_id'],
				'message' => $request['message'],
				'property_id'=>$request['property_id'],
				'request_status'=>'Pending'
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$sql = "SELECT * FROM invite_tb WHERE ((assets_id='".$request['assets_id']."' AND invite_id='".$request['invite_id']."' ) OR (assets_id='".$request['invite_id']."' AND invite_id='".$request['assets_id']."')) AND request_status='Joined'";
			$query=$this->db->query($sql);
			$checkDuplicate = $query->result();
			
			$sql2 = "SELECT * FROM invite_tb WHERE (assets_id='".$request['assets_id']."' AND invite_id='".$request['invite_id']."' ) AND request_status='Pending'";
		
			$query2=$this->db->query($sql2);
			$checkDuplicate2 = $query2->result();
			
			$sql3 = "SELECT * FROM invite_tb WHERE (assets_id='".$request['invite_id']."' AND invite_id='".$request['assets_id']."') AND request_status='Pending'";
		
			$query3=$this->db->query($sql3);
			$checkDuplicate3 = $query3->result();
			
			if(count($checkDuplicate)==0)
			{
				if(count($checkDuplicate2)==1)
				{
					// $updateData = array(
						// 'request_status'=>1
						
						
					// );
					// $this->db->update('invite_tb',$updateData);
					// $query = $this->db->get('invite_tb');
					// $result = $query->result_array();
					// $retres=array();
					// if($result)
					// {
						$retres['success']=1;
						$retres['msg']="You already requested for same user. !!!";
						// $retres['invitation']=$result;
					// }
				}else if(count($checkDuplicate3)==1)
				{
					// $updateData = array(
						// 'request_status'=>1
						
						
					// );
					// $this->db->update('invite_tb',$updateData);
					// $query = $this->db->get('invite_tb');
					// $result = $query->result_array();
					// $retres=array();
					// if($result)
					// {
						$retres['success']=1;
						$retres['msg']="You already invited for same user. Please accept request in requested section !!!";
						// $retres['invitation']=$result;
					// }
				}
				else
				{
					$result = $this->assetsapi_model->invite($inviteData);
					$retres=array();
					if($result)
					{
						$retres['success']=1;
						$retres['msg']="Invitation send successfully. !!!";
						$retres['invitation']=$result;
					}
				}
			}else
			{
				$retres['success']=0;
				$retres['msg']='User already connected. !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
				$retres=json_encode($retres);
				echo $retres;
		
	}
	// =====================================Send Invite Request End=====================================================================
		
	// =====================================Accept Invite Request Start=====================================================================
	public function invite_accept($assets_id,$invite_id,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true);
		// $inviteData = array(
				// 'assets_id'=>$request['assets_id'],
				// 'invite_id' => $request['invite_id']
				// );
	$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
				$result = $this->assetsapi_model->invite_accept($assets_id,$invite_id);
				
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Invitation Accepted successfully.";
					$retres['invitation']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='Something went wrong. Please try again !!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function invite_status($userid,$assets_type,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true);
		// $requestData = array(
				
				// 'assets_type' => $request['assets_type']
				
			// );
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->invite_status($userid,$assets_type);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['invite_status_detail']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
		// =====================================Accept Invite Request End=====================================================================
		
	// =====================================Requested Owner/Agent/Tenant Start/===================================================================== 
	  
	public function requested()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$inviteData = array(
				'user_id'=>$request['user_id'],
				'assets_type' => $request['assets_type']
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->requested($inviteData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['requested']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No Data Found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	// =====================================Requested Owner/Agent/Tenant Start/=====================================================================
	
		// =====================================Joind Owner/Agent/Tenant Start/=====================================================================
	public function joined()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$inviteData = array(
				'user_id'=>$request['user_id'],
				'assets_type' => $request['assets_type']
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->joined($inviteData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['joined']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No Data Found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	// =====================================Joind Owner/Agent/Tenant End/=====================================================================	
	
	public function send_message()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$msgData = array(
				'sender'=>$request['sender'],
				'receiver' => $request['receiver'],
				'message' => $request['message']
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->send_message($msgData);
			$retres=array();
					if($result)
					{
						$retres['success']=1;
						$retres['msg']="Message send successfully !!!";
						$retres['notification']=$result;
					}
					else
					{
						$retres['success']=0;
						$retres['msg']='Something went wrong. Please try again !!!';
					}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
				$retres=json_encode($retres);
				echo $retres;
	}
	// =====================================Agent/Tenant/Owner End=====================================================================
	
	// =====================================Service Start=====================================================================
	 public function service_request($userid,$session_id)
	 {
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->service_request($userid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Data not found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}	
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function service_request_send()
    {
		$request = json_decode(file_get_contents('php://input'), true);
		$serviceData = array(
				'property_id'=>$request['property_id'],
				'send_by' => $request['send_by'],
				'service_provider' => $request['service_provider'],
				'service_msg' => $request['service_msg'],
				'service_photo' => $request['service_photo']
				
			);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->service_request_send($serviceData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Something went wrong. Please try again !!!';
					$retres['service']=$result;
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}	
			$retres=json_encode($retres);
			echo $retres;
	}
	
	 public function service_send($userid,$session_id)
	 {
		 $validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->service_send($userid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Data not found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	public function service_resolve($userid,$session_id)
	 {
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->service_resolve($userid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Data not found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	public function service_detail($userId,$serviceid,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->service_detail($userId,$serviceid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Data not found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	public function service_requested($userid,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->service_requested($userid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Service request send successfully.";
				$retres['service']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='Data not found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	// =====================================Service End=====================================================================
	// =====================================Portal Content Start====================================================================
	public function portal_content($tag)
    {
		//$query = $this->db->get_where('portal_content_tb',array('tag'=>$tag));
		//$result = $query->result_array();
		$filename = $tag.'.txt';
		$result = file_get_contents('assetsadmin/textfiles/'.$filename);
		
		//$result = $query->result_array();

		if($result)
		{
			$retres['success']=1;
			//$retres['msg']="Service request send successfully.";
			$retres['portal_content']=json_decode($result);
		}
		else{
			$retres['success']=0;
			$retres['msg']='Data not found !!!';
				
		}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	// =====================================Portal Content End====================================================================
	
	//===========================================Logout============================================================================
	public function signout($id)
    {
		$this->session->unset_userdata('SESS_MEMBER_ID');
		$this->session->sess_destroy();
		 $this->facebook->destroy_session();
        // Remove user data from session
        $this->session->unset_userdata('userData');
		// $upd_status = $this->db->update('registration_tb',array('session_id'=>''),array('assets_id'=>$id));
		// echo $this->db->last_query();
		//redirect('login');
		$retres['success']=1;
		$retres['msg']="Signout successfully.";
			
	}
	//========================================Logout end=======================================================================
	
	//========================================Social Login start======================================================================
	
	public function google()
    {
		if(isset($_GET['code'])){
			
            //authenticate user
            $this->google->getAuthenticate();
            
            //get user info from google
            $gpInfo = $this->google->getUserInfo();
            
            //preparing data for database insertion
            $userData['oauth_provider'] = 'google';
            $userData['oauth_uid']      = $gpInfo['id'];
            $userData['first_name']     = $gpInfo['given_name'];
            $userData['last_name']      = $gpInfo['family_name'];
            $userData['email']          = $gpInfo['email'];
            //$userData['gender']         = !empty($gpInfo['gender'])?$gpInfo['gender']:'';
           // $userData['locale']         = !empty($gpInfo['locale'])?$gpInfo['locale']:'';
            //$userData['profile_url']    = !empty($gpInfo['link'])?$gpInfo['link']:'';
           // $userData['picture_url']    = !empty($gpInfo['picture'])?$gpInfo['picture']:'';
            
            //insert or update user data to the database
            // $userID = $this->assetsapi_model->checkUser($userData);
            
            //store status & user info in session
            // $this->session->set_userdata('loggedIn', true);
            // $this->session->set_userdata('userData', $userData);
            
            //redirect to profile page
			$reacturl = $this->config->item('reacturl').'social?oauth_provider="'.$userData["oauth_provider"].'"&oauth_uid="'.$userData["oauth_uid"].'"&first_name="'.$userData["first_name"].'"&last_name="'.$userData["last_name"].'"&email="'.$userData["email"].'"';
           redirect($reacturl);
        } 
		//google login url
		$loginURL = $this->google->loginURL();
		
		if(!empty($loginURL)){
			redirect($loginURL);
		}
        //redirect('assetsapi','refresh');
        //google login url
        //$data['loginURL'] = $this->google->loginURL();
        
        //load google login view
        //$this->load->view('welcome_message',$data);
		
		// $retres=array();
		// if($userID)
		// {
			// $retres['success']=1;
			// $retres['msg']="Login successfully.";
			// $retres['googlelogin']=$userID;
		// }
		// else{
			// $retres['success']=0;
			// $retres['msg']='Something went wrong. Please try again !!!';
				
		// }
			
			// $retres=json_encode($retres);
			// echo $retres;
	}
	public function social_login(){
		$request = json_decode(file_get_contents('php://input'), true);
		
		$email = $request['email'];
		$assets_type = $request['assets_type'];
		$oauth_provider = $request['oauth_provider'] ;
		$oauth_uid =  $request['oauth_uid'] ;
		
		$sqlcont="SELECT * FROM registration_tb WHERE ((oauth_provider = '$oauth_provider' AND oauth_uid = '$oauth_uid') AND assets_type = '$assets_type')";
		$query =$this->db->query($sqlcont);
		$result=$query->result_array();
		if(count($result)==0){
			if($request['owner_type']==2)
			{
				$company_name = $request['company_name'] ;
				$website_url =  $request['website_url'] ;
			}else
			{
				$company_name = '';
				$website_url =  '';
			}
				
			if($request['assets_type']==2)
			{
				$agent_type = isset($request['agent_type']) ? $request['agent_type'] : '';
				
			}else
			{
				$agent_type = '';
				
			}
			
			$randNumber = mt_rand(100000, 999999);
				$hashPassword = $this->assetsapi_model->encrypt_decrypt('encrypt',$request['password']);
			$userData = array(
				'owner_type' => $request['owner_type'],
				'first_name' => $request['first_name'],
				'last_name' => $request['last_name'],
				'email' => $request['email'],
				'password' => $hashPassword,
				'city' => $request['city'],
				'state' => $request['state'],
				'country' => $request['country'],
				'zip_code' => $request['zip_code'],
				'mobile_no' => $request['mobile_no'],
				'landline_no' => $request['landline_no'],
				'assets_type' => $request['assets_type'],
				'company_name' => $company_name,
				'website_url' => $website_url,
				'agent_type' =>$agent_type,
				'account_id' =>$randNumber,
				'oauth_provider' => $oauth_provider,
				'oauth_uid' =>  $oauth_uid,
				'status' => '0'
			);
			$result = $this->assetsapi_model->register($userData);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']='Registered Successfully';
				 $retres['user']= $result;
				
				$assets_id = $result['assets_id'];
				$result1 = $this->assetsapi_model->profile($assets_id);
				
				
				$assets_type = $result1['assets_type'];
				
				$fullName = $result1['first_name']." ".$result1['last_name'];
				/* $to_email = $result1['email'];
				
				$from_email = "info@assetswatch.com";
				//========================Mail======================================================================
				$filename = 'registration_template.txt';
				$template = read_file('assets/email_template/'.$filename);
				$subject = "Registration";
				
				$tokensArr = array(
				'USER_NAME' => $fullName,
				 'USER_EMAIL'=> $to_email
				);
				$mail = $this->send_mail($from_email,$to_email,$subject,$tokensArr,$template); */
				// ========================Mail======================================================================
				// if($mail)
				// {
					// echo "send";
					
				// }else{
					// echo "not send ::".$this->email->print_debugger(FALSE);
					
				// }
				
				if($result['agentType']!='Service Provider')
				{
					$result2 = $this->assetsapi_model->plan_by_assetstype($request['assets_type']);
					if($result2)
					{
						$retres['plan']= $result2;
					}else
					{
						$retres['msg']='Registered Successfully. No plan available.!!!';
					}
				}else{
					$retres['msg']='Registered Successfully';
				}
				
			}
			else
			{
				$retres['success']=0;            
			}
		}else{
			$retres['success']=0;
			$retres['msg']='Email Already Exist, Please go to login tab !!!';
		}
        $retres=json_encode($retres);
        echo $retres;
	}
	public function linkedin()
	{
	
		$userData = array();
        
        //Include the linkedin api php libraries
       
		 //Include the linkedin api php libraries
        include_once APPPATH."libraries/LinkedIn/http.php";
        include_once APPPATH."libraries/LinkedIn/oauth_client.php";
        
        
        //Get status and user info from session
        //$oauthStatus = $this->session->userdata('oauth_status');
        //$sessUserData = $this->session->userdata('userData');
         //print_r($sessUserData);
        //if(isset($oauthStatus) && $oauthStatus == 'verified'){
            //User info from session
			//print_r($sessUserData);
           // $userData = $sessUserData;
        //}else
			if((isset($_REQUEST["oauth_init"]) && $_REQUEST["oauth_init"] == 1) || (isset($_REQUEST['oauth_token']) && isset($_REQUEST['oauth_verifier']))){
            $client = new oauth_client_class;
            $client->client_id = $this->config->item('linkedin_api_key');
            $client->client_secret = $this->config->item('linkedin_api_secret');
            $client->redirect_uri = $this->config->item('linkedin_redirect_url');
            $client->scope = $this->config->item('linkedin_scope');
            $client->debug = false;
            $client->debug_http = true;
            $application_line = __LINE__;
            
            //If authentication returns success
            if($success = $client->Initialize()){
                if(($success = $client->Process())){
                    if(strlen($client->authorization_error)){
                        $client->error = $client->authorization_error;
                        $success = false;
                    }elseif(strlen($client->access_token)){
                        $success = $client->CallAPI('http://api.linkedin.com/v1/people/~:(id,email-address,first-name,last-name,location,picture-url,public-profile-url,formatted-name)', 
                        'GET',
                        array('format'=>'json'),
                        array('FailOnAccessError'=>true), $userInfo);
                    }
                }
                $success = $client->Finalize($success);
            }
            
            if($client->exit) exit;
    
            if($success){
                //Preparing data for database insertion
                $first_name = !empty($userInfo->firstName)?$userInfo->firstName:'';
                $last_name = !empty($userInfo->lastName)?$userInfo->lastName:'';
                $userData = array(
                    'oauth_provider'=> 'linkedin',
                    'oauth_uid'     => $userInfo->id,
                    'first_name'     => $first_name,
                    'last_name'     => $last_name,
                    'email'         => $userInfo->emailAddress,
                    /*'locale'         => $userInfo->location->name,
                    'profile_url'     => $userInfo->publicProfileUrl,
                    'picture_url'     => $userInfo->pictureUrl*/
               );
                
                //Insert or update user data
                //$userID = $this->assetsapi_model->checkUser($userData);
                
                //Store status and user profile info into session
                $this->session->set_userdata('oauth_status','verified');
                 $this->session->set_userdata('userData',$userData);
                
                //Redirect the user back to the same page
                //redirect('/user_authentication');
				$reacturl = $this->config->item('reacturl').'social?oauth_provider="'.$userData["oauth_provider"].'"&oauth_uid="'.$userData["oauth_uid"].'"&first_name="'.$userData["first_name"].'"&last_name="'.$userData["last_name"].'"&email="'.$userData["email"].'"';
				redirect($reacturl);

            }else{
                 $data['error_msg'] = 'Some problem occurred, please try again later!';
            }
        }elseif(isset($_REQUEST["oauth_problem"]) && $_REQUEST["oauth_problem"] <> ""){
            $data['error_msg'] = $_GET["oauth_problem"];
        }else{
            $data['linkedinURL'] = base_url().$this->config->item('linkedin_redirect_url').'?oauth_init=1';
        }
        
        $data['userData'] = $userData;
        
        // Load login & profile view
		 // $retres=array();
		// if($userID)
		// {
			// $retres['success']=1;
			// $retres['msg']="Linkedin login successfully.";
			// $retres['linkedin']=$userID;
		// }
		// else{
			// $retres['success']=0;
			// $retres['msg']='Something went wrong. Please try again !!!';
				
		// }
			
			// $retres=json_encode($retres);
			// echo $retres;
       //redirect('assetsapi','refresh');
	}
	
	
	public function facebook()
	{
		// redirect('https://devstg.assetswatch.com','refresh');
		$userData = array();
		// Check if user is logged in
		 if($this->facebook->is_authenticated()){
			 
			// Get user facebook profile details
			$userProfile = $this->facebook->request('get', '/me?fields=id,first_name,last_name,email,gender,locale,picture');

            // Preparing data for database insertion
            $userData['oauth_provider'] = 'facebook';
            $userData['oauth_uid'] = $userProfile['id'];
            $userData['first_name'] = $userProfile['first_name'];
            $userData['last_name'] = $userProfile['last_name'];
            $userData['email'] = $userProfile['email'];
            // $userData['gender'] = $userProfile['gender'];
            // $userData['locale'] = $userProfile['locale'];
            // $userData['profile_url'] = 'https://www.facebook.com/'.$userProfile['id'];
            // $userData['picture_url'] = $userProfile['picture']['data']['url'];
			
            // Insert or update user data
            // $userID = $this->quakbox_model->checkFacebookUser($userData);
			
			// Check user data insert or update status
            if(!empty($userData)){
				
                $data['userData'] = $userData;
                $this->session->set_userdata('userData',$userData);
				$reacturl = $this->config->item('reacturl').'social?oauth_provider="'.$userData["oauth_provider"].'"&oauth_uid="'.$userData["oauth_uid"].'"&first_name="'.$userData["first_name"].'"&last_name="'.$userData["last_name"].'"&email="'.$userData["email"].'"';
				 redirect($reacturl);
				//redirect('home');
            } else {
				 
				$data['userData'] = array();
				//$this->load->view('landing');
            }
			// Get logout URL
			// $data['logoutUrl'] = $this->facebook->logout_url();
			$data['logoutURL'] = $this->facebook->logout_url();
			
		}else{
			 
			$data['authURL'] =  $this->facebook->login_url();
            /* $fbuser = '';
			// Get login URL
            $authUrl =  $this->facebook->login_url();
			if(!empty($authUrl)){
				redirect($authUrl); */
			}
        }  
		 
		 public function twitter()
		 {
			 if(isset($_SESSION['oauth_token'])){
			  $oauth_token=$_SESSION['oauth_token'];unset($_SESSION['oauth_token']);
			  $consumer_key = $this->config->item('twitter_consumer_token');
			  $consumer_secret = $this->config->item('twitter_consumer_secret');
			  $connection = new TwitterOAuth($consumer_key, $consumer_secret);
			 //necessary to get access token other wise u will not have permision to get user info
			  $params=array("oauth_verifier" => $_GET['oauth_verifier'],"oauth_token"=>$_GET['oauth_token']);
			  $access_token = $connection->oauth("oauth/access_token", $params);
			  //now again create new instance using updated return oauth_token and oauth_token_secret because old one expired if u dont u this u will also get token expired error
			  $connection = new TwitterOAuth($consumer_key, $consumer_secret,
			  $access_token['oauth_token'],$access_token['oauth_token_secret']);
			  $user_info = $connection->get("account/verify_credentials");
			 // print_r($user_info);
					$name = explode(" ",$user_info->name);
					$first_name = isset($name[0])?$name[0]:'';
					$last_name = isset($name[1])?$name[1]:'';
					
					$userData['oauth_provider'] = 'twitter';
					$userData['oauth_uid'] = $user_info->id;
					$userData['first_name'] = $first_name;
					$userData['last_name'] = $last_name;
					$data['userData'] = $userData;
					$reacturl = $this->config->item('reacturl').'social?oauth_provider="'.$userData["oauth_provider"].'"&oauth_uid="'.$userData["oauth_uid"].'"&first_name="'.$userData["first_name"].'"&last_name="'.$userData["last_name"].'"';
				 redirect($reacturl);
			}
			else{
			  // main startup code
			  $consumer_key = $this->config->item('twitter_consumer_token');
			  $consumer_secret = $this->config->item('twitter_consumer_secret');
			  //this code will return your valid url which u can use in iframe src to popup or can directly view the page as its happening in this example

			  $connection = new TwitterOAuth($consumer_key, $consumer_secret);
			  $oauthCallback = $this->config->item('alternate_url')."assetsapi/twitter";
			  $temporary_credentials = $connection->oauth('oauth/request_token', array("oauth_callback" =>$oauthCallback));
			  $_SESSION['oauth_token']=$temporary_credentials['oauth_token'];       $_SESSION['oauth_token_secret']=$temporary_credentials['oauth_token_secret'];$url = $connection->url("oauth/authorize", array("oauth_token" => $temporary_credentials['oauth_token']));
			// REDIRECTING TO THE URL
			  header('Location: ' . $url); 
			} 
			 /* $consumerKey = $this->config->item('twitter_consumer_token');
			$consumerSecret = $this->config->item('twitter_consumer_secret');
			$oauthCallback = base_url().'assetsapi/twitter/';
			$connection = new TwitterOAuth($consumerKey, $consumerSecret);
			$request_token = $connection->oauth("oauth/request_token", array("oauth_callback" =>base_url()."assetsapi/twitter/"));

			$_SESSION['oauth_token'] = $request_token['oauth_token'];
			$_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];

			$url = $connection->url("oauth/authorize", array("oauth_token" => $request_token['oauth_token']));
			header('Location: ' . $url);
			//echo $url;
			if($_GET['oauth_token'] || $_GET['oauth_verifier'])
			{	
				$connection = new TwitterOAuth($consumerKey, $consumerSecret, $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
				$access_token = $connection->oauth('oauth/access_token', array('oauth_verifier' => $_REQUEST['oauth_verifier'], 'oauth_token'=> $_GET['oauth_token']));

				$connection = new TwitterOAuth($consumerKey, $consumerSecret, $access_token['oauth_token'], $access_token['oauth_token_secret']);

				$user_info = $connection->get('account/verify_credentials');
			
				$oauth_token = $access_token['oauth_token'];
				$oauth_token_secret = $access_token['oauth_token_secret'];
					$name = explode(" ",$user_info->name);
					$first_name = isset($name[0])?$name[0]:'';
					$last_name = isset($name[1])?$name[1]:'';
					
					$userData['oauth_provider'] = 'twitter';
					$userData['oauth_uid'] = $user_info->id;
					$userData['first_name'] = $first_name;
					$userData['last_name'] = $last_name;
					//$userData['email'] = $fbUserProfile['email'];
					
					// $userID = $this->assetsapi_model->checkUser($userData);
					
					// $this->session->set_userdata('loggedIn', true);
					// $this->session->set_userdata('userData', $userData);
			}else{
				echo "error";
			}
			 $data['userData'] = $userData;
			print_r($userData);  */
        // Load login & profile view
		 // $retres=array();
		// if($userID)
		// {
			// $retres['success']=1;
			// $retres['msg']="Twitter login successfully.";
			// $retres['twitter']=$userID;
		// }
		// else{
			// $retres['success']=0;
			// $retres['msg']='Something went wrong. Please try again !!!';
				
		// }
			
			// $retres=json_encode($retres);
			// echo $retres;
       //redirect('assetsapi','refresh');
	   // $reacturl = $this->config->item('reacturl').'social?oauth_provider="'.$userData["oauth_provider"].'"&oauth_uid="'.$userData["oauth_uid"].'"&first_name="'.$userData["first_name"].'"&last_name="'.$userData["last_name"].'"';
				// redirect($reacturl);
			
    }
	

	
	//=======================================Plan Start======================================================================
	public function plan()
    {
		$result = $this->assetsapi_model->plan();
		$retres=array();
		if($result)
		{
			$retres['success']=1;
			$retres['plan']=$result;
		}
		else{
			$retres['success']=0;
			$retres['msg']='No record found !!!';
				
		}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function plan_by_assetstype($assets_type){
		$result = $this->assetsapi_model->plan_by_assetstype($assets_type);
		$retres=array();
		if($result)
		{
			$retres['success']=1;
			$retres['plan']=$result;
		}
		else{
			$retres['success']=0;
			$retres['msg']='No record found !!!';
				
		}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	//=======================================Plan End======================================================================
	
	
	//==========================================Plan Restrictions Check============================================================
	public function checkPermissions($userid,$feature_alias)
	{
		$userData = $this->assetsapi_model->profile($userid);
				$assets_type= $userData['assets_type'];
				$plan_id= $userData['plan_id'];
		
				$featureTagQuery = $this->db->get_where('feature_tb',array('feature_tag'=>$feature_alias));
				$featureTagArr = $featureTagQuery->result_array();
				
				$featureAvailable = $this->assetsapi_model->getPlandetail($plan_id,$feature_alias);
				
				$retres=array();
				if(count($featureTagArr)>0 && count($featureAvailable)>0)
				{
					$featureTag = $featureTagArr[0]['feature_tag'];
					$feature_unit = $featureTagArr[0]['feature_unit'];
					
					if($featureTag=='manage_properties_upto'){
						$propertyCount = $this->assetsapi_model->getPropertydetail($userid);
						 // print_r($propertyCount);
						 if(count($propertyCount)>0)
						 {
							 $used_feature = $propertyCount[0]['added_property'];
						 }else{
							$used_feature = 0; 
						 }
					}elseif($featureTag=='upload_image_per_property'){
						
						
						$used_feature = 0;
					}elseif($featureTag=='create_agreement'){
						
						$AgreementCount = $this->assetsapi_model->getAgreementCount($userid);
						 if(count($AgreementCount)>0){
							 $used_feature = $AgreementCount[0]['agreement_count'];
						 }else{
							$used_feature = 0; 
						 }
						
					}
					elseif($featureTag=='send_agreement_for_signature'){
						
						$SendAgreementCount = $this->assetsapi_model->getSendAgreementCount($userid);
						// print_r($SendAgreementCount);
						 if(count($SendAgreementCount)>0){
							 $used_feature = $SendAgreementCount[0]['agreement_count'];
						 }else{
							$used_feature = 0; 
						 }
					}
					
					elseif($featureTag=='document_upload'){
						
						 $DocumentCount = $this->assetsapi_model->getDocumentCount($userid);
						// print_r($SendAgreementCount);
						 if($DocumentCount){
							 $used_feature = $DocumentCount[0]['docCount'];
						 }else{
							$used_feature = 0; 
						 } 
					}
					
					
					
					if($feature_unit=='Limit'){
						/* if($featureTag=='upload_image_per_property'){
						
							$retres['success']=1;
							//$retres['msg']="You can proceed. !!!";
							$retres['available']=$featureAvailable;
						} */
						$availableLimitUpto =$featureAvailable[0]['limit_upto'];
						if(count($availableLimitUpto)>0 || count($used_feature)>0)
						{
							if($availableLimitUpto>$used_feature)
							{
								$retres['success']=0;
								$retres['msg']="You can proceed. !!!";
								$retres['used_feature']=$used_feature;
								$retres['limit']=$availableLimitUpto;
								
								
							}else{
								$retres['success']=1;
								 // $diff = ($availableLimitUpto - $used_feature); 
								 $retres['msg']="Your limit is over.Your maximum limit is $availableLimitUpto. !!!";
								$retres['used_feature']=$used_feature;
								$retres['limit']=$availableLimitUpto;
							}
						}else{
							$retres['success']=0;
							$retres['msg']='No data found.!!!';
						}
					}elseif($feature_unit=='Restrict'){
					//
						$status =$featureAvailable[0]['confirmation'];
						if($status==='Yes')
							{
								$retres['success']=1;
								$retres['msg']="You can proceed. !!!";
								$retres['status']=$status;
								
								
								
							}else{
								$retres['success']=0;
								 // $diff = ($availableLimitUpto - $used_feature); 
								 $retres['msg']="Please upgrade your plan for this feature.!!!";
								$retres['status']=$status;
								
							}
					}
				}else{
					$retres['success']=0;
					$retres['msg']='No data found.!!!';
							
				}
				$retres=json_encode($retres);
				echo $retres;
				
			
		}
		
		
		
//==========================================Payment Gateway===========================================================		
		/*public function purchase_plan($user_id,$plan_id)
		{
			$update = $this->db->update('registration_tb',array('plan_id'=>$plan_id),array('assets_id'=>$user_id));
			$retres=array();
			if($update)
			{
					$retres['success']=1;
					$retres['msg']="Plan successfully added to user. !!!";
					//$retres['used_feature']=$used_feature;
								
			}else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong please try later.!!!';
					
				}
				$retres=json_encode($retres);
				echo $retres;
		}
		*/
		public function payment($user_id,$plan_id,$plan_month_year)
		{ 
			// $update = $this->db->update('registration_tb',array('plan_id'=>$plan_id),array('assets_id'=>$user_id));
			
			$userData = $this->assetsapi_model->profile($user_id);
			$planData = $this->assetsapi_model->planDeatilBy($plan_id);
			
			$first_name = $userData['first_name'];
			$last_name = $userData['last_name'];
			//$address = $userData[0]['address'];
			$city = $userData['city'];
			$state = $userData['state'];
			$country = $userData['country'];
			$zip = $userData['zip_code'];
			$email = $userData['email'];
			$password = $userData['password'];
			$assets_type = $userData['assets_type'];
			if($plan_month_year=='per_month')
			{
				$planPrice = $planData[0]['per_month'];
			}else if($plan_month_year=='per_annum'){
				$planPrice = $planData[0]['per_annum'];
			}else{
				$planPrice = '';
			}
			
			$randNumber = mt_rand(100000, 999999);
			$orderid = 'TXN'.$randNumber;
			//$data = array('first_name'=>$first_name,'last_name'=>$last_name,'city'=>$city, 'state'=>$state, 'country'=>$country, 'zip'=>$zip,'email'=> $email, 'user_id'=>$user_id,'plan_id'=> $plan_id,'planPrice'=>$planPrice);
			$data = array('first_name'=>$first_name,'last_name'=>$last_name,'user_id'=>$user_id,'plan_id'=> $plan_id,'planPrice'=>$planPrice,'orderid'=>$orderid,'plan_month_year'=>$plan_month_year,'email'=> $email,'password'=> $password,'assets_type'=> $assets_type);
			
			//$this->load->view('payment_gatway',$data);
			
			
			// $datatoinsert = array('user_id'=>$user_id,'plan_id'=> $plan_id,'orderid'=> $orderid,'plan_amount'=>$planPrice);
			$retres=array();
			if($data)
			{
					$retres['success']=1;
					$retres['user_detail']=$data;
					$retres['orderid']=$orderid;
					// $insertData = $this->db->insert('transaction_tb',$datatoinsert);
					// $txn_id = $this->db->insert_id();
					
					$sessionData = array(
										// 'txn_id'=>$txn_id,
										'user_id'=>$user_id,
										'plan_id'=> $plan_id,
										'orderid'=> $orderid,
										'planPrice'=>$planPrice
										);
					$this->session->set_userdata('orderid',$orderid);

								
			}else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong please try later.!!!';
					
				}
				$retres=json_encode($retres);
				echo $retres;
		}
		
		public function paymentgateway()
		{
		//print_r($_POST);
		//exit();
			$request = json_decode(file_get_contents('php://input'), true);
			
			$partnerkey = $this->config->item('partnerkey');
			$partnerid = $this->config->item('partnerid');
			$transactiontype = $this->config->item('transactiontype');
			
			$userData = $this->assetsapi_model->profile($request["userid"]);
			//$planData = $this->assetsapi_model->planDeatilBy($plan_id);
			
			$first_name = $userData['first_name'];
			$last_name = $userData['last_name'];
			$address = $userData['city'].", ".$userData['state'].", ".$userData['country'].", ".$userData['zip_code'];
			$city = $userData['city'];
			
			$state = $userData['state'];
			$StateCodeQ = $this->db->get_where('uvw_country_states',array('state_name'=>$state));
			$stateRslt = $StateCodeQ->result_array();
			if(count($stateRslt)){
				$stateCode = $stateRslt[0]['state_2_code'];
			}else{
				$stateCode = '';
			}
						
			$country = $userData['country'];
			$CountryQuery = $this->db->get_where('countries',array('name'=>$country));
			$countryRslt = $CountryQuery->result_array();
			if(count($countryRslt)>0){
				$countryCode = $countryRslt[0]['sortname'];
			}else{
				$countryCode = '';
			}
			
			$zip = $userData['zip_code'];
			$email = $userData['email'];
			//$orderid = $this->session->userdata('orderid');
			//$explodeName = explode(' ' ,$_POST['name'])
			//$firstName = (!empty($explodeName[0]))?$explodeName[0]:'';
			//$lastName = (!empty($explodeName[1]))?$explodeName[1]:'';
			//$expirymmyy = date('m',strtotime($_POST['month'])).date('y',strtotime($_POST['year']));
			if($request['type']==='CC'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"expirymmyy"=>$request["expirymmyy"],
				"cvv"=>$request["cvv"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}else if($request['type']==='ACH'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}
			
			//print_r($datatosend);
			//exit();
			
						$this->db->order_by('transactiondate',"desc");
						$this->db->limit(1);
						$query = $this->db->get('transaction_tb');
						 $lastRecord = $query->result_array();
					  if($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null ){
						   $inv = $lastRecord[0]['invoice_number'];
						  
						    $inv_number = ++$inv;
					  }else{
						  $inv_number = 'AWLLC000001';
					  }
					  
						$invoice_number = $inv_number;
					   $datatoinsertTrans = array( 
									'invoice_number' => $invoice_number,
									'user_id'=>$request["userid"],
									'plan_id'=> $request["plan_id"],
									'orderid'=> $request["orderid"],
									'plan_amount'=>$request["transactionamount"],
									// 'transactionid'=>$responseArr->transactionid,
									// 'paymentmode'=>$responseArr->paymentmode,
									// 'transaction_type'=>$responseArr->transactiontype,
									// 'transactionamount'=>$responseArr->transactionamount,
									// 'transactionreference'=>$responseArr->transactionreference,
									// 'responsecode'=>$responseArr->responsecode,
									// 'responsestatus'=>$responseArr->responsestatus,
									// 'responsemessage'=>$responseArr->responsemessage,
									// 'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
									'trans_for'=>'Register',
									'paid_by'=>$request['type'],
									 "tax_amt"=>$request["extraAmt"],
									"actual_amt"=>$request["actual_amt"]
									
					   );
					 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					$insertTrans = $this->db->insert('transaction_tb',$datatoinsertTrans);
			$jsondata = json_encode($datatosend);
			log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://api.singularbillpay.com/v1/transaction",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				 CURLOPT_POSTFIELDS => $jsondata,
				 CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
					$retres['success']=0;
					 $retres['msg']='Somthing went wrong please try later.!!!';
					
				 
				} else {
				  //echo $response;
				  // $txn_id = $this->session->userdata('txn_no');
				  			log_message('debug',print_r($response,TRUE));
				  $responseArr = json_decode($response);
				 if(count($responseArr)>0){
				  if($request["orderid"] == $responseArr->orderid)
				  {
					 $datatoupdate = array( 
									
									'transactionid'=>$responseArr->transactionid,
									'paymentmode'=>$responseArr->paymentmode,
									'transaction_type'=>$responseArr->transactiontype,
									'transactionamount'=>$responseArr->transactionamount,
									'transactionreference'=>$responseArr->transactionreference,
									'responsecode'=>$responseArr->responsecode,
									'responsestatus'=>$responseArr->responsestatus,
									'responsemessage'=>$responseArr->responsemessage,
									'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate))
									
									
					   );
					  $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					
					
				  }
				
			 $retres=array();
			 if($request["orderid"] == $responseArr->orderid &&  $responseArr->responsestatus==='APPROVED')
			 {
				 $currDate = date('Y-m-d');
					if($request["plan_type"]=='per_month')
					{
						
						$expireDate = date('Y-m-d', strtotime($currDate. ' + 1 month'));
						
						
					}else if($request["plan_type"]=='per_annum')
					{
						 $expireDate = date('Y-m-d', strtotime($currDate. ' + 1 year'));
						
					} 
					$datatoinsert = array( 
									'assets_id'=>$request["userid"],
									'plan_id'=>$request["plan_id"],
									'plan_type'=>$request["plan_type"],
									'upgrade_reason'=>'Register',
									'expire_date'=>$expireDate,
									'upgrade_date'=>date("Y-m-d H:i:s")
									
					   );
					$insert = $this->db->insert('upgrade_plan_log_tb',$datatoinsert);
					$updateReg = $this->db->update('registration_tb',array('plan_id'=>$request["plan_id"],'status'=>1),array('assets_id'=>$request["userid"]));
					 $retres['success']=1;
					 $retres['msg']='Registered Successfully.!!!';
					
				
				//========================Mail======================================================================
				$to_email = $email;
				$from_email = "info@assetswatch.com";
				$RegFilename = 'registration_template.txt';
				$RegTemplate = read_file('assets/email_template/'.$RegFilename);
				$RegSubject = "Registration";
				
				$reacturl = $this->config->item('reacturl');
				$url = "<br/><a href='".$reacturl."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Login</a>";

				$RegTokensArr = array(
				'USER_NAME' => $first_name,
				 'USER_EMAIL'=> $to_email,
				 'URL'=> trim($url)
				);
				$RegMail = $this->send_mail($from_email,$to_email,$RegSubject,$RegTokensArr,$RegTemplate);
				// ========================Mail======================================================================
				//========================Mail Invoice====================================================
				
				$InvoiceFilename = 'invoice_template_transaction.txt';
				$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
				$InvoiceSubject = "Invoice For Registration";
				
				$transactionamount = $responseArr->transactionamount;
				$transData = $this->assetsapi_model->getTransactionBy($invoice_number);
				//$transactionamount = $transData[0]['transactionamount'];
				
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
						$title = 'Register';
						$relatedTitle = "Plan Name";
						 $relatedName = $PlanName;
					
					
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
				/* $PayBy = $request['type'];
				$chargeInfo = $this->assetsapi_model->getPaymentCharges($PayBy);
			
					 if($PayBy){
						 if($chargeInfo['pay_mode']=='Percentage'){
												 $tax_title = $chargeInfo['name']."(".$chargeInfo['charges']."% )";
												 $actualAmt = $request['actual_amt'];
												 $TaxAmount =($actualAmt*$chargeInfo['charges'])/100;
											 }else if($chargeInfo['pay_mode']=='Amount'){
												 $tax_title =  $chargeInfo['name']."( $".$chargeInfo['charges']." )";
												 $actualAmt = $request['actual_amt'];
												 $TaxAmount =$chargeInfo['charges'];
											 }
						
					 }else{
						 $tax_title = 'TAX';
						 $TaxAmount = 0;
						 $actualAmt = $request["actual_amt"];
					 }  */
				

				// $TotAmount = $transactionamount + $TaxAmount;
				$transactiondate = $responseArr->transactiondate;
				$InvoiceTokensArr = array(
					'PAYEE_NAME' => $payeeName,
					'PAYEE_ADDRESS' => $payeeaddress,
					'PAYEE_MOBILE' => $payeeMobile,
					'PAYEE_EMAIL' => $payeeEmail,
					// 'Billed_BY_NAME' => $Billed_BY_NAME,
					// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
					// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
					// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
					 // 'PAID_FOR'=> $paidFor,
					 // 'PAID_FOR_MONTH'=> $paid_for_month,
					 'RELATED_TITLE'=>$relatedTitle,
					  'RELATED_NAME'=>$relatedName,
					 'AMOUNT'=> number_format($actualAmt,2),
					  'TITLE'=> $title,
					 'TAX_AMOUNT'=> number_format($TaxAmount,2),
					 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
					 'INVOICE'=>$invoice_number,
					 'INVOICE_DATE'=>$transactiondate
					 
				/* 'ADDRESS' => $address,
				 'TITLE'=> 'Registration Fee',
				 'AMOUNT'=> number_format($actualAmt,2),
				 'TAX_AMOUNT'=> number_format($TaxAmount,2),
				  'TAX_TITLE'=> $taxTitle,
				 'TOTAL_AMOUNT'=> number_format($transactionamount,2),
				 'INVOICE'=>$invoice_number,
				 'INVOICE_DATE'=>date('d M Y') */
				);
				$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
				// 
				// if($mail)
				// {
					// echo "send";
					
				// }else{
					// echo "not send ::".$this->email->print_debugger(FALSE);
					
				// }
					 //$retres['payment']=$responseArr;
				
				
								
			 }else{
					 $retres['success']=0;
					 $retres['msg']='Somthing went wrong please try later.!!!';
					
				 }
			}else{
					 $retres['success']=0;
					 $retres['msg']=$responseArr->responsemessage;
					
				 }
			}
				 $retres=json_encode($retres);
				 echo $retres;
		}
		
//========================================================================================================================================================================	

//========================================Plan Upgrade========================================================================
public function upgpaymentgateway()
		{
		//print_r($_POST);
		//exit();
			$request = json_decode(file_get_contents('php://input'), true);
			
			$partnerkey = $this->config->item('partnerkey');
			$partnerid = $this->config->item('partnerid');
			$transactiontype = $this->config->item('transactiontype');
			
			$userData = $this->assetsapi_model->profile($request["userid"]);
			//$planData = $this->assetsapi_model->planDeatilBy($plan_id);
			
			$first_name = $userData['first_name'];
			$last_name = $userData['last_name'];
			$address = $userData['city']." ".$userData['state']." ".$userData['country']." ".$userData['zip_code'];
			$city = $userData['city'];
			
			$state = $userData['state'];
			$StateCodeQ = $this->db->get_where('uvw_country_states',array('state_name'=>$state));
			$stateRslt = $StateCodeQ->result_array();
			if(count($stateRslt)){
				$stateCode = $stateRslt[0]['state_2_code'];
			}else{
				$stateCode = '';
			}
			
						
			$country = $userData['country'];
			$CountryQuery = $this->db->get_where('countries',array('name'=>$country));
			$countryRslt = $CountryQuery->result_array();
			if(count($countryRslt)>0){
				$countryCode = $countryRslt[0]['sortname'];
			}else{
				$countryCode = '';
			}
			
			$zip = $userData['zip_code'];
			$email = $userData['email'];
			//$orderid = $this->session->userdata('orderid');
			//$explodeName = explode(' ' ,$_POST['name'])
			//$firstName = (!empty($explodeName[0]))?$explodeName[0]:'';
			//$lastName = (!empty($explodeName[1]))?$explodeName[1]:'';
			//$expirymmyy = date('m',strtotime($_POST['month'])).date('y',strtotime($_POST['year']));
			if($request['type']==='CC'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"expirymmyy"=>$request["expirymmyy"],
				"cvv"=>$request["cvv"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
				
			}else if($request['type']==='ACH'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}
			//print_r($datatosend);
			//exit();
			
			  $this->db->order_by('transactiondate',"desc");
						$this->db->limit(1);
						$query = $this->db->get('transaction_tb');
						 $lastRecord = $query->result_array();
					  if($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null ){
						  $inv = $lastRecord[0]['invoice_number'];
						  
						    $inv_number = ++$inv;
					  }else{
						  $inv_number = 'AWLLC000001';
					  }
					  
					   $invoice_number = $inv_number;
					   $datatoinsertTrans = array( 
									'invoice_number' => $invoice_number,
									'user_id'=>$request["userid"],
									'plan_id'=> $request["plan_id"],
									'orderid'=> $request["orderid"],
									'plan_amount'=>$request["transactionamount"],
									//'transactionid'=>$responseArr->transactionid,
									//'paymentmode'=>$responseArr->paymentmode,
									//'transaction_type'=>$responseArr->transactiontype,
									//'transactionamount'=>$responseArr->transactionamount,
									//'transactionreference'=>$responseArr->transactionreference,
									// 'responsecode'=>$responseArr->responsecode,
									// 'responsestatus'=>$responseArr->responsestatus,
									// 'responsemessage'=>$responseArr->responsemessage,
									// 'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
									 'trans_for'=>'Upgrade',
									// 'paid_by'=>$request['type'],
									 "tax_amt"=>$request["extraAmt"],
									"actual_amt"=>$request["actual_amt"],
									
					   );
					   // print_r($datatoinsertTrans);
					 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					$insertTrans = $this->db->insert('transaction_tb',$datatoinsertTrans);
					
					
			 $jsondata = json_encode($datatosend);
			 log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://api.singularbillpay.com/v1/transaction",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  
				 CURLOPT_POSTFIELDS => $jsondata,
				 CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				  //echo $response;
				  $txn_id = $this->session->userdata('txn_no');
				  log_message('debug',print_r($response,TRUE));
				  $responseArr = json_decode($response);
				   if(count($responseArr)>0){
				  if($request["orderid"] == $responseArr->orderid)
				  {
					   $datatoupdate = array( 
									
									'transactionid'=>$responseArr->transactionid,
									'paymentmode'=>$responseArr->paymentmode,
									'transaction_type'=>$responseArr->transactiontype,
									'transactionamount'=>$responseArr->transactionamount,
									'transactionreference'=>$responseArr->transactionreference,
									'responsecode'=>$responseArr->responsecode,
									'responsestatus'=>$responseArr->responsestatus,
									'responsemessage'=>$responseArr->responsemessage,
									'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
									'trans_for'=>'Upgrade',
									'paid_by'=>$request['type']
									
									
					   );
					$update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					$currDate = date('Y-m-d');
					if($request["plan_type"]=='per_month')
					{
						
						$expireDate = date('Y-m-d', strtotime($currDate. ' + 1 month'));
						
						
					}else if($request["plan_type"]=='per_annum')
					{
						 $expireDate = date('Y-m-d', strtotime($currDate. ' + 1 year'));
						
					}
			if($responseArr->responsestatus==='APPROVED'){
				$this->db->order_by('upgrade_id','DESC');
				$this->db->limit(1);
				$UPGquery =  $this->db->get_where('upgrade_plan_log_tb',array('assets_id'=>$request["userid"]));
				$Upgrslt = $UPGquery->result_array();
				$upgrade_id = $Upgrslt[0]['upgrade_id'];
				if(count($rslt)>0){
					$this->db->update('upgrade_plan_log_tb',array('plan_change_date'=>date("Y-m-d H:i:s")),array('upgrade_id'=>$upgrade_id));
					
				}
						$datatoinsert = array( 
										'assets_id'=>$request["userid"],
										'plan_id'=>$request["plan_id"],
										'plan_type'=>$request["plan_type"],
										'upgrade_reason'=>'Upgrade',
										'expire_date'=>$expireDate,
										'upgrade_date'=>date("Y-m-d H:i:s")
										
						   );
						$insert = $this->db->insert('upgrade_plan_log_tb',$datatoinsert);
						$updateReg = $this->db->update('registration_tb',array('plan_id'=>$request["plan_id"],'status'=>1),array('assets_id'=>$request["userid"]));
			}
			
					
				  }
				
			 $retres=array();
			 if($request["orderid"] == $responseArr->orderid &&  $responseArr->responsestatus==='APPROVED')
			 {
					 $retres['success']=1;
					 $retres['msg']='Plan Upgraded Successfully.!!!';
					 
					 //========================Mail Invoice====================================================
					 $settingInfo = $this->assetsapi_model->getEmailSmsSettingInfo($request["userid"]);
					 if($settingInfo){
						 if($settingInfo['email']==='ON'){
								$to_email = $email;
								$from_email = "info@assetswatch.com";
								$InvoiceFilename = 'invoice_template_transaction.txt';
								$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
								$InvoiceSubject = "Invoice For Plan Upgrade";
								
								$transactionamount = $responseArr->transactionamount;
								$transData = $this->assetsapi_model->getTransactionBy($invoice_number);
					
					 //$transactionamount = $transData[0]['transactionamount'];
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					 
						  $title = 'Plan Upgrade';
						   $relatedTitle ="Plan Name" ;
						  $relatedName = $PlanName;
					
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
								

								$InvoiceTokensArr = array(
									'PAYEE_NAME' => $payeeName,
									'PAYEE_ADDRESS' => $payeeaddress,
									'PAYEE_MOBILE' => $payeeMobile,
									'PAYEE_EMAIL' => $payeeEmail,
									// 'Billed_BY_NAME' => $Billed_BY_NAME,
									// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
									// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
									// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
									 // 'PAID_FOR'=> $paidFor,
									 // 'PAID_FOR_MONTH'=> $paid_for_month,
									 'RELATED_TITLE'=>$relatedTitle,
									  'RELATED_NAME'=>$relatedName,
									 'AMOUNT'=> number_format($actualAmt,2),
									  'TITLE'=> $title,
									 'TAX_AMOUNT'=> number_format($TaxAmount,2),
									 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
									 'INVOICE'=>$invoice_number,
									 'INVOICE_DATE'=>$transactiondate
									// 'ADDRESS' => $address,
									 // 'TITLE'=> 'Plan Upgrade Fee',
									 // 'AMOUNT'=> number_format($actualAmt,2),
									 // 'TAX_TITLE'=> $tax_title,
									 // 'TAX_AMOUNT'=> number_format($TaxAmount,2),
									 // 'TOTAL_AMOUNT'=> number_format($transactionamount,2),
									 // 'INVOICE'=>$invoice_number,
									 // 'INVOICE_DATE'=>date('d M Y')
									);
								$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate); 
						 }
					 }else{
						$to_email = $email;
						$from_email = "info@assetswatch.com";
						$InvoiceFilename = 'invoice_template_transaction.txt';
						$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
						$InvoiceSubject = "Invoice For Plan Upgrade";
						
						$transactionamount = $responseArr->transactionamount;
						$transData = $this->assetsapi_model->getTransactionBy($invoice_number);
					
					 //$transactionamount = $transData[0]['transactionamount'];
					  if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					 
						  $title = 'Plan Upgrade';
						   $relatedTitle ="Plan Name" ;
						  $relatedName = $PlanName;
					
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
						$InvoiceTokensArr = array(
						'PAYEE_NAME' => $payeeName,
						'PAYEE_ADDRESS' => $payeeaddress,
						'PAYEE_MOBILE' => $payeeMobile,
						'PAYEE_EMAIL' => $payeeEmail,
						// 'Billed_BY_NAME' => $Billed_BY_NAME,
						// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
						// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
						// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
						 // 'PAID_FOR'=> $paidFor,
						 // 'PAID_FOR_MONTH'=> $paid_for_month,
						 'RELATED_TITLE'=>$relatedTitle,
						  'RELATED_NAME'=>$relatedName,
						 'AMOUNT'=> number_format($actualAmt,2),
						  'TITLE'=> $title,
						 'TAX_AMOUNT'=> number_format($TaxAmount,2),
						 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
						 'INVOICE'=>$invoice_number,
						 'INVOICE_DATE'=>$transactiondate
						// 'ADDRESS' => $address,
						 // 'TITLE'=> 'Plan Upgrade Fee',
						 // 'AMOUNT'=> number_format($actualAmt,2),
						 // 'TAX_TITLE'=> $tax_title,
						 // 'TAX_AMOUNT'=> number_format($TaxAmount,2),
						 // 'TOTAL_AMOUNT'=> number_format($transactionamount,2),
						 // 'INVOICE'=>$invoice_number,
						 // 'INVOICE_DATE'=>date('d M Y')
						);
						$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate); 
					 }
				
					 //$retres['payment']=$responseArr;
								
			 }else{
					 $retres['success']=0;
					 $retres['msg']=$responseArr->responsemessage;
					
				 }
			}else{
					 $retres['success']=0;
					 $retres['msg']=$responseArr->responsemessage;
					
				 }
			}
				 $retres=json_encode($retres);
				 echo $retres;
				 
		}
		
//========================================================================================================================================================================	
		
		
//================================================================Agreement Start=============================================================================================
		
	
	
	//==============================================================PDF Generation==============================================================================
		public function pdfGenerator($user_id,$agreement_id){
			// $propertyformQuery = $this->db->get_where('agreement_property_form_tb',array('status'=>'1'));
			// $propertyformData = $propertyformQuery->result_array();
			// $propDescription = $propertyformData[0]['description'];
			
			
			// $signatureQuery = $this->db->get('agreement_signature_form_tb',array('status'=>'1'));
			// $signatureformData = $signatureQuery->result_array();
			// $signDescription = $signatureformData[0]['description'];
			
			
			
			$userData = $this->assetsapi_model->profile($user_id);
			$assets_type= $userData['assets_type'];
			
			$agreementQuery = $this->db->get_where('agreement_tb',array('user_id'=>$user_id,'agreement_id'=>$agreement_id));
			$agreementData = $agreementQuery->result_array();
			
			$Title = $agreementData[0]['agreement_title'];
			$fileName = str_replace(" ", "_", $Title);
			

			$brandingData = $this->assetsapi_model->getBrandingInfo($user_id);
			
			
			if($brandingData){
				$branding = $brandingData['branding'];
					$headerContent = $brandingData['header_title'];
					$footerContent = $brandingData['footer_title'];
					$headerImage = $brandingData['branding_logo'];
					$watermarkImage = $brandingData['branding_watermark'];
			}else{
				$branding = 'Default';
				$headerContent = '';
				$footerContent = '';
				$headerImage = '';
				$watermarkImage = '';
			}
			
			
			$html = $agreementData[0]['agreement_doc_content'];
			
			
			//$TermsDescription = $agreementData[0]['agreement_doc_content'];
			
			
			// $html = $propDescription.$TermsDescription.$signDescription;
			// $html = $signDescription;
			
			// Create a new PDF but using our own class that extends TCPDF
			$pdf = new MyCustomPDFWithWatermark(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
			
			$template = array('headerContent'=>$headerContent,'footerContent'=>$footerContent,'headerImage'=>$headerImage,'watermarkImage'=>$watermarkImage,'branding'=>$branding);
			//echo $headerImage;
			
			$pdf->setData($template);
			
			// set document information
			//$pdf->SetAuthor('Our Code World');
			 
			// set default monospaced font
			//$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
			// set default header data
			$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
			// set margins
			//$pdf->SetMargins('10', '40', '10');
			
			// set margins
			$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
			$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
			$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
			
			 $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);//, 70,120, 57, 25, '', '', '', false, 300, '', false, false, 0);
			
			$pdf->SetFont('times', '', 8, '', true); 
				
			$pdf->AddPage();
			$pdf->writeHTML($html, true, false, true, false, '');
			
			if($assets_type == 1)
			{
				$path = "assets/agreement_DOC/Owner/$user_id/$agreement_id/";
				
				
			}elseif($assets_type == 2){
				$path = "assets/agreement_DOC/Agent/$user_id/$agreement_id/";
				
				
			}
			
			$folderPath = mkdir($path, 0777, true);
			$pdfFilePath = APPPATH.'../'.$path.$fileName.'.pdf';
			// echo $pdfFilePath;
			 ob_clean();
			  
			   $pdfgenerated = $pdf->Output($pdfFilePath, 'F');
			 //$pdfgenerated = $pdf->Output($_SERVER['DOCUMENT_ROOT']. $pdfFilePath, 'F');
				$this->db->set('agreement_file_name',$path.$fileName.'.pdf');
				$this->db->where('agreement_id', $agreement_id);
				$this->db->update('agreement_tb');
			
		}

		
//===========================================================Add Agreement================================================================================================
		public function add_agreement(){
			$request = json_decode(file_get_contents('php://input'), true);
			$agreement_doc_id = 'AWG'.mt_rand(100000, 999999);
			
			$header_content = isset($request['header_content'])?$request['header_content']:'';
			$header_image = isset($request['header_image'])?$request['header_image']:'';
			$watermark_image = isset($request['watermark_image'])?$request['watermark_image']:'';
			$footer_content = isset($request['footer_content'])?$request['footer_content']:'';
			
			$agreementData = array(
				'agreement_doc_id'=>$agreement_doc_id,
				'user_id'=>$request['user_id'],
				'agreement_title' => $request['agreement_title'],
				'agreement_doc_content' => $request['agreement_doc_content'],
				'header_content' => $header_content,
				'header_image' =>$header_image,
				'watermark_image' =>$watermark_image,
				'footer_content' =>$footer_content
				);
			
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
				$insertData = $this->db->insert('agreement_tb',$agreementData);
				$agreement_id = $this->db->insert_id();
				$retres=array();
				if($insertData)
				{
					$retres['success']=1;
					$retres['msg']="Agreement Created Successfully. !!!";
					$user_id = $request['user_id'];
					$profileInfo = $this->assetsapi_model->profile($user_id);
					$assets_type = $profileInfo['assets_type'];
					$assetsType= $this->assetsapi_model->getAssetsType($assets_type);
			//===============================header image======================
			/* if(isset($request['header_image']) && $request['header_image']!='')
			{
					$headerImg = $header_image;
					$headImg = str_replace('data:image/jpeg;base64,', '', $headerImg);
					$img = str_replace('data:image/png;base64,', '', $headImg);
					$headerimage = base64_decode($img);
					// echo "<script>alert(".$image.")</script>";
					$image_name = md5(uniqid(rand(), true));// image name generating with random number with 32 characters
					$headerfilename = $image_name . '.' . 'png';
					//rename file name with random number
					// $path = './';
					$path = "assets/agreement_DOC/".$assetsType."/".$user_id."/".$agreement_id."/";
					$folderPath = mkdir($path, 0777, true);
					$headtargetPath = $path.$headerfilename;
					file_put_contents($headtargetPath , $headerimage);
			} */
			//================================watermark image=========================================
			/* if(isset($request['watermark_image']) && $request['watermark_image']!='')
			{
					$watermark_Img = $watermark_image;
					$WImg = str_replace('data:image/jpeg;base64,', '', $watermark_Img);
					$waterimg = str_replace('data:image/png;base64,', '', $WImg);
					$wmimage = base64_decode($waterimg);
					// echo "<script>alert(".$image.")</script>";
					$wmimage_name = md5(uniqid(rand(), true));// image name generating with random number with 32 characters
					$WMfilename = $wmimage_name . '.' . 'png';
					//rename file name with random number
					// $path = './';
					$path = "assets/agreement_DOC/".$assetsType."/".$user_id."/".$agreement_id."/";
					if (!file_exists($path)) {
						$folderPath = mkdir($path, 0777, true);
					}else{
						$folderPath = $path;
					}
					
					
					$WMtargetPath = $path.$WMfilename;
					file_put_contents($WMtargetPath, $wmimage);
			} */
					// $this->db->set(array('header_image'=>$headtargetPath,'watermark_image'=>$WMtargetPath));
					// $this->db->where('agreement_id', $agreement_id);
					// $this->db->update('agreement_tb');
					
					$pdfgeneration = $this->pdfGenerator($user_id,$agreement_id);
					$retres['success']=1;
					$retres['msg']="Agreement Created.!!!";
					
				}else{
					$retres['success']=0;
					$retres['msg']="Somthing went wrong please try again.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			
			$retres=json_encode($retres);
			echo $retres;
		
		}
		

//=============================================================Send Agreement================================================================================================
		public function send_agreement(){
			$request = json_decode(file_get_contents('php://input'), true);
			
			$propQ = $this->db->get_where('property_tb',array('id'=>$request['property_id']));
			$propStatus=$propQ->result_array();
			$propsSt = $propStatus[0]['property_status'];
			$paid_to = isset($request['paid_to'])?$request['paid_to']:'';
			$agreementData = array(
				'sender_id'=>$request['sender_id'],
				'receiver_id'=>$request['receiver_id'],
				'agreement_id' => $request['agreement_id'],
				'property_id' => $request['property_id'],
				'initiated_date'=>date('Y-m-d'),
				'description'=>$request['description'],
				'tenure_start_date'=>$request['tenure_start_date'],
				'tenure_end_date'=>$request['tenure_end_date'],
				'paid_to'=>$paid_to
				);
				
				$retres=array();
			$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
			if($validate)
			{
				if($propsSt=='Rented' || $propsSt=='Sold'){
						$retres['success']=0;
						$retres['msg']="Selected property already ".$propsSt;
				}else{
					$result = $this->assetsapi_model->send_agreement($agreementData);
					if($result)
					{
						$retres['success']=1;
						$retres['msg']="Agreement send successfully. !!!";
						$retres['deal']=$result;
						
						
					}else{
						$retres['success']=0;
						$retres['msg']="Somthing went wrong please try again.!!!";
						
					}
				}
				
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
//===========================================================================================================

//=============================send forwarded agreement======================================================
	public function send_forwarded_agreement(){
			$request = json_decode(file_get_contents('php://input'), true);
			
			
			$agreementData = array(
				'sender_id'=>$request['sender_id'],
				'receiver_id'=>$request['receiver_id'],
				'agreement_id' => $request['agreement_id'],
				'property_id' => $request['property_id'],
				'initiated_date'=>date('Y-m-d'),
				'description'=>$request['description'],
				'updatedTemplate'=>$request['updatedTemplate'],
				'tenure_start_date'=>$request['tenure_start_date'],
				'tenure_end_date'=>$request['tenure_end_date']
				);
				
				$retres=array();
			$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
			if($validate)
			{
				$result = $this->assetsapi_model->send_forwarded_agreement($agreementData);
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Agreement send successfully. !!!";
					$retres['deal']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Somthing went wrong please try again.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
//==========================webview agreement============================================================
		public function webview_agreement($deal_id,$session_id){
			
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->webview_agreement($deal_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['webview']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
			
		}
//===========================================================List Of Saved Agreement================================================================================================
		public function saved_agreement($user_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->saved_agreement($user_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['saved_agreement']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}


//===========================================================Agreement Details================================================================================================		
		public function agreement_detail($agreement_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->agreement_detail($agreement_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['agreement_detail']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}


//===========================================================List Of Requested Agreement=======================================================================================
		public function requested_agreement($user_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->requested_agreement($user_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['requested_agreements']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function sended_agreement($user_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->sended_agreement($user_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['sended_agreements']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}


//===========================================================Requested Agreement Send=================================================================================
		/*public function requested_agreement_send()
		{
			$request = json_decode(file_get_contents('php://input'), true);
			$requestedData = array(
				
				'deal_id'=>$request['deal_id'],
				'version_name'=>$version_name,
				'file_name' => $file_name,
				'status' => $request['status'],
				'comment'=>$request['comment'],
				'acceptance_status'=>$request['acceptance_status']
				
				);
				
				$retres=array();
			
			$Insert = $this->db->insert('agreement_version_tb',$requestedData);
			if($Insert)
			{
				//$pdfgeneration = $this->pdfGenerator($user_id,$agreement_id);
			}
			/*$retres=array();
			if($result)
			{
				$retres['success']=1;
				$retres['agreement_detail']=$result;
				
				
			}else{
				$retres['success']=0;
				$retres['msg']="No data found.!!!";
				
			}
			$retres=json_encode($retres);
			echo $retres;
		}*/
		
//===========================================================List of Execute Agreement ====================================================================================
		public function execute_agreement($user_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->execute_agreement($user_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['execute_agreements']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data found.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		//------------------------------------------delete agreement==========================================================
		public function delete_agreement($agreement_id,$session_id)
		{
		 // $request = json_decode(file_get_contents('php://input'), true);
			// $NotifyData = array(
				// 'notify_id' =>  $request['notify_id']
			// );
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->delete_agreement($agreement_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']='Agreement deleted successfully. !!!';
				}
				else
				{
					$retres['success']=0;
					$retres['msg']='Something went wrong. Please try again !!!';
				}
			}else{
						$retres['success']=0;
						$retres['msg']='Unauthorised User !!!';
				}
			$retres=json_encode($retres);
			echo $retres;
			
		}
		
		//=======================================agreement detail by id===================================================
		public function agreement_detail_by($agreement_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->getAgreement($agreement_id);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['agreement_detail']=$result;
				}
				else
				{
					$retres['success']=0;
					$retres['msg']='Something went wrong. Please try again !!!';
				}
			}else{
						$retres['success']=0;
						$retres['msg']='Unauthorised User !!!';
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		//=====================================edit agreement=========================================================
		    public function edit_agreement()
			{
				$request = json_decode(file_get_contents('php://input'), true);
				$header_content = isset($request['header_content'])?$request['header_content']:'';
				$header_image = isset($request['header_image'])?$request['header_image']:'';
				$watermark_image = isset($request['watermark_image'])?$request['watermark_image']:'';
				$footer_content = isset($request['footer_content'])?$request['footer_content']:'';
				
				$agreementData = array(
				'agreement_title' => $request['agreement_title'],
				'agreement_doc_content' => $request['agreement_doc_content'],
				'header_content' =>$header_content,
				'header_image' =>$header_image,
				'watermark_image' =>$watermark_image,
				'footer_content' =>$footer_content,
				'agreement_id' => $request['agreement_id']
				);
				
				$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
				$agreement_id = $request['agreement_id'];
				if($validate)
				{
					$result = $this->assetsapi_model->edit_agreement($agreementData);
					$retres=array();
					if($result)
					{
						$retres['success']=1;
						$retres['msg']="Agreement edited successfully !!!";
						$retres['edit_agreement']=$result;
						$user_id = $result[0]['user_id'];
				//===============================header image======================
			/* if(isset($request['header_image']) && $request['header_image']!='')
			{
					$headerImg = $header_image;
					$headImg = str_replace('data:image/jpeg;base64,', '', $headerImg);
					$img = str_replace('data:image/png;base64,', '', $headImg);
					$headerimage = base64_decode($img);
					// echo "<script>alert(".$image.")</script>";
					$image_name = md5(uniqid(rand(), true));// image name generating with random number with 32 characters
					$headerfilename = $image_name . '.' . 'png';
					//rename file name with random number
					// $path = './';
					$path = "assets/agreement_DOC/Owner/$user_id/$agreement_id/";
					$folderPath = mkdir($path, 0777, true);
					$headtargetPath = $path.$headerfilename;
					file_put_contents($headtargetPath , $headerimage);
			}
			//================================watermark image=========================================
			if(isset($request['watermark_image']) && $request['watermark_image']!='')
			{
					$watermark_Img = $watermark_image;
					$WImg = str_replace('data:image/jpeg;base64,', '', $watermark_Img);
					$waterimg = str_replace('data:image/png;base64,', '', $WImg);
					$wmimage = base64_decode($waterimg);
					// echo "<script>alert(".$image.")</script>";
					$wmimage_name = md5(uniqid(rand(), true));// image name generating with random number with 32 characters
					$WMfilename = $wmimage_name . '.' . 'png';
					//rename file name with random number
					// $path = './';
					$path = "assets/agreement_DOC/Owner/$user_id/$agreement_id/";
					if (!file_exists($path)) {
						$folderPath = mkdir($path, 0777, true);
					}else{
						$folderPath = $path;
					}
					
					
					$WMtargetPath = $path.$WMfilename;
					file_put_contents($WMtargetPath, $wmimage);
			} */
							// $this->db->set(array('header_image'=>$headtargetPath,'watermark_image'=>$WMtargetPath));
							// $this->db->where('agreement_id', $agreement_id);
							// $this->db->update('agreement_tb');
							
							$pdfgeneration = $this->pdfGenerator($user_id,$request['agreement_id']);
					}
					else
					{
						$retres['success']=0;
						$retres['msg']='Something went wrong. Please try again !!!';
					}
				}else
				{
					$retres['success']=0;
					$retres['msg']='Unauthorised access !!!';
				}
				$retres=json_encode($retres);
				echo $retres;
			}
//====================================================AgreementEnd======================================================================

				
//===================================================================================================================================
	
	//=========================================================Add Services by service provider====================================================================
		public function getServices()
		{
			$query = $this->db->get('property_services_tb');
			$result = $query->result_array();
			
			$retres=array();
			
			if($result)
			{
				$retres['success']=1;
				$retres['services_list']=$result;
				
				
			}else{
				$retres['success']=0;
				$retres['msg']="No data found.!!!";
				
			}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function add_service_by_provider()
		{
			$request = json_decode(file_get_contents('php://input'), true);
			// if(!empty($request['services_list']))
			// foreach($request['services_list'] as $key=>$val)
			// {
				// $serviceArr[$request['user_id']][$val['service_id']] = $val['service_id'];
			// }
			$dataToAdd = array(
				
				'user_id'=>$request['user_id'],
				'services_list' => $request['services_list']
				
				);
			
			$validate = $this->assetsapi_model->getSessionValidate($request['session_id)']);
			if($validate)
			{
				$result = $this->assetsapi_model->add_service_by_provider($dataToAdd);			
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Data inserted successfully. !!!";
					$retres['added_service']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Somthing went wrong please try again.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
	
//======================================Add Services by service provider End ====================================
//================================================================================================================


//==========================================Send Email===========================================================
		public function send_mail($from_email='',$to_email='',$subject='',$tokensArr='',$template='')
		{ 
			$pattern = '[%s]';
			
			foreach($tokensArr as $key=>$val){
				$varMap[sprintf($pattern,$key)] = $val;
			}

			$emailContent = strtr($template,$varMap);
		  
		$config = Array(
                    'protocol' => 'smtp',
                    // 'smtp_host' => 'smtp.googlemail.com',
                    // 'smtp_port' => 587,
					//'smtp_host' => 'smtp.gmail.com', 
					'smtp_host' => 'smtpout.secureserver.net', 
					'smtp_crypto' => 'ssl',
					'smtp_port' => 465,
                    'smtp_user' => 'info@assetswatch.com',//'jirehhelpdesk@gmail.com', 
                    'smtp_pass' => 'Assets123',//my valid email password
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1',
                    'wordwrap' => TRUE
					
                  );
    $this->email->initialize($config);
    $this->load->library('email', $config);
    $this->email->set_newline("\r\n");  
    $this->email->from($from_email); 
    $this->email->to($to_email);
    $this->email->subject($subject);
    $this->email->message($emailContent);
		
		
   
         //Send mail 
          if($this->email->send()) 
			 return true; //$this->session->set_flashdata("email_sent","Email sent successfully."); 
          else 
			 return false;//$this->session->set_flashdata("email_sent","Error in sending Email."); 
      } 
//======================================================================Send Email End=============================================================================================
//========================================================================================================================================================================

//====================================================================User Search Start==========================================================================================	
	public function userSearch()
	{
		$request = json_decode(file_get_contents('php://input'), true);
		$datatopass = array(
			"assets_type"=>$request['assets_type'],
			"string"=>$request['string'],
			"userid"=>$request['userid'],
		);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->userSearch($datatopass);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['users']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
//====================================================================User Search End==========================================================================================	
//===============================================================================================================================================================================	


//======================================================================get countries=========================================================================================
	public function country()
	{
		$result = $this->assetsapi_model->getCountries();
		$retres = array();
		if($result)
		{
			$retres['success']=1;
			$retres['countries']=$result;
			
		}else{
				$retres['success']=0;
				$retres['msg']="No records found.!!!";
				
		}
		$retres=json_encode($retres);
		echo $retres;
	}
//==============================================================================================================================================================================

//==========================================================================get states=============================================================================================
	public function state($name)
	{
		$Name = utf8_decode(urldecode($name));
		$result = $this->assetsapi_model->getStates($Name);
		$retres = array();
		if($result)
		{
			$retres['success']=1;
			$retres['states']=$result;
			
		}else{
				$retres['success']=0;
				$retres['msg']="No records found.!!!";
				
		}
		$retres=json_encode($retres);
		echo $retres;
	}
		public function state_list()
		{
			
			$query = $this->db->get('states');
			$result = $query->result_array();
			$retres = array();
			if(count($result)>0)
			{
				$retres['success']=1;
				$retres['states']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
			$retres=json_encode($retres);
			echo $retres;
		}
//==============================================================================================================================================================================

//=====================================================================================get cities==========================================================================
	public function city($name)
	{
		$Name = utf8_decode(urldecode($name));
		$result = $this->assetsapi_model->getCities($Name);
		$retres = array();
		if($result)
		{
			$retres['success']=1;
			$retres['cities']=$result;
			
		}else{
				$retres['success']=0;
				$retres['msg']="No records found.!!!";
				
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	public function city_list()
	{
		$query = $this->db->get('cities');
			$result = $query->result_array();
		$retres = array();
		if($result)
		{
			$retres['success']=1;
			$retres['cities']=$result;
			
		}else{
				$retres['success']=0;
				$retres['msg']="No records found.!!!";
				
		}
		$retres=json_encode($retres);
		echo $retres;
	}
//=================================================================================================================================================================
//=================================================================================================================================================================

//========================================Static count service provider=======================================
	public function statics_service_provider($user_id,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->statics_service_provider($user_id);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['statics']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No statics found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	
	public function recent_resolved_request($user_id,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->recent_resolved_request($user_id);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['recent_resolve_request']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No Data found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
		
	}
	//===============================================================================================================
	
	//==========================================Singular Bill Pay Enroll=====================================
	public function singularbill_enroll()
	{
			$request = json_decode(file_get_contents('php://input'), true);
			
			$partnerkey = $this->config->item('partnerkey');
			$partnerid = $this->config->item('partnerid');
			
			$email = (isset($request["email"])?$request["email"]:'');
			$dba_name = (isset($request["dba_name"])?$request["dba_name"]:'');
			$legal_name = (isset($request["legal_name"])?$request["legal_name"]:'');
			$business_address_line_1 = (isset($request["business_address_line_1"])?$request["business_address_line_1"]:'');
			$business_address_line_2 = (isset($request["business_address_line_2"])?$request["business_address_line_2"]:'');
			$business_city = (isset($request["business_city"])?$request["business_city"]:'');
			$business_state_province = (isset($request["business_state_province"])?$request["business_state_province"]:'');
			$business_postal_code = (isset($request["business_postal_code"])?$request["business_postal_code"]:'');
			$business_phone_number = (isset($request["business_phone_number"])?$request["business_phone_number"]:'');
			$principal_first_name = (isset($request["first_name"])?$request["first_name"]:'');
			$last_name = (isset($request["last_name"])?$request["last_name"]:'');
			$principal_middle_name = (isset($request["principal_middle_name"])?$request["principal_middle_name"]:'');
			$fed_tax_id = (isset($request["fed_tax_id"])?$request["fed_tax_id"]:'');
			$ownership_type = (isset($request["ownership_type"])?$request["ownership_type"]:'');
			$website = (isset($request["website"])?$request["website"]:'');
			$business_category = (isset($request["business_category"])?$request["business_category"]:'');
			$business_type = (isset($request["business_type"])?$request["business_type"]:'');
			$business_description = (isset($request["business_description"])?$request["business_description"]:'');
			$mcc = (isset($request["mcc"])?$request["mcc"]:'');
			$swiped_percent = (isset($request["swiped_percent"])?$request["swiped_percent"]:'');
			$keyed_percent = (isset($request["keyed_percent"])?$request["keyed_percent"]:'');
			$ecommerce_percent = (isset($request["ecommerce_percent"])?$request["ecommerce_percent"]:'');
			$cc_average_ticket_range = (isset($request["cc_average_ticket_range"])?$request["cc_average_ticket_range"]:'');
			$cc_monthly_volume_range = (isset($request["cc_monthly_volume_range"])?$request["cc_monthly_volume_range"]:'');
			$ec_average_ticket_range = (isset($request["ec_average_ticket_range"])?$request["ec_average_ticket_range"]:'');
			$ec_monthly_volume_range = (isset($request["ec_monthly_volume_range"])?$request["ec_monthly_volume_range"]:'');
			$city = (isset($request["city"])?$request["city"]:'');
			$zip_code = (isset($request["zip_code"])?$request["zip_code"]:'');
			$mobile_no = (isset($request["mobile_no"])?$request["mobile_no"]:'');
			$principal_date_of_birth = (isset($request["principal_date_of_birth"])?$request["principal_date_of_birth"]:'');
			$principal_ownership_percent =(isset($request["principal_ownership_percent"])?$request["principal_ownership_percent"]:'');
			$principal_ssn = (isset($request["principal_ssn"])?substr($request["principal_ssn"], -4):'');
			$account_number = (isset($request["account_number"])?$request["account_number"]:'');
			$routing_number = (isset($request["routing_number"])?$request["routing_number"]:'');
			$account_holder_name = (isset($request["account_holder_name"])?$request["account_holder_name"]:'');
			$principal_title = (isset($request["principal_title"])?$request["principal_title"]:'');
			$principal_address_line_2 = (isset($request["principal_address_line_2"])?$request["principal_address_line_2"]:'');
			$principal_address_line_1 = (isset($request["principal_address_line_1"])?$request["principal_address_line_1"]:'');
			$cc_high_ticket = (isset($request["cc_high_ticket"])?$request["cc_high_ticket"]:'');
			$ec_high_ticket = (isset($request["ec_high_ticket"])?$request["ec_high_ticket"]:'');
			$state =(isset($request["state"])?$request["state"]:'');
			
			$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
			
				"email"=>$email,
				"dba_name"=>$dba_name,
				"legal_name"=>$legal_name,
				"business_address_line_1"=>$business_address_line_1,
				"business_address_line_2"=>$business_address_line_2,
				"business_city"=>$business_city,
				"business_state_province"=>$business_state_province,
				"business_postal_code"=>$business_postal_code,
				"business_phone_number"=>$business_phone_number,
				"principal_first_name"=>$principal_first_name,
				 "principal_last_name"=>$last_name,
				"principal_middle_name"=>$principal_middle_name,
				"principal_title"=>$principal_title,
				"principal_address_line_1"=>$principal_address_line_1,
				"principal_address_line_2"=>$principal_address_line_2,
				"fed_tax_id"=>$fed_tax_id,
				"ownership_type"=>$ownership_type,
				"website"=>$website,
				"business_category"=>$business_category,
				"business_type"=>$business_type,
				"business_description"=>$business_description,
				"mcc"=>$mcc,
				"swiped_percent"=>$swiped_percent,
				"keyed_percent"=>$keyed_percent,
				"ecommerce_percent"=>$ecommerce_percent,
				"cc_average_ticket_range"=>$cc_average_ticket_range,
				"cc_monthly_volume_range"=>$cc_monthly_volume_range,
				"cc_high_ticket"=>$cc_high_ticket,
				"ec_high_ticket"=>$ec_high_ticket,
				"ec_average_ticket_range"=>$ec_average_ticket_range,
				"ec_monthly_volume_range"=>$ec_monthly_volume_range,
				"principal_city"=>$city,
				"principal_state_province"=>$state,
				"principal_postal_code"=>$zip_code,
				"principal_phone_number"=>$mobile_no,
				"principal_date_of_birth"=>$principal_date_of_birth,
				"principal_ownership_percent"=>$principal_ownership_percent,
				"principal_ssn"=>$principal_ssn,
				"account_number"=>$account_number,
				"routing_number"=>$routing_number,
				"account_holder_name"=>$account_holder_name
				
			);
			$jsondata = json_encode($datatosend);
			 log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://api.singularbillpay.com/v1/enroll",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				 CURLOPT_POSTFIELDS => $jsondata,
				 CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);
	
				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				  
				  $responseArr = json_decode($response);
				   //print_r($responseArr);
				    log_message('debug',print_r($response,TRUE));
				}
			 $retres=array();
			 if(count($responseArr)>0)
			 {
					 $retres['success']=1;
					 $retres['msg']='Sub-Mechant Account Initiated Successfully, Key will update soon.!!!';
					 $retres['enroll']=$responseArr;
					 
					 $clientpartnerid = $responseArr->clientpartnerid;
					 $enrollmentlink = $responseArr->enrollmentlink;
					 
					 $responsedata= array('clientpartnerid' => $clientpartnerid,
					 'enrollmentlink' => $enrollmentlink);
					 
					 $DataTostore = $responsedata + $request;
					 
					  $enrollInfo = $this->assetsapi_model->storeEnrollinfo($DataTostore);
					 
					 $retres['enrollInfo']=$enrollInfo;
					  
					 
								
			 }else{
					 $retres['success']=0;
					 $retres['msg']='Somthing went wrong.';
					
				 }
				 $retres=json_encode($retres);
				 echo $retres;
	}
	public function enroll_info($user_id,$session_id){
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->enroll_info($user_id);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['enroll_info']=$result;
				if($result[0]['clientpartnerkey']!=''){
					$var = trim(str_replace('-','',$result[0]['clientpartnerkey']));
					$merchantAccount = substr_replace($var, str_repeat("X", 24), 4, 24);
					$retres['merchantAccount']=$merchantAccount;
				}else{
					$retres['merchantAccount']='';
				}
				
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	
	public function MerchantStatus()
	{
			
			
			 $partnerkey = $this->config->item('partnerkey');
			 $partnerid = $this->config->item('partnerid');
			
			$MerchantStatus = $this->assetsapi_model->getMerchantStatus();
			 // print_r($MerchantStatus);
			
			
			foreach($MerchantStatus as $merch)
			{
				$fed_tax_id = $merch['fed_tax_id'];
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"fed_tax_id"=>$fed_tax_id
				
				);
			  // print_r($datatosend);
			 
			$jsondata = json_encode($datatosend);
			log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://devapi.singularbillpay.com/v1/MerchantStatus",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => $jsondata,
				  CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				   log_message("cURL Error #:", $err);
				} else {
				  log_message('debug',print_r($response,TRUE));
				  $responseArr = json_decode($response);
				  // print_r($responseArr);
				  if(count($responseArr->subaccounts)>0){
					  
				  $ACC = $responseArr->subaccounts;
				     
				  

					  $clientpartnerkey = $ACC[0]->clientpartnerkey;
					  $dbaname = $ACC[0]->dbaname;
					  $status = $ACC[0]->status;
					  $statusmessage = $ACC[0]->statusmessage;
					  
					  $dataToUpdate = array(
					  'clientpartnerkey'=>$clientpartnerkey,
					  'sub_dbaname'=>$dbaname,
					  'sub_status'=>$status,
					  'sub_statusmessage'=>$statusmessage
					  );
					  // print_r($dataToUpdate);
					$update=$this->db->update('enroll_submerchant_tb',$dataToUpdate,array('fed_tax_id'=>$fed_tax_id)); 
				  }else{
					  log_message('debug', 'Due to some error subaccount not created... ');
				  }
				  }
				  
				 
			}
			// print_r($client_partner_id);
			 
			 
	}
	public function change_merchant_status($id,$status,$session_id){
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				if($status=="Active"){
					$updateStatus = "Inactive";
				}else if($status=="Inactive"){
					$updateStatus = "Active";
				}
				
				$changeStatus = $this->db->update('enroll_submerchant_tb',array('status'=>$updateStatus),array('id'=>$id));
				
					
				
					
					if($changeStatus)
					{
						$retres['success']=1;
						$retres['msg']= "Account status changed.";
						
					}else{
							$retres['success']=0;
							$retres['msg']="Something went wrong.Please try again!!!";
							
					}
				
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	//============================================================================================================
	
	//===============================property search================================================================
	public function property_search_by(){
		$request = json_decode(file_get_contents('php://input'), true);
		$datatopass = array(
			"keyword"=>$request['keyword']
			
		);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->property_search_by($datatopass);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['property_list']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	
	//Start Elakkiya//
	//==============================================Forgot Password======================================================================
	public function forgot_password(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'email'  => $request['email'],
			'assets_type'=>$request['assets_type']
		);
		$ses_id = $this->assetsapi_model->get_session_id($data);
		$session_id = isset($ses_id[0]->session_id)?$ses_id[0]->session_id:'';
		// $url = "www.assetswatch.com/reset_password?id=".$session_id;
		$reacturl = $this->config->item('reacturl');
		 $url = "<br/><a href='".$reacturl."password-reset?id=".$session_id."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Reset Password</a>";
		
		if(!empty($session_id)){
		$record = array(
			'assets_type'		=> $request['assets_type'],
			'email'				=> $request['email'],
			'current_session_id'=> $session_id,
			'status'			=> 'pending',
			'created_date' 		=> date('Y-m-d H:i:s')
		);
		$ins_rec = $this->assetsapi_model->insert_forgot_password_status($record);
		
			$result['success'] = 1;
			$result['url'] = $url;
				
				$to_email = $request['email'];
				$from_email = "info@assetswatch.com";
				//========================Mail======================================================================
				$filename = 'forget_password.txt';
				$template = read_file('assets/email_template/'.$filename);
				$subject = "Forget Password";
				
				$tokensArr = array(
				 'URL'=> trim($url)
				);
				$mail = $this->send_mail($from_email,$to_email,$subject,$tokensArr,$template);
				if($mail){
					$result['success'] = 1;
					$result['msg'] = "Password reset link sended to your email.!!!";
				}else{
					$result['success'] = 0;
					$result['msg'] = "Somthing went wrong. Please try later!!!";
				}
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Unauthorised User.!!!";
		}
		echo json_encode($result);
	}
	public function change_password(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'password' 	=> $request['password'],
			'session_id' 	=> $request['session_id'],
		);
		$email = $this->assetsapi_model->get_email($data['session_id']);
		
		if(!empty($email)){
			$rec = array(
					'email' => $email[0]->email,
					'password' 	=> $request['password'],
					'session_id' 	=> $request['session_id']
				);
			
				$upd_pwd = $this->assetsapi_model->update_password($rec);
				if($upd_pwd==1){
					$upd_status = $this->db->delete('forgot_password_status_tb',array('current_session_id'=>$request['session_id']));
					$result['success'] = 1;
					$result['msg'] = "Password Updated Successfully";
				}else{
					$result['success'] = 0;
					$result['msg'] = "This link is expired. Please request for new link.!!!";
				}
			
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Unauthorised User.!!!";
		}
		echo json_encode($result);
	}
	
	public function forget_pass_data($session_id)
	{
		$fPassQuery = $this->db->get_where('forgot_password_status_tb',array('current_session_id'=>$session_id));
			if($fPassQuery->num_rows()>0)
			{
				$result['success'] = 1;
				
			}
			else{
					$result['success'] = 0;
					$result['msg'] = "This link is expired. Please request for new link.!!!";
				}
			echo json_encode($result);
	}
	//==============================================Owner-agent rating======================================================================
	public function rating(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'owner_id'	=> $request['user_id'],
			'agent_id'	=> $request['agent_id'],
			'rating' 	=> $request['rating'],
			'feedback' 	=> $request['feedback'],
			'created_date'=>date("Y-m-d H:i:s")
			);
			$rating = $this->assetsapi_model->insert_rating($data);
			
			if($rating){
				$result['success'] = 1;
				$result['msg'] = "Rated Successfully";
			}else{
				$result['success'] = 0;
				$result['msg'] = "Something went wrong. Please try again !!! ";
			}
			
			echo json_encode($result);
	}
	//==============================================Get Owner's relevant service provider ==========================================================
	public function get_serviceprovider(){
		$request = json_decode(file_get_contents('php://input'), true);
		$owner_id = $request['owner_id'];
		$sp_id = $this->assetsapi_model->get_serviceprovider_by_owner($owner_id);
		$id = explode(',',$sp_id);
		
		foreach($id as $assets_id){
			$agent = $this->assetsapi_model->get_serviceprovider($assets_id);
			if($agent!='')
				$result[] = $agent;
		}
		if($sp_id){
			if($result){
				$output['success'] = 1;
				$output['service_provider'] = $result;
			}else{
				$output['success'] = 0;
				$output['msg'] = "No records found ";
			}
		}else{
			$output['success'] = 0;
			$output['msg'] = "Something went wrong. Please try again !!! ";
		}
		echo json_encode($output);
	}
	//==============================================Insert service request ==========================================================
	public function add_service_request(){
		$request = json_decode(file_get_contents('php://input'), true);
		
		$deal = $this->assetsapi_model->get_deal_id($request['property_id']);
		if(!empty($deal)){
		$data = array(
			'deal_id'			=> $deal->deal_id,
			'send_by'			=> $request['user_id'],
			'service_provider'	=> $request['service_provider'],
			'service_msg' 		=> $request['description'],  
			'service_photo' 	=> $request['service_photo'],
			'service_status' 	=> 0,
			'entry_date'		=>date("Y-m-d H:i:s")
			); 
		$service_request = $this->assetsapi_model->insert_service_request($data);
		
			if($service_request){
				$result['success'] = 1;
				$result['msg'] = "Service request added Successfully";
			}else{
				$result['success'] = 0;
				$result['msg'] = "Something went wrong. Please try again !!! ";
			}
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Something went wrong. Please try again !!! ";
		}
		
		echo json_encode($result);
	}
	//============================================== Property Report ==========================================================
	public function property_report(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'property_id' 	=> $request['property_id'],
			'user_id' 		=> $request['user_id'],
			'from_date' 	=> date("Y-m-d H:i:s",strtotime($request['from_date'])),
			'to_date' 		=> date("Y-m-d H:i:s",strtotime($request['to_date']))
		);
			$report = $this->assetsapi_model->get_property_report($data);
			if($report){
				$result['success'] = 1;
				$totAmt = 0;
				foreach($report as $val)
				{
					$totAmt = (float) str_replace(',', '', $totAmt) + (float) str_replace(',', '', $val['transactionamount']);
				}
				$result['report'] = $report;
				$result['totalAmt'] = number_format($totAmt, 2);
			}else{
				$result['success'] = 0;
				$result['msg'] = "No records found";
			}
			echo json_encode($result);
	}
	//============================================== Transaction Report ==========================================================
	public function transaction_report(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id'],
			'trans_for' 		=> $request['trans_for'],
			'from_date' 	=> date("Y-m-d H:i:s",strtotime($request['from_date'])),
			'to_date' 		=> date("Y-m-d H:i:s",strtotime($request['to_date']))
		);
		$report = $this->assetsapi_model->get_transaction_report($data);
		if($report){
			$result['success'] = 1;
			$result['report'] = $report;
		}else{
			$result['success'] = 0;
			$result['msg'] = "No records found";
		}
		echo json_encode($result);
	}
	
		public function download_trans_invoice_report($invoiceId){


					$InvoiceFilename = 'invoice_template_transaction.txt';
					$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
					
					$transData = $this->assetsapi_model->getTransactionBy($invoiceId);
					
					 $transactionamount = $transData[0]['transactionamount'];
					  if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					 if($transData[0]['trans_for']=="Agreement Purchase"){
						 $this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('agreement_purchase_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('agreement_tb a','a.agreement_id=B.agreement_id','LEFT');
							$this->db->where('invoice_number',$invoiceId);
							$Agquery = $this->db->get();
							$AgRslt = $Agquery->result_array();
							  // print_r($AgRslt);
						  $title = $transData[0]['trans_for'];
						  $relatedTitle = "Agreement";
						  $relatedName = $AgRslt[0]['agreement_title'];
					 }else if($transData[0]['trans_for']=="Upgrade"){
						
						  $title = 'Plan Upgrade';
						   $relatedTitle ="Plan Name" ;
						  $relatedName = $PlanName;
					 }else if($transData[0]['trans_for']=="Register"){
						  $title = 'Register';
						   $relatedTitle = "Plan Name";
						  $relatedName = $PlanName;
					 }else if($transData[0]['trans_for']=="BGV"){
							$this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('background_verification_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('bgv_package_tb p','p.packageId=B.selected_package','LEFT');
							$this->db->join('registration_tb r','r.assets_id=B.user_id','LEFT');
							$this->db->where('invoice_number',$invoiceId);
							$Bgvquery = $this->db->get();
							 $bgvRslt = $Bgvquery->result_array();
							  // print_r($bgvRslt);
							$Bname = $bgvRslt[0]['first_name'].' '.$bgvRslt[0]['last_name'];
						$title = 'BGV for '.$Bname;
						$relatedTitle = "BGV Package";
						$relatedName = $bgvRslt[0]['package'];
					 }
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
					 
					$InvoiceTokensArr = array(
					'PAYEE_NAME' => $payeeName,
					'PAYEE_ADDRESS' => $payeeaddress,
					'PAYEE_MOBILE' => $payeeMobile,
					'PAYEE_EMAIL' => $payeeEmail,
					// 'Billed_BY_NAME' => $Billed_BY_NAME,
					// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
					// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
					// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
					 // 'PAID_FOR'=> $paidFor,
					 // 'PAID_FOR_MONTH'=> $paid_for_month,
					 'RELATED_TITLE'=>$relatedTitle,
					  'RELATED_NAME'=>$relatedName,
					 'AMOUNT'=> number_format($actualAmt,2),
					  'TITLE'=> $title,
					 'TAX_AMOUNT'=> number_format($TaxAmount,2),
					 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
					 'INVOICE'=>$invoiceId,
					 'INVOICE_DATE'=>$transactiondate
					);
					$pattern = '[%s]';
				
					foreach($InvoiceTokensArr as $key=>$val){
						$varMap[sprintf($pattern,$key)] = $val;
					}
					$Template = strtr($InvoiceTemplate,$varMap);
					//print_r($Template);
					 $dompdf = new Dompdf\Dompdf();
				 
						// (Optional) Setup the paper size and orientation
						// print_r($Template);

						$dompdf->loadHtml($Template);
						$dompdf->set_option('isHtml5ParserEnabled', true);
						$dompdf->set_option('isRemoteEnabled', TRUE);
						$dompdf->setPaper('A4', 'landscape');
						// Render the HTML as PDF
						$dompdf->render();
				 
						// Get the generated PDF file contents
						$pdf = $dompdf->output();
				 
						// Output the generated PDF to Browser
						$dompdf->stream(); 
						
 }
 public function download_property_invoice_report($invoiceId){


					$InvoiceFilename = 'invoice_template.txt';
					$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
					
					$transData = $this->assetsapi_model->getPropTransactionBy($invoiceId);
					
					 $transactionamount = $transData[0]['transactionamount'];
					  if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					
					
					 //$TotAmount = (float) str_replace(',', '', $transactionamount) + (float) str_replace(',', '', $TaxAmount);
					 $paidFor = $transData[0]['paid_for'];
					 $transactiondate = $transData[0]['transactiondate'];
					 
					$PayBy = $transData[0]['paid_by'];

						 $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
						
					$payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					 $paid_for_month = $transData[0]['paid_for_month']?($transData[0]['paid_for_month']).", ".date('Y',strtotime($transactiondate)):date('M, Y',strtotime($transactiondate));
					 
					 $dealInfo = $this->assetsapi_model->deal_agreement_pdf_view($transData[0]['deal_id']);
					 $propertyId = $dealInfo[0]['property_id'];
					 
					 $this->db->select("*");
					$query = $this->db->get_where('property_payment_check',array('user_id'=>$transData[0]['payee_id'],'property_id'=>$propertyId,'status'=>'Active'));
					$rslt = $query->result_array();
					if(count($rslt)>0){
						$paid_to = $rslt[0]['paid_to'];
					
						$paidToProfile = $this->assetsapi_model->profile($paid_to);
						
						$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
						 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
						
						$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
						$Billed_BY_EMAIL = $paidToProfile['email'];
					
					}else{
						$dataProperty = $this->assetsapi_model->property_details($propertyId);
						$paid_to = $dataProperty[0]['owner_id'];
					
						$paidToProfile = $this->assetsapi_model->profile($paid_to);
						$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
						 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
						$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
						$Billed_BY_EMAIL = $paidToProfile['email'];
					}
					
					$this->db->select("*");
					$query1 = $this->db->get_where('property_tb',array('id'=>$propertyId,'status'=>'1'));
					$rslt1 = $query1->result_array();
					// echo $this->db->last_query();
					// print_r($rslt1);
					$property = $rslt1[0]['title'];
					$RENT_PAID_DATE = date('m/d/Y H:i:s',strtotime($transactiondate));
					$InvoiceTokensArr = array(
					'PAYEE_NAME' => $payeeName,
					'PAYEE_ADDRESS' => $payeeaddress,
					'PAYEE_MOBILE' => $payeeMobile,
					'PAYEE_EMAIL' => $payeeEmail,
					'Billed_BY_NAME' => $Billed_BY_NAME,
					'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
					'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
					'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
					 'PAID_FOR'=> $paidFor,
					 'PAID_FOR_MONTH'=> $paid_for_month,
					 'RENT_PAID_DATE'=> $RENT_PAID_DATE,
					 'AMOUNT'=> number_format($actualAmt,2),
					 'PROPERTY'=> $property,
					 'TAX_AMOUNT'=> number_format($TaxAmount,2),
					 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
					 'INVOICE'=>$invoiceId,
					 'INVOICE_DATE'=>$transactiondate
					);
					$pattern = '[%s]';
				
					foreach($InvoiceTokensArr as $key=>$val){
						$varMap[sprintf($pattern,$key)] = $val;
					}
					$Template = strtr($InvoiceTemplate,$varMap);
					 //print_r($Template);
			
				 	  $dompdf = new Dompdf\Dompdf();
				 
						// (Optional) Setup the paper size and orientation
						// print_r($Template);
						 
						$dompdf->loadHtml($Template);
						$dompdf->set_option('isHtml5ParserEnabled', true);
						$dompdf->set_option('isRemoteEnabled', TRUE);
						$dompdf->setPaper('A4', 'landscape');
						// Render the HTML as PDF
						$dompdf->render();
				 
						// Get the generated PDF file contents
						$pdf = $dompdf->output();
				 
						// Output the generated PDF to Browser
						$dompdf->stream();   
						
 }
	//============================================== Contact Report ==========================================================
	public function contact_report(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id'],
			'from_date' 	=> date("Y-m-d H:i:s",strtotime($request['from_date'])),
			'to_date' 		=> date("Y-m-d H:i:s",strtotime($request['to_date']))
		);
		$report = $this->assetsapi_model->get_contact_report($data);
		if($report){
			$result['success'] = 1;
			$result['report'] = $report;
		}else{
			$result['success'] = 0;
			$result['msg'] = "No records found";
		}
		echo json_encode($result);
	}
	//======================================================== Search API ============================================================
	public function search_api(){
		$request = json_decode(file_get_contents('php://input'), true);
		$keyword 		= isset($request['keyword']) ? $request['keyword'] : '';
		$property_type 	= isset($request['property_type']) ? $request['property_type'] : '';
		$city 			= isset($request['city']) ? $request['city'] : '';
		$property_status= isset($request['property_status']) ? $request['property_status'] : '';
		$area 			= isset($request['area']) ? $request['area'] : '';
		$zip_code 		= isset($request['zip_code']) ? $request['zip_code'] : '';
		
		$propertyData = array(
			'keyword' 		 => $keyword,
			'city' 			 => $city,
			'property_type'  => $property_type,
			'property_status'=> $property_status,
			'area' 			 => $area,
			'zip_code' 		 => $zip_code,
			'owner_id'		 => $request['owner_id']
		);
		$report = $this->assetsapi_model->property_search_by_user($propertyData);
		if($report){
			$result['success'] = 1;
			$result['report'] = $report;
		}else{
			$result['success'] = 0;
			$result['msg'] = "No records found";
		}
		echo json_encode($result);
	}
	//======================================================== BGV  ============================================================
	public function User_background_verification(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 			=> $request['user_id'],
			'selected_package' 	=> $request['package'],
			'created_date' 		=> date("Y-m-d H:i:s")
		);
		if(!empty($data['user_id'])){
		$record = $this->assetsapi_model->add_bgv($data);
		
			$result['success'] = 1;
			$result['msg'] = "Details Added Successfully";
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Something went wrong. Please try again !!! ";
		}
		echo json_encode($result);
	}
	//================================================= BGV document============================================================
	public function bgv_document(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 			=> $request['user_id'],
			'document' 			=> $request['document']
			);
		$record = $this->assetsapi_model->update_bgv_document($data);
		if($record){
			$result['success'] = 1;
			$result['msg'] = "Document Updated Successfully";
		}else{
			$result['success'] = 0;
			$result['msg'] = "Invalid user_id";
		}
		echo json_encode($result);
	}
	//=================================================Download BGV document============================================================
	public function download_bgv_document(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 			=> $request['user_id'],
			'document' 			=> $request['document']
			);
		$bgv = $this->assetsapi_model->find_bgv_document($data);
		if($bgv){
			$result['success'] = 1;
			$result['download_url'] = $bgv;
		}else{
			$result['success'] = 0;
			$result['msg'] = "Something went wrong. Please try again !!! ";
		}
		echo json_encode($result);
	}
	//=================================================Payment============================================================
	public function payment_details(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id'],
			'name' 			=> $request['name'],
			'legal_name' 	=> $request['legal_name'],
			'address' 		=> $request['address'],
			'city' 			=> $request['city'],
			'zip_code' 		=> $request['zip_code'],
			'mobile_no' 	=> $request['mobile_no'],
			'email' 		=> $request['email'],
			'first_name' 	=> $request['first_name'],
			'last_name' 	=> $request['last_name'],
			'payment_by'	=> $request['payment_by'], //singlular_billpay, amazon, paypal
			'created_date' 	=> date("Y-m-d H:i:s")
			);
		if(!empty($data['user_id'])){
		$record = $this->assetsapi_model->add_payment_details($data);
		
			$result['success'] = 1;
			$result['msg'] = "Details Added Successfully";
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Something went wrong. Please try again !!! ";
		}
		echo json_encode($result);
	}
	//=================================================card_profile============================================================
	public function card_profile(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id'],
			'name' 			=> $this->assetsapi_model->encrypt_decrypt('encrypt',$request['name']),
			'card_no' 		=> $this->assetsapi_model->encrypt_decrypt('encrypt',$request['card_no']),
			'exp_date' 		=> $this->assetsapi_model->encrypt_decrypt('encrypt',$request['exp_date']),
			'created_date' 	=> date("Y-m-d H:i:s")
			);
		if(!empty($data['user_id'])){
		$record = $this->assetsapi_model->add_card_profile($data);
			$result['success'] = 1;
			$result['msg'] = "Details Added Successfully";
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Something went wrong. Please try again !!! ";
		}
		echo json_encode($result);	
	}
	public function get_card_details(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id']
			);
		$record = $this->assetsapi_model->get_card_details($data);
		if($record){
			$result['success'] = 1;
			$result['data'] = $record;
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Unauthorised user ";
		}
		echo json_encode($result);	
	}
	//---------Start Elakkiya on 11.08.2018---------------------
	
	//================================================ To get Agreement content========================================================
	public function agreement_content(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'deal_id' 		=> $request['deal_id']
			);
		$record = $this->assetsapi_model->get_agreement_content($data);
		if($record){
			$result['success'] = 1;
			$result['data'] = $record;
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "Invalid deal_id";
		}
		echo json_encode($result);	
	}
	//=================================================== Agreement Acceptance =========================================
	public function agreement_acceptance(){
		$request = json_decode(file_get_contents('php://input'), true);
		$verData = $this->assetsapi_model->get_version_agreement($request['deal_id']);
		$version = $verData[0]['version_name'];
		$strReplace = trim(str_replace('AWG_V','',$version));
		$actualversion = 'AWG_V'.($strReplace + 1);
		
		$data = array(
			'deal_id' 			=> $request['deal_id'],
			'comment' 			=> $request['comment'],
			'user_id' 			=> $request['user_id'],
			'agreement_content' => $request['agreement_content'],
			'div_id' 			=> $request['div_id'],
			'signature_content' => $request['signature_content'],
			'signature_type' 	=> $request['signature_type'],
			'acceptance_status' => '1', //Submitted
			'created_date'		=> date("Y-m-d H:i:s"),
			'version_name'		=> $actualversion
			);
			
		$record = $this->assetsapi_model->agreement_acceptance($data);
		if($record){
			$result['success'] = 1;
			$result['msg'] = 'Agreement Accepted Successfully';
			
			$datatoupdate = array(
			'replaced_template' 	=> $request['agreement_content'],
			'status' => 'Inprocess'
			);
			$this->db->update('property_deal_tb',$datatoupdate,array('deal_id'=>$request['deal_id']));
					$dealDetail = $this->assetsapi_model->getDealInfo($request['deal_id']);
					$profileSender = $this->assetsapi_model->profile($request["user_id"]);
					$SenderAssets_type  = $profileSender['assets_type'];
					$senderAssetsType = $this->assetsapi_model->getAssetsType($SenderAssets_type);
					$SenderName  = $profileSender['first_name'].' '.$profileSender['last_name'];
					$notiData = array(
										'sender'=>$request['user_id'],
										'receiver'=>$dealDetail[0]['sender_id'],
										'message' => $senderAssetsType.' '.$SenderName.' signed agreement.'
										
									);
					$notifyInsert = $this->db->insert('notification_tb',$notiData);
		}
		else{
			$result['success'] = 0;
			$result['msg'] = "No input";
		}
		echo json_encode($result);	
	}
	//================================================ Owner submitted deal  ==================================================
	public function get_submitted_deal(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'user_id' 		=> $request['user_id']
			);
		$record = $this->assetsapi_model->get_submitted_deal($data);
		if(!empty($record)){
			$deal_id = explode(',',$record->deal_id);
			foreach($deal_id as $id){
				$res[] = $this->assetsapi_model->fetch_submitted_deal($id);
			}
			
			if($res){
				$result['success'] = 1;
				$result['data'] = $res;
			}
			else{
				$result['success'] = 0;
				$result['msg'] = "Invalid Userid";
			}
		}else{
			$result['success'] = 0;
			$result['msg'] = "Invalid Userid";
		}
		
			echo json_encode($result);	
	}
	//======================================= View Submitted deal ============================================
	public function view_submitted_deal(){
		$request = json_decode(file_get_contents('php://input'), true);
		$data = array(
			'id' 		=> $request['id']
			);
		$agreement_version = $this->assetsapi_model->view_submitted_data($data);
		if($agreement_version){
		 	$result['success'] = 1;
		 	$result['data'] = $agreement_version;
		 }
		 else{
		 	$result['success'] = 0;
		 	$result['msg'] = "Invalid input";
		 }
		 echo json_encode($result);
	}
	//======================================== Download Agreement PDF ===========================================
	public function  download_agreement($deal_id){
		// $request = json_decode(file_get_contents('php://input'), true);	
		// $data = array(
			// 'deal_id' 		=> $request['deal_id']
		// );
		$record = $this->assetsapi_model->get_agreement($deal_id);
		 $sender_id = $record->sender_id;
		// $agreement ='';
		// $agreement .= '<div class="col-md-12" align="center" style="text-align:center;text-transform: uppercase; text-decoration: underline;"><h1>'.$record->agreement_title.'</h1></div>';
		// $agreement .= '<div class="col-md-12" align="center" style="text-align:justify; line-spacing: 2px; font-size: 20px;">'.$record->agreement_content.'</div>'; 
		// $agreement .= '<div class="col-md-12" align="right">'.$record->signature_content.'</div>';
		
			// Create a new PDF but using our own class that extends TCPDF
			$pdf = new MyCustomPDFWithWatermark(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
			
			$brandingData = $this->assetsapi_model->getBrandingInfo($sender_id);
			// print_r($brandingData);
			
			if($brandingData){
				$branding = $brandingData['branding'];
					$headerContent = $brandingData['header_title'];
					$footerContent = $brandingData['footer_title'];
					$headerImage = $brandingData['branding_logo'];
					$watermarkImage = $brandingData['branding_watermark'];
			}else{
				$branding = 'Default';
				$headerContent = '';
				$footerContent = '';
				$headerImage = '';
				$watermarkImage = '';
			}
			
			
			$html = $record->replaced_template;
			$template = array('headerContent'=>$headerContent,'footerContent'=>$footerContent,'headerImage'=>$headerImage,'watermarkImage'=>$watermarkImage,'branding'=>$branding);

			//echo $headerImage;
			 // print_r($template);
			 // exit();
			$pdf->setData($template);
			
			$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
			
			// set header and footer fonts
				$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
				$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

				// set default monospaced font
				$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
			
			// set margins
			$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
			$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
			$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
			
			$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);//, 70,120, 57, 25, '', '', '', false, 300, '', false, false, 0);
			
			$pdf->SetFont('times', '', 8, '', false); 
				
			$pdf->AddPage();
			$pdf->writeHTML($html, true, false, true, false, '');
			ob_clean();
			
			$fileName = $record->agreement_unique_id.'.pdf';
			 $pdf->Output($fileName,'D');
			

			/* $pdf->writeHTML($agreement, true, false, true, false, '');
			$path = "/";
			$filename = "Agreement_".$request['deal_id']=1;
			$folderPath = mkdir($path, 0777, true);
			$pdfFilePath = APPPATH.'../'.$path.$filename.'.pdf';
			 ob_clean();
			  $pdfgenerated = $pdf->Output($pdfFilePath, 'I'); */
			 
		}
		
		//===============================Unsubscribe Plan============================================
		public function unsubscribe_plan($user_id,$assetsTypeId,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$profile = $this->assetsapi_model->profile($user_id);
				$planName = $profile['planName'];
				$retres = array();
				if($planName=='Basic')
				{
					$retres['success']=0;
					$retres['msg']="Already In Basic Plan!!!";
				}else{
					
					$result = $this->assetsapi_model->unsubscribe_plan($user_id,$assetsTypeId);
					
					if($result)
					{
						$retres['success']=1;
						$retres['msg']= "Unsubscribe successfully.";
						
					}else{
							$retres['success']=0;
							$retres['msg']="Something went wrong.Please try again!!!";
							
					}
				}
				
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
		}
	
//==============================Notification UserList ================================================	
		public function userlist_notification($user_id,$assets_type,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->userlist_notification($user_id,$assets_type);
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['userlist']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		//=================================get Agreement template==================================================
		
		public function agreement_template_name($session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->agreement_template_name();
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['template_list']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
		}
		public function agreement_template_detail($template_id,$session_id)
		{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->agreement_template_detail($template_id);
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['template_detail']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
		}
	//=========================================contact info for contact us page =============================
		public function contactinfo()
		{
			
				$result = $this->assetsapi_model->contactinfo();
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['contactinfo']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function social_links(){
			$data['googleloginURL'] = $this->google->loginURL();
         //linkedin
		 $data['linkedinURL'] = $this->config->item('linkedin_redirect_url').'?oauth_init=1';
		 $data['fblogoutURL'] = $this->facebook->logout_url();
          $data['fbauthURL'] =  $this->facebook->login_url();
		   $data['twitterUrl'] = $this->config->item('alternate_url').'assetsapi/twitter';
		   $retres['data']=$data;
		   $retres=json_encode($retres);
			echo $retres;
		}
		 
		public function change_status_execute()
		{
			$request = json_decode(file_get_contents('php://input'), true);
			
			
			$agreementData = array(
				'property_id'=>$request['property_id'],
				 'user_id'=>$request['user_id'],
				 'status'=>$request['status']
				);
				
				$retres=array();
			
				$result = $this->assetsapi_model->change_status_execute($agreementData);
				if($result)
				{
					$retres['success']=1;
					// if($request['status']==="Completed"){
						$retres['msg']="Agreement ".$request['status']." successfully. !!!";
					// }
					
					$dealDetailQ = $this->db->get_where('property_deal_tb',array('sender_id'=>$request['user_id'],'property_id'=>$request['property_id'],'status'=>'Completed'));
					$dealDetail = $dealDetailQ->result_array();
					foreach($dealDetail as $val){
						$profileSender = $this->assetsapi_model->profile($val['receiver_id']);
						$SenderAssets_type  = $profileSender['assets_type'];
						$senderAssetsType = $this->assetsapi_model->getAssetsType($SenderAssets_type);
						$SenderName  = $profileSender['first_name'].' '.$profileSender['last_name'];
						$notiData = array(
											'sender'=>$request['user_id'],
											'receiver'=>$val['receiver_id'],
											'message' => $SenderName.' has '.$request["status"].' property agreement.'
											
										);
						$notifyInsert = $this->db->insert('notification_tb',$notiData);
					}
					
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Somthing went wrong please try again.!!!";
					
				}
		
			$retres=json_encode($retres);
			echo $retres;
		}
	
	//===========================user search =====================================
	public function user_search($request=array())
	{
		
		$request = json_decode(file_get_contents('php://input'), true);
		$datatopass = array(
			"assets_type"=>$request['assets_type'],
			"keyword"=>$request['keyword']
		);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->user_search($datatopass);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['search_userlist']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	
	//========================rating DEtail ===================================
	public function rating_detail($id,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->rating_detail($id);
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['rating_detail']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			}else{
						$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=======================swith user type=================================
	public function switch_usertype($request=array())
	{
		
		$request = json_decode(file_get_contents('php://input'), true);
		
			$result = $this->assetsapi_model->switch_usertype($request);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['userType']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		
		$retres=json_encode($retres);
		echo $retres;
	}
	
	//=======================Background Verification=================================
	public function background_verification($request=array())
	{
		
		 $request = json_decode(file_get_contents('php://input'), true);  
		
			
			$partnerkey = $this->config->item('partnerkey');
			$partnerid = $this->config->item('partnerid');
			$transactiontype = $this->config->item('transactiontype');
			
			$randNumber = mt_rand(100000, 999999);
			$orderid = 'TXN'.$randNumber;
			$this->session->set_userdata('orderid', $orderid);
			 $userData = $this->assetsapi_model->profile($request["login_user_id"]);
			//$planData = $this->assetsapi_model->planDeatilBy($plan_id);
			/* $plan_id = $userData['plan_id'];
			$first_name = $userData['first_name'];
			$last_name = $userData['last_name'];
			$address = $userData['city']." ".$userData['state']." ".$userData['country']." ".$userData['zip_code'];
			$city = $userData['city'];
			$state = $userData['state'];
			$country = $userData['country'];
			$zip = $userData['zip_code'];
			$email = $userData['email'];  */
			//$orderid = $this->session->userdata('orderid');
			//$explodeName = explode(' ' ,$_POST['name'])
			//$firstName = (!empty($explodeName[0]))?$explodeName[0]:'';
			//$lastName = (!empty($explodeName[1]))?$explodeName[1]:'';
			//$expirymmyy = date('m',strtotime($_POST['month'])).date('y',strtotime($_POST['year']));
						
			$state = $request["state"];
			$StateCodeQ = $this->db->get_where('uvw_country_states',array('state_name'=>$state));
			$stateRslt = $StateCodeQ->result_array();
			if(count($stateRslt)){
				$stateCode = $stateRslt[0]['state_2_code'];
			}else{
				$stateCode = '';
			}
						
			$country = $request["country"];
			$CountryQuery = $this->db->get_where('countries',array('name'=>$country));
			$countryRslt = $CountryQuery->result_array();
			if(count($countryRslt)>0){
				$countryCode = $countryRslt[0]['sortname'];
			}else{
				$countryCode = '';
			}
			if($request['type']==='CC')
			{
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"expirymmyy"=>$request["expirymmyy"],
				"cvv"=>$request["cvv"],
				"paymentmode"=>$request["paymentmode"],

				"transactionamount"=>$request["amount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$request["first_name"],
				"payeelastname"=>$request["last_name"],
				"address"=>$request["address"],
				"city"=>$request["city"],
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$request["zip_code"],
				"email"=>$request["email"],
				"transactionreference"=>$request["transactionreference"],
				 "orderid"=>$orderid,
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}else if($request['type']==='ACH'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$request["first_name"],
				"payeelastname"=>$request["last_name"],
				"address"=>$request["address"],
				"city"=>$request["city"],
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$request["zip_code"],
				"email"=>$request["email"],
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$orderid,
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}
			
			$this->db->order_by('transactiondate',"desc");
						$this->db->limit(1);
						$query = $this->db->get('transaction_tb');
						 $lastRecord = $query->result_array();
					  if($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null ){
						  $inv = $lastRecord[0]['invoice_number'];
						  
						    $inv_number = ++$inv;
					  }else{
						  $inv_number = 'AWLLC000001';
					  }
					  
					   $invoice_number = $inv_number;
					   $datatoinsertTrans = array( 
									'invoice_number' => $invoice_number,
									'user_id'=>$request["login_user_id"],
									 'plan_id'=> $userData['plan_id'],
									'orderid'=> $orderid,
									// 'plan_amount'=>$request["amount"],
									// 'transactionid'=>$responseArr->transactionid,
									// 'paymentmode'=>$responseArr->paymentmode,
									// 'transaction_type'=>$responseArr->transactiontype,
									// 'transactionamount'=>$responseArr->transactionamount,
									// 'transactionreference'=>$responseArr->transactionreference,
									// 'responsecode'=>$responseArr->responsecode,
									// 'responsestatus'=>$responseArr->responsestatus,
									// 'responsemessage'=>$responseArr->responsemessage,
									// 'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
									'trans_for'=>'BGV',
									'paid_by'=>$request['type'],
									'actual_amt'=>$request['actual_amt'],
									'tax_amt'=>$request['extraAmt']
									
					   );
					   // print_r($datatoinsertTrans);
					 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					$insertTrans = $this->db->insert('transaction_tb',$datatoinsertTrans);
					$tx_id = $this->db->insert_id();
			// print_r($datatosend);
			//exit();
			$jsondata = json_encode($datatosend);
			log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://api.singularbillpay.com/v1/transaction",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				 CURLOPT_POSTFIELDS => $jsondata,
				 CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
				  // echo "response : ".$response;
				  //print_r($response);
				  // $txn_id = $this->session->userdata('txn_no');
				  log_message('debug',print_r($response,TRUE));
				  $responseArr = json_decode($response);
				  if(count($responseArr)>0 ){
				  if($orderid == $responseArr->orderid )
				  {
					  $datatoupdate = array( 
									
									'plan_amount'=>$request["amount"],
									'transactionid'=>$responseArr->transactionid,
									'paymentmode'=>$responseArr->paymentmode,
									'transaction_type'=>$responseArr->transactiontype,
									'transactionamount'=>$responseArr->transactionamount,
									'transactionreference'=>$responseArr->transactionreference,
									'responsecode'=>$responseArr->responsecode,
									'responsestatus'=>$responseArr->responsestatus,
									'responsemessage'=>$responseArr->responsemessage,
									'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate))
									
									
					   );
					   // print_r($datatoinsertTrans);
					  $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					  
					
						if($insertTrans){
							
							//========================Mail Invoice====================================================
					$settingInfo = $this->assetsapi_model->getEmailSmsSettingInfo($request["login_user_id"]);
					
					if($settingInfo){
						if($settingInfo['email']==='ON'){
							$to_email = $request["email"];
							$from_email = "info@assetswatch.com";
							$InvoiceFilename = 'invoice_template_transaction.txt';
							$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
							$InvoiceSubject = "Invoice For Background Verification";
							
							$transactionamount = $responseArr->transactionamount;
							$transData = $this->assetsapi_model->getTransactionBy($invoiceId);
					
					 //$transactionamount = $transData[0]['transactionamount'];
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }

					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					 
							$this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('background_verification_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('bgv_package_tb p','p.packageId=B.selected_package','LEFT');
							$this->db->join('registration_tb r','r.assets_id=B.user_id','LEFT');
							$this->db->where('invoice_number',$invoice_number);
							$Bgvquery = $this->db->get();
							 $bgvRslt = $Bgvquery->result_array();
							  // print_r($bgvRslt);
							$Bname = $bgvRslt[0]['first_name'].' '.$bgvRslt[0]['last_name'];
						$title = 'BGV for '.$Bname;
						$relatedTitle = "BGV Package";
						$relatedName = $bgvRslt[0]['package'];
					 
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
					 
					$InvoiceTokensArr = array(
					'PAYEE_NAME' => $payeeName,
					'PAYEE_ADDRESS' => $payeeaddress,
					'PAYEE_MOBILE' => $payeeMobile,
					'PAYEE_EMAIL' => $payeeEmail,
					// 'Billed_BY_NAME' => $Billed_BY_NAME,
					// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
					// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
					// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
					 // 'PAID_FOR'=> $paidFor,
					 // 'PAID_FOR_MONTH'=> $paid_for_month,
					 'RELATED_TITLE'=>$relatedTitle,
					  'RELATED_NAME'=>$relatedName,
					 'AMOUNT'=> number_format($actualAmt,2),
					  'TITLE'=> $title,
					 'TAX_AMOUNT'=> number_format($TaxAmount,2),
					 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
					 'INVOICE'=>$invoice_number,
					 'INVOICE_DATE'=>$transactiondate
					);
							$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
						}
					}else{
						$to_email = $request["email"];
						$from_email = "info@assetswatch.com";
						$InvoiceFilename = 'invoice_template_transaction.txt';
							$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
							$InvoiceSubject = "Invoice For Background Verification";
							
							$transactionamount = $responseArr->transactionamount;
							$transData = $this->assetsapi_model->getTransactionBy($invoiceId);
					
					 //$transactionamount = $transData[0]['transactionamount'];
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }

					 $TaxAmount = 0;
					 // $TotAmount = $transactionamount + $TaxAmount;
					 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					 
							$this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('background_verification_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('bgv_package_tb p','p.packageId=B.selected_package','LEFT');
							$this->db->join('registration_tb r','r.assets_id=B.user_id','LEFT');
							$this->db->where('invoice_number',$invoice_number);
							$Bgvquery = $this->db->get();
							 $bgvRslt = $Bgvquery->result_array();
							  // print_r($bgvRslt);
							$Bname = $bgvRslt[0]['first_name'].' '.$bgvRslt[0]['last_name'];
						$title = 'BGV for '.$Bname;
						$relatedTitle = "BGV Package";
						$relatedName = $bgvRslt[0]['package'];
					 
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
					 
					$InvoiceTokensArr = array(
					'PAYEE_NAME' => $payeeName,
					'PAYEE_ADDRESS' => $payeeaddress,
					'PAYEE_MOBILE' => $payeeMobile,
					'PAYEE_EMAIL' => $payeeEmail,
					// 'Billed_BY_NAME' => $Billed_BY_NAME,
					// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
					// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
					// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
					 // 'PAID_FOR'=> $paidFor,
					 // 'PAID_FOR_MONTH'=> $paid_for_month,
					 'RELATED_TITLE'=>$relatedTitle,
					  'RELATED_NAME'=>$relatedName,
					 'AMOUNT'=> number_format($actualAmt,2),
					  'TITLE'=> $title,
					 'TAX_AMOUNT'=> number_format($TaxAmount,2),
					 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
					 'INVOICE'=>$invoice_number,
					 'INVOICE_DATE'=>$transactiondate
					);
						$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
					}
					
				
				
							$SSN_EIN = $request['SSN_EIN'];
							$resultSSN_EIN = substr_replace($SSN_EIN, '-', 3, 0);
							$ssn	=substr_replace($resultSSN_EIN, '-', 6, 0);
				
				$retres=array();
				$Entolldatatosend =	array (
							  'webhookURL' => 'https://devstg.assetswatch.com',
							  'packageId' => $request['packageid'],
							  'locationId' => 'ASSEMON',
							  'refId' => '',
							  'billingRefId' => '',
							  'applicationRefId' => '',
							  'user' => 
							  array (
								'refId' => '',
								'firstName' => $request['first_name'],
								'lastName' => $request['last_name'],
								'email' => $request['email'],
							  ),
							  'applicant' => 
							  array (
								'refId' => '',
								'sendReportCopy' => 'true',
								'basicInformation' => 
								array (
								  'firstName' => $request['first_name'],
								  'middleName' => '',
								  'lastName' => $request['last_name'],
								  'ssn' => $ssn,
								  'phoneNumber' => $request['mobile_no'],
								  'email' => $request['email'],
								  'dob' => date('m/d/Y',strtotime($request['dob'])),
								),
								'address' => 
								array (
								  'addressLine1' => $request['address'],
								  'city' => $request['city'],
								  'state' => $request['state'],
								  'zipCode' => $request['zip_code'],
								),
							  ),
							);
		
							$jsondataEnroll = json_encode($Entolldatatosend);
							 // print_r($jsondata);
							// exit();
							log_message('debug',print_r($jsondataEnroll,TRUE));
							
							$header = array(
										//'Accept: application/json',
										'Content-Type: application/json',
										//'Authorization: Basic NjUyQTY3MzItOTE3MC00Q0Q0LUI5QzctREZBNzlFNTYxRTU5Og=='
										'Authorization: Basic '. base64_encode("652A6732-9170-4CD4-B9C7-DFA79E561E59:")
									);
								$curl = curl_init();

								curl_setopt_array($curl, array(
								  CURLOPT_URL => "https://api.screening.services/v1/orders",
								  CURLOPT_RETURNTRANSFER => true,
								  CURLOPT_ENCODING => "",
								  CURLOPT_MAXREDIRS => 10,
								  CURLOPT_TIMEOUT => 30,
								  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
								  CURLOPT_CUSTOMREQUEST => "POST",
								 CURLOPT_POSTFIELDS => $jsondataEnroll,
								 CURLOPT_HTTPHEADER => $header
								));

								$responseEnroll = curl_exec($curl);
								$err = curl_error($curl);
							
								curl_close($curl);

								if ($err) {
								  echo "cURL Error #:" . $err;
								  $retres['success']=0;
									$retres['msg']="Something went wrong.!!!";
								}else{
								   //print_r($responseEnroll);
									// echo "<br/>";
									// echo "<br/>";
									// echo "<br/>";
									log_message('debug',print_r($responseEnroll,TRUE));
									$responseArrEnroll=json_decode($responseEnroll, true);
									 
									if (strpos($responseEnroll, "data") !== FALSE) {
											$retres['success']=0;
											$retres['msg']="Something went wrong.!!!";	
										}else{
											
											
													$reportId =$responseArrEnroll['reportId'];
													$mvpId = $responseArrEnroll['mvpId'];
													$status = $responseArrEnroll['status'];
													$orderDate =date('Y-m-d H:i:s');
													$login_user_id = $request['login_user_id'];
													$user_id = $request['user_id'];
													$packageId = $request['packageid'];
											if($reportId>0){
												
													$dataToInsert = array(
														'tx_id'=>$tx_id,
														'reportId'=>$reportId,
														'mvpId'=>$mvpId,
														'status'=>$status,
														'orderDate'=>$orderDate,
														'login_user'=>$login_user_id,
														'user_id'=>$user_id,
														'selected_package'=>$packageId,
														'created_date'=>date('Y-m-d H:i:s')
														// 'document'=>$responseReport
													);
													$this->db->insert('background_verification_tb',$dataToInsert);
													// print_r($responseReport);
													$retres['success']=1;
													$retres['msg']="Background Verification Completed.!!!";
													$retres['reportId']=$reportId;
												 
											}else{
												$retres['success']=0;
												$retres['msg']="Something went wrong.!!!";
											}
											
										}
								} 
							
							
						}else{
												$retres['success']=0;
												$retres['msg']="Something went wrong.!!!";
												
										}
					
					
				  }
				  }else{
					  $retres['success']=0;
						$retres['msg']=$responseArr->responsemessage;
						
				  }
				}
			
			 
				 $retres=json_encode($retres);
				 echo $retres;
		   
				
		
		
	}
	public function bgv_report($reportId)
	{

			
					
					$curl = curl_init();
					$header = array(
						'Content-Type: application/json',
						'Authorization: Basic '. base64_encode("652A6732-9170-4CD4-B9C7-DFA79E561E59:")
					);
					curl_setopt_array($curl, array(
					  CURLOPT_URL => "https://api.screening.services/v1/widgets/report-viewer/".$reportId,
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 30,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "GET",
					 CURLOPT_HTTPHEADER => $header
					));

					$responseReport = curl_exec($curl);
					$err = curl_error($curl);

					curl_close($curl);
					if ($err) {
					  echo "cURL Error #:" . $err;
					} else {
						// $html = $responseReport;
						$dompdf = new Dompdf\Dompdf();
				 
						// (Optional) Setup the paper size and orientation
						

						$dompdf->loadHtml($responseReport);
						$dompdf->set_option('isHtml5ParserEnabled', true);
						$dompdf->set_option('isRemoteEnabled', TRUE);
		
						$dompdf->setPaper('A4', 'landscape');
						// Render the HTML as PDF
						$dompdf->render();
				 
						// Get the generated PDF file contents
						$pdf = $dompdf->output();
				 
						// Output the generated PDF to Browser
						$dompdf->stream();
					} 
					
					
					
 
						
	}
	public function bgv_information($login_userId,$report_userId){
		$result =$this->assetsapi_model->get_bgvinfo_by($login_userId,$report_userId);
		$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['bgvInfo']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	//=========================ratiing list with top agents==================
	public function top_rating_agents()
	{
		$result = $this->assetsapi_model->top_rating_agents();
				$retres = array();
				if($result)
				{
					$retres['success']=1;
					$retres['agent_list']= $result;
					
				}else{
						$retres['success']=0;
						$retres['msg']="Something went wrong.!!!";
						
				}
			
			$retres=json_encode($retres);
			echo $retres;
				
	}
	
	//========================send_emailto_non_register=======================================
	public function send_emailto_non_register($request=array())
	{
		$request = json_decode(file_get_contents('php://input'), true);  
		
			if(strpos($request['email'], ',') !== false) {
				$exploded = explode(',',$request['email']);
				$emailArr = $exploded;
			}else{
				$emailArr = $request['email'];
			}
			 
		  $from_email = "info@assetswatch.com";
		  $filename = 'non_register_user.txt';
		  $template = read_file('assets/email_template/'.$filename);
		  $subject = "Registration";
		  $to_email = $emailArr;
			
		$reacturl = $this->config->item('reacturl');
		 $url = "<br/><a href='".$reacturl."register' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Register</a>";
		
		$tokensArr = array(
				 'URL'=> trim($url)
				);
				$mail = $this->send_mail($from_email,$to_email,$subject,$tokensArr,$template);
				// ========================Mail======================================================================
				$retres = array();
			if($mail)
				{
					$retres['success']=1;
					$retres['msg']="Mail sended successfully.!!!";
					
				}else{
					// echo "not send ::".$this->email->print_debugger(FALSE);
					$retres['success']=0;
					$retres['msg']="Something went wrong.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
				
	}
	
	
	//=======================property payment=================================
	public function property_payment($request=array())
	{
		
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $prop_detail = $this->assetsapi_model->property_details($request["property_id"]);
			$owner_id = $prop_detail[0]['owner_id'];
			$agent_perc = $prop_detail[0]['agent_perc'];
			$paidToInfo = $this->assetsapi_model->getPaidToInfo($request["property_id"]);
			$paidTo = $paidToInfo[0]['paid_to'];
			$enrollInfo = $this->assetsapi_model->enroll_info($paidTo);
			
			 $dealInfo = $this->assetsapi_model->getDealInfo($request['deal_id']);
			$sender_id = $dealInfo[0]['sender_id'];
			$SenderProfile = $this->assetsapi_model->profile($sender_id);
			$sender_Assetstype = $SenderProfile['assets_type'];
			$retres = array();
			if($enrollInfo){
				$pid = $enrollInfo[0]['clientpartnerid'];
				$clientpartnerkey = $enrollInfo[0]['clientpartnerkey'];
				if($pid!='' && $pid!=null && $clientpartnerkey!='' && $clientpartnerkey!=null){
					
						// $retres['msg']="any";
						// $retres['checkUserType']=$checkUserType;
						// $partnerkey = $this->config->item('partnerkey');
						$partnerkey = $clientpartnerkey;
						$partnerid = $pid;
						$transactiontype = $this->config->item('transactiontype');
			
						$randNumber = mt_rand(100000, 999999);
						$orderid = 'TXN'.$randNumber;
						$this->session->set_userdata('orderid', $orderid);
						$userData = $this->assetsapi_model->profile($request["payeeid"]);
			
						$first_name = $userData['first_name'];
						$last_name = $userData['last_name'];
						$address = $userData['city']." ".$userData['state']." ".$userData['country']." ".$userData['zip_code'];
						$city = $userData['city'];
						
						 $state = $userData['state'];
						$StateCodeQ = $this->db->get_where('uvw_country_states',array('state_name'=>$state));
						$stateRslt = $StateCodeQ->result_array();
						if(count($stateRslt)){
							$stateCode = $stateRslt[0]['state_2_code'];
						}else{
							$stateCode = '';
						}
						
						$country = $userData['country'];
						$CountryQuery = $this->db->get_where('countries',array('name'=>$country));
						$countryRslt = $CountryQuery->result_array();
						if(count($countryRslt)>0){
							$countryCode = $countryRslt[0]['sortname'];
						}else{
							$countryCode = '';
						}
						
						$zip = $userData['zip_code'];
						$email = $userData['email']; 
						if($request['type']==='CC'){
							$chargeInfo = $this->assetsapi_model->getPaymentCharges($request['type']);
							 if($chargeInfo['pay_mode']=='Percentage'){
								$subAmt = (($request["transactionamount"]*$chargeInfo['charges'])/100);
							}else if($chargeInfo['pay_mode']=='Amount'){
								$subAmt = $chargeInfo['charges'];
								 }
							
							if($sender_Assetstype==2){
								$secondaryamount = ($request["transactionamount"]*$agent_perc)/100;
								$transactionamount = ($request["transactionamount"]-$secondaryamount) + $subAmt;
							}else{
								$secondaryamount = 0;
								$transactionamount = ($request["transactionamount"]) + $subAmt;
							}
							
							$datatosend = array(
							"partnerkey"=>$partnerkey,
							"partnerid"=>$partnerid,
							"transactiontype"=>$transactiontype,
							"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
							"expirymmyy"=>$request["expirymmyy"],
							"cvv"=>$request["cvv"],
							"paymentmode"=>$request["paymentmode"],
							"transactionamount"=>$transactionamount,
							"secondaryamount"=>$secondaryamount,
							"routingnumber"=>$request["routingnumber"],
							"surchargeamount"=>$request["surchargeamount"],
							"currency"=>$request["currency"],
							"payeefirstname"=>$first_name,
							"payeelastname"=>$last_name,
							"address"=>$address,
							"city"=>$city,
							"state"=>$stateCode,
							"country"=>$countryCode,
							"zip"=>$zip,
							"email"=>$email,
							"transactionreference"=>$request["transactionreference"],
							 "orderid"=>$orderid,
							"payeeid"=>$request["payeeid"],
							"notifypayee"=>$request["notifypayee"],
							"profile"=>$request["profile"],
							"profileid"=>$request["profileid"]
							);
						}else if($request['type']==='ACH'){
							$chargeInfo = $this->assetsapi_model->getPaymentCharges($request['type']);
							 if($chargeInfo['pay_mode']=='Percentage'){
								$subAmt = (($request["transactionamount"]*$chargeInfo['charges'])/100);
							}else if($chargeInfo['pay_mode']=='Amount'){
								$subAmt = $chargeInfo['charges'];
								 }
							
							if($sender_Assetstype==2){
								$secondaryamount = ($request["transactionamount"]*$agent_perc)/100;
								$transactionamount = ($request["transactionamount"]-$secondaryamount) + $subAmt;
							}else{
								$secondaryamount = 0;
								$transactionamount = ($request["transactionamount"]) + $subAmt;
							}
							
							$datatosend = array(
									"partnerkey"=>$partnerkey,
									"partnerid"=>$partnerid,
									"transactiontype"=>$transactiontype,
									"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
									"paymentmode"=>$request["paymentmode"],
									"transactionamount"=>$transactionamount,
									"secondaryamount"=>$secondaryamount,
									"routingnumber"=>$request["routingnumber"],
									"surchargeamount"=>$request["surchargeamount"],
									"currency"=>$request["currency"],
									"payeefirstname"=>$first_name,
									"payeelastname"=>$last_name,
									"address"=>$address,
									"city"=>$city,
									"state"=>$stateCode,
									"country"=>$countryCode,
									"zip"=>$zip,
									"email"=>$email,
									"transactionreference"=>$request["transactionreference"],
									"orderid"=>$orderid,
									"payeeid"=>$request["payeeid"],
									"notifypayee"=>$request["notifypayee"],
									"profile"=>$request["profile"],
									"profileid"=>$request["profileid"]
									);
						}
						
						 $jsondata = json_encode($datatosend);
						 

						log_message('debug',print_r($jsondata,TRUE));
						$this->db->order_by('transactiondate',"desc");
										$this->db->limit(1);
										$query = $this->db->get('property_transaction_tb');
										 $lastRecord = $query->result_array();
									  if(count($lastRecord)>0 && ($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null) ){
										  $inv = $lastRecord[0]['invoice_number'];
										  
											$inv_number = ++$inv;
									  }else{
										  $inv_number = 'AWLLCP000001';
									  }
							 $transAmount = $transactionamount;
								   $invoice_number = $inv_number;
								   if($request["paid_for"]=='Rent' || $request["paid_for"]=='Rented'){
										$paidMonth = $request["paid_month"];
									}else{
										$paidMonth = null;
									}
								   $datatoinsertTrans = array( 
												'invoice_number' => $invoice_number,
												'deal_id' => $request['deal_id'],
												'payee_id'=>$request["payeeid"],
												'orderid'=> $orderid,
												// 'transactionid'=>$responseArr->transactionid,
												// 'paymentmode'=>$responseArr->paymentmode,
												// 'transaction_type'=>$responseArr->transactiontype,
												// 'transactionamount'=>$transAmount,
												// 'transactionreference'=>$responseArr->transactionreference,
												// 'responsecode'=>$responseArr->responsecode,
												// 'responsestatus'=>$responseArr->responsestatus,
												// 'responsemessage'=>$responseArr->responsemessage,
												// 'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
												'paid_for'=>$request["paid_for"],
												'paid_by'=>$request['type'],
												'paid_amt_owner'=>$transAmount,
												'paid_for_month'=>$paidMonth,
												'actual_amt'=>$request["transactionamount"],
												'tax_amt'=>$subAmt
												
												
								   );
								   // print_r($datatoinsertTrans);
								 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
									$insertTrans = $this->db->insert('property_transaction_tb',$datatoinsertTrans);
						 // print_r($jsondata);
						$curl = curl_init();

						curl_setopt_array($curl, array(
						  CURLOPT_URL => "https://api.singularbillpay.com/v1/transaction",
						  CURLOPT_RETURNTRANSFER => true,
						  CURLOPT_ENCODING => "",
						  CURLOPT_MAXREDIRS => 10,
						  CURLOPT_TIMEOUT => 30,
						  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						  CURLOPT_CUSTOMREQUEST => "POST",
						 CURLOPT_POSTFIELDS => $jsondata,
						 CURLOPT_HTTPHEADER => array(
							"Content-Type: application/json"
						  ),
						));

						$response = curl_exec($curl);
						$err = curl_error($curl);

						curl_close($curl);
						if ($err) {
						echo "cURL Error #:" . $err;
						} else {
							      // echo $response;
							  // $txn_id = $this->session->userdata('txn_no');
							  // print_r($responseArr);
								  $responseArr = json_decode($response);
								  
								  log_message('debug',print_r($responseArr,TRUE));
							 if(count($responseArr)>0){
								  if($orderid == $responseArr->orderid)
								  {
									  $datatoupdate = array( 
												
												'transactionid'=>$responseArr->transactionid,
												'paymentmode'=>$responseArr->paymentmode,
												'transaction_type'=>$responseArr->transactiontype,
												'transactionamount'=>$transAmount,
												'transactionreference'=>$responseArr->transactionreference,
												'responsecode'=>$responseArr->responsecode,
												'responsestatus'=>$responseArr->responsestatus,
												'responsemessage'=>$responseArr->responsemessage,
												'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
												
												
												
								   );
								   // print_r($datatoinsertTrans);
								  $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$orderid));
									
									$profileSender = $this->assetsapi_model->profile($request["payeeid"]);
									$SenderAssets_type  = $profileSender['assets_type'];
									$senderAssetsType = $this->assetsapi_model->getAssetsType($SenderAssets_type);
									$SenderName  = $profileSender['first_name'].' '.$profileSender['last_name'];
									$notiData = array(
										'sender'=>$request['payeeid'],
										'receiver'=>$owner_id,
										'message' => $senderAssetsType.' '.$SenderName.' paid the rent of '.$transAmount
										
									);
									$notifyInsert = $this->db->insert('notification_tb',$notiData);
								}
							
								 if($orderid == $responseArr->orderid &&  $responseArr->responsestatus==='APPROVED')
								 {
										 $retres['success']=1;
										 $retres['msg']='Payment Completed.!!!';
										 //========================Mail Invoice====================================================
								 $settingInfo = $this->assetsapi_model->getEmailSmsSettingInfo($request['payeeid']);
								 
								 if($settingInfo){
									 if($settingInfo['email']==='ON'){
										 $to_email = $email;
										$from_email = "info@assetswatch.com";
										$InvoiceFilename = 'invoice_template.txt';
										$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
										$InvoiceSubject = "Invoice For Property";
										
										$transData = $this->assetsapi_model->getPropTransactionBy($invoice_number);
					
					 $transactionamount = $transData[0]['transactionamount'];
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }

					
					
						 //$TotAmount = (float) str_replace(',', '', $transactionamount) + (float) str_replace(',', '', $TaxAmount);
						 $paidFor = $transData[0]['paid_for'];
						 $transactiondate = $transData[0]['transactiondate'];
					 
							$PayBy = $transData[0]['paid_by'];

							$actualAmt = $transData[0]['actual_amt'];
						 
							$TaxAmount =$transData[0]['tax_amt'];
						
							$payeeName = $transData[0]['name'];
							$payeeMobile = $transData[0]['mobile_no'];
							$payeeEmail = $transData[0]['email'];
							 $paid_for_month = $transData[0]['paid_for_month']?($transData[0]['paid_for_month']).", ".date('Y',strtotime($transactiondate)):date('M, Y',strtotime($transactiondate));
							 
							 $dealInfo = $this->assetsapi_model->deal_agreement_pdf_view($transData[0]['deal_id']);
							 $propertyId = $dealInfo[0]['property_id'];
							 
							 $this->db->select("*");
							$query = $this->db->get_where('property_payment_check',array('user_id'=>$transData[0]['payee_id'],'property_id'=>$propertyId,'status'=>'Active'));
							$rslt = $query->result_array();
							if(count($rslt)>0){
								$paid_to = $rslt[0]['paid_to'];
							
								$paidToProfile = $this->assetsapi_model->profile($paid_to);
								
								$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
								 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
								$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
								$Billed_BY_EMAIL = $paidToProfile['email'];
							
							}else{
								$dataProperty = $this->assetsapi_model->property_details($propertyId);
								$paid_to = $dataProperty[0]['owner_id'];
							
								$paidToProfile = $this->assetsapi_model->profile($paid_to);
								$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
								 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
								$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
								$Billed_BY_EMAIL = $paidToProfile['email'];
							}
							
							$this->db->select("*");
							$query1 = $this->db->get_where('property_tb',array('id'=>$propertyId,'status'=>'1'));
							$rslt1 = $query1->result_array();
							// echo $this->db->last_query();
							// print_r($rslt1);
							$property = $rslt1[0]['title'];
							$RENT_PAID_DATE = date('m/d/Y H:i:s',strtotime($transactiondate));
										
										 $title = "Property ".$request["paid_for"];
										$InvoiceTokensArr = array(
											'PAYEE_NAME' => $payeeName,
											'PAYEE_ADDRESS' => $payeeaddress,
											'PAYEE_MOBILE' => $payeeMobile,
											'PAYEE_EMAIL' => $payeeEmail,
											'Billed_BY_NAME' => $Billed_BY_NAME,
											'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
											'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
											'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
											 'PAID_FOR'=> $paidFor,
											 'PAID_FOR_MONTH'=> $paid_for_month,
											 'RENT_PAID_DATE'=> $RENT_PAID_DATE,
											 'AMOUNT'=> number_format($actualAmt,2),
											 'PROPERTY'=> $property,
											 'TAX_AMOUNT'=> number_format($TaxAmount,2),
											 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
											 'INVOICE'=>$invoice_number,
											 'INVOICE_DATE'=>$transactiondate
											);
										$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
									 }
								 }else{
									 $to_email = $email;
									$from_email = "info@assetswatch.com";
									$InvoiceFilename = 'invoice_template.txt';
										$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
										$InvoiceSubject = "Invoice For Property";
										
										$transData = $this->assetsapi_model->getPropTransactionBy($invoice_number);
					
					 $transactionamount = $transData[0]['transactionamount'];
					 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
					
					
						 //$TotAmount = (float) str_replace(',', '', $transactionamount) + (float) str_replace(',', '', $TaxAmount);
						 $paidFor = $transData[0]['paid_for'];
						 $transactiondate = $transData[0]['transactiondate'];
					 
							$PayBy = $transData[0]['paid_by'];

							$actualAmt = $transData[0]['actual_amt'];
						 
							$TaxAmount =$transData[0]['tax_amt'];
						
							$payeeName = $transData[0]['name'];
							$payeeMobile = $transData[0]['mobile_no'];
							$payeeEmail = $transData[0]['email'];
							 $paid_for_month = $transData[0]['paid_for_month']?($transData[0]['paid_for_month']).", ".date('Y',strtotime($transactiondate)):date('M, Y',strtotime($transactiondate));
							 
							 $dealInfo = $this->assetsapi_model->deal_agreement_pdf_view($transData[0]['deal_id']);
							 $propertyId = $dealInfo[0]['property_id'];
							 
							 $this->db->select("*");
							$query = $this->db->get_where('property_payment_check',array('user_id'=>$transData[0]['payee_id'],'property_id'=>$propertyId,'status'=>'Active'));
							$rslt = $query->result_array();
							if(count($rslt)>0){
								$paid_to = $rslt[0]['paid_to'];
							
								$paidToProfile = $this->assetsapi_model->profile($paid_to);
								
								$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
								 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
								$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
								$Billed_BY_EMAIL = $paidToProfile['email'];
							
							}else{
								$dataProperty = $this->assetsapi_model->property_details($propertyId);
								$paid_to = $dataProperty[0]['owner_id'];
							
								$paidToProfile = $this->assetsapi_model->profile($paid_to);
								$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
								 if(!empty($paidToProfile['assets_address'])){
									 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
								 }else{
									 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
								 }
								$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
								$Billed_BY_EMAIL = $paidToProfile['email'];
							}
							
							$this->db->select("*");
							$query1 = $this->db->get_where('property_tb',array('id'=>$propertyId,'status'=>'1'));
							$rslt1 = $query1->result_array();
							// echo $this->db->last_query();
							// print_r($rslt1);
							$property = $rslt1[0]['title'];
							$RENT_PAID_DATE = date('m/d/Y H:i:s',strtotime($transactiondate));
										
										 $title = "Property ".$request["paid_for"];
										$InvoiceTokensArr = array(
											'PAYEE_NAME' => $payeeName,
											'PAYEE_ADDRESS' => $payeeaddress,
											'PAYEE_MOBILE' => $payeeMobile,
											'PAYEE_EMAIL' => $payeeEmail,
											'Billed_BY_NAME' => $Billed_BY_NAME,
											'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
											'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
											'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
											 'PAID_FOR'=> $paidFor,
											 'PAID_FOR_MONTH'=> $paid_for_month,
											 'RENT_PAID_DATE'=> $RENT_PAID_DATE,
											 'AMOUNT'=> number_format($actualAmt,2),
											 'PROPERTY'=> $property,
											 'TAX_AMOUNT'=> number_format($TaxAmount,2),
											 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
											 'INVOICE'=>$invoice_number,
											 'INVOICE_DATE'=>$transactiondate
											);
									$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
								 }
									
										 //$retres['payment']=$responseArr;
													
								 }else{
										 $retres['success']=0;
										 $retres['msg']=$responseArr->responsemessage;
										
									 } 
							 }else{
										$retres['success']=0;
										 $retres['msg']=$responseArr->responsemessage;
							 } 
					   
						}
					
				}else{
					$retres['success']=0;
					$retres['msg']="Your owner have not merchant account or partner key.!!!";
				}
			}else{
				$retres['success']=0;
				$retres['msg']="Something went wrong. Please try later.!!!";
			} 
			
			
		$retres=json_encode($retres);
				 echo $retres; 
	}
	
	public function basic_plan_update($userid,$planid)
	{
		$update = $this->db->update('registration_tb',array('plan_id'=>$planid,'status'=>1),array('assets_id'=>$userid));
		$retres = array();
		if($update){
			$dataToInsert = array(
					"assets_id"=>$userid,
					"plan_id"=>$planid,
					"upgrade_reason"=>'Register',
					'upgrade_date'=>date("Y-m-d H:i:s")

			);
			$this->db->insert('upgrade_plan_log_tb',$dataToInsert);
				$retres['success']=1;
				$retres['msg']='Successfully Register.!!!';

				$result1 = $this->assetsapi_model->profile($userid);
				
				$email = $result1['email'];
				//========================Mail======================================================================
				$to_email = $email;
				$from_email = "info@assetswatch.com";
				$RegFilename = 'registration_template.txt';
				$RegTemplate = read_file('assets/email_template/'.$RegFilename);
				$RegSubject = "Registration";
				
				$reacturl = $this->config->item('reacturl');
				$url = "<br/><a href='".$reacturl."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Login</a>";

				$RegTokensArr = array(
				'USER_NAME' => $result1['first_name'],
				 'USER_EMAIL'=> $to_email,
				 'URL'=> trim($url)
				);
				$RegMail = $this->send_mail($from_email,$to_email,$RegSubject,$RegTokensArr,$RegTemplate);
		}else{
				$retres['success']=0;
				$retres['msg']='Somthing went wrong please try later.!!!';
						
			} 
		$retres=json_encode($retres);
		 echo $retres;
	}
	
	//========================================  Agreement PDF ===========================================
	public function  agreement_pdf_view($agreement_id,$session_id){
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$record = $this->assetsapi_model->agreement_pdf_view($agreement_id);
				
			// print_r($brandingData);
			$pdf = new MyCustomPDFWithWatermark(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
					
					$userId =$record[0]['user_id'];
					$brandingData = $this->assetsapi_model->getBrandingInfo($userId);
					if($brandingData){
						$branding = $brandingData['branding'];
							$headerContent = $brandingData['header_title'];
							$footerContent = $brandingData['footer_title'];
							$headerImage = $brandingData['branding_logo'];
							$watermarkImage = $brandingData['branding_watermark'];
					}else{
						$branding = 'Default';
						$headerContent = '';
						$footerContent = '';
						$headerImage = '';
						$watermarkImage = '';
					}
					
					$html = $record[0]['agreement_doc_content'];
					
					$template = array('headerContent'=>$headerContent,'footerContent'=>$footerContent,'headerImage'=>$headerImage,'watermarkImage'=>$watermarkImage,'branding'=>$branding);
					$pdf->setData($template);
					
					$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
					
					// set header and footer fonts
						$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
						$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

						// set default monospaced font
						$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
					
					// set margins
					$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
					$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
					$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
					
					$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);//, 70,120, 57, 25, '', '', '', false, 300, '', false, false, 0);
					
					$pdf->SetFont('times', '', 8, '', false); 
						
					$pdf->AddPage();
					$pdf->writeHTML($html, true, false, true, false, '');
					ob_clean();
					
					$fileName = $record[0]['agreement_doc_id'].'.pdf';
					 $pdf->Output($fileName,'I'); 
			}else{
					$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
		}
		
		public function  deal_agreement_pdf_view($userId,$deal_id,$session_id){
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$record = $this->assetsapi_model->deal_agreement_pdf_view($deal_id);
				
					$pdf = new MyCustomPDFWithWatermark(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
					
					//$userId =$record[0]['sender_id'];
					$brandingData = $this->assetsapi_model->getBrandingInfo($userId);
					if($brandingData){
						$branding = $brandingData['branding'];
							$headerContent = $brandingData['header_title'];
							$footerContent = $brandingData['footer_title'];
							$headerImage = $brandingData['branding_logo'];
							$watermarkImage = $brandingData['branding_watermark'];
					}else{
						$branding = 'Default';
						$headerContent = '';
						$footerContent = '';
						$headerImage = '';
						$watermarkImage = '';
					}
					
					$html = $record[0]['replaced_template'];
					//print_r($html);
					$template = array('headerContent'=>$headerContent,'footerContent'=>$footerContent,'headerImage'=>$headerImage,'watermarkImage'=>$watermarkImage,'branding'=>$branding);
					$pdf->setData($template);
					
					$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
					
					// set header and footer fonts
						$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
						$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

						// set default monospaced font
						$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
					
					// set margins
					$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
					$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
					$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
					
					$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);//, 70,120, 57, 25, '', '', '', false, 300, '', false, false, 0);
					
					$pdf->SetFont('times', '', 8, '', false); 
						
					$pdf->AddPage();
					$pdf->writeHTML($html, true, false, true, false, '');
					ob_clean();
					
					$fileName = $record[0]['agreement_unique_id'].'.pdf';
					 $pdf->Output($fileName,'I'); 
			}else{
					$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
		}
	
	//=================================================newsletter============================================================
	public function newsletter($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $checkEmail = $this->assetsapi_model->getNewsLetterBy($request['email']);
		 $retres = array();
		 if(count($checkEmail)>0){
				$retres['success']=0;
				$retres['msg']= "This email already subscribed.!!!";
		 }else{
			 $result = $this->assetsapi_model->insertNewsletterEmail($request);
			 if($result){
				$retres['success']=1;
				$retres['msg']= "You have successfully subscribed news feeds.";
			}
			else{
				$retres['success']=0;
				$retres['msg']= "Something went wrong. Please try later.!!!";
			}
		 }
			$retres=json_encode($retres);
			echo $retres;
			
	}
	
	//=================================================newsletter============================================================
	public function property_images($id){
		 
		 $query = $this->db->get_where('property_photo_tb',array('property_id'=>$id));
		 $result = $query->result_array();
		 $retres = array();
		 if(count($result)>0){
				$retres['success']=1;
				$retres['property_images']= $result;
		 }else{
				$retres['success']=0;
				$retres['msg']= "Something went wrong. Please try later.!!!";

		 }
			$retres=json_encode($retres);
			echo $retres;
			
	}
		public function session_check($user_id,$session_id){
		$validate = $this->assetsapi_model->session_check($user_id,$session_id);
			if($validate)
			{
					$retres['success']=1;
					$retres['msg']="Authorised User.!!!";
			}
			else
			{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
			}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function delete_image($request=array()){
			$request = json_decode(file_get_contents('php://input'), true); 
			$Del = $this->db->delete('property_photo_tb',array('img_path'=>$request['image']));
			if($Del){
				$retres['success']=1;
				$retres['msg']= "Deleted";
			}else{
				$retres['success']=0;
				$retres['msg']= "Something went wrong. Please try later.!!!";
				}
				// echo $this->db->last_query();
			$retres=json_encode($retres);
			echo $retres;
		}
		
		//=========================================================================================
		public function terminate_user($userId,$inviteId,$session_id){
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$result = $this->assetsapi_model->terminate_user($userId,$inviteId);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']='User terminated successfully.';
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Something went wrong.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		//====================================================================================================
		
		//=========================================================================================
		public function agreement_terminate($userId,$dealId){
			
				$result = $this->assetsapi_model->agreement_terminate($userId,$dealId);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']='Agreement terminated successfully.';
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Something went wrong.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		//=========================================================================================
		public function getTransaction($dealId,$paidFor){
			
				$result = $this->assetsapi_model->getTransaction($dealId,$paidFor);
				$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['paidAmt']=$result;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Something went wrong.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function checkMerchant($userid,$propertyId){
			 $prop_detail = $this->assetsapi_model->property_details($propertyId);
			$owner_id = $prop_detail[0]['owner_id'];
			$profileDetail = $this->assetsapi_model->profile($owner_id);
			$ownerName = $profileDetail['first_name']." ".$profileDetail['last_name'];
			$enrollInfo = $this->assetsapi_model->enroll_info($owner_id);
			
			$TprofileDetail = $this->assetsapi_model->profile($userid);
			$tenant_name = $TprofileDetail['first_name']." ".$TprofileDetail['last_name'];
			
			$retres = array();
			if($enrollInfo){
				$pid = $enrollInfo[0]['clientpartnerid'];
				$clientpartnerkey = $enrollInfo[0]['clientpartnerkey'];
				if($pid!='' && $pid!=null && $clientpartnerkey!='' && $clientpartnerkey!=null){
					$retres['success']=1;
					$retres['msg']="Please Continue.!!!";
				}else{
					$retres['success']=0;
					$retres['msg']="Don't pay now because owner ".ucfirst($ownerName)."'s merchent key is not initiated.Please contact to your property owner..!!!";
				}
			}else{
				$retres['success']=0;
				$retres['msg']="Don't pay now because owner ".ucfirst($ownerName)."'s merchent key is not initiated.Please contact to your property owner..!!!";
				$reacturl = $this->config->item('reacturl');
						
					$notiData = array(
										'sender'=>$userid,
										'receiver'=>$owner_id,
										'message' =>'Tenant '.$tenant_name.' has tried to pay rent . Please initiate your sub-merchant account. <a href="'.$reacturl.'owner-payment">Initiate Account</a>'
										
									);
					 $notifyInsert = $this->db->insert('notification_tb',$notiData);
			}
			
			
			$retres=json_encode($retres);
				 echo $retres; 
	
		}
		
		public function payByCheque(){
			$request = json_decode(file_get_contents('php://input'), true); 
			 //print_r($request);
			// exit();
			$chequeno = $request['chqno'];
			$assets_id = $request['assets_id'];
			$deal_id = $request['deal_id'];
			$amt = $request['amt'];
			$payFor = $request['payFor'];
			$description = $request['description'];
			$paid_month = $request['paid_month'];
			
			$prop_detail = $this->assetsapi_model->property_details($request["property_id"]);
			
			$paidToInfo = $this->assetsapi_model->getPaidToInfo($request["property_id"]);
			$paidTo = $paidToInfo[0]['paid_to'];
			if($paidTo!=''){
				$paidTo = $paidToInfo[0]['paid_to'];
			}else{
				$paidTo = $prop_detail[0]['owner_id'];
			}
			$owner_id = $prop_detail[0]['owner_id'];
			
			
			$randNumber = mt_rand(100000, 999999);
			$orderid = 'TXN'.$randNumber;

			$userData = $this->assetsapi_model->profile($assets_id);
			
			$this->db->order_by('transactiondate',"desc");
			$this->db->limit(1);
			$query = $this->db->get('property_transaction_tb');
			$lastRecord = $query->result_array();
			if(count($lastRecord)>0 && ($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null) ){
				$inv = $lastRecord[0]['invoice_number'];
				$inv_number = ++$inv;
				}else{
					$inv_number = 'AWLLCP000001';
				}
							 $transAmount = $amt;
								   $invoice_number = $inv_number;
								   $datatoinsertTrans = array( 
												'invoice_number' => $invoice_number,
												'deal_id' => $deal_id,
												'payee_id'=>$assets_id,
												'orderid'=> $orderid,
												'paymentmode'=>'Cheque',
												'transactionamount'=>$transAmount,
												'responsestatus'=>'APPROVED',
												'responsemessage'=>'success',
												'transactiondate'=>date('Y-m-d H:i:s'),
												'paid_for'=>$payFor,
												'paid_by'=>'CHEQUE',
												'paid_amt_owner'=>$transAmount,
												'paid_for_month'=>$paid_month,
												'actual_amt'=>$transAmount
												
												
								   );
								   // print_r($datatoinsertTrans);
								 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
				$insertTrans = $this->db->insert('property_transaction_tb',$datatoinsertTrans);
				
			if($insertTrans){
				$datatoinsert = array( 
												'deal_id' => $deal_id,
												'owner_id' => $paidTo,
												'payee_id'=>$assets_id,
												'cheque_no'=> $chequeno,
												'description'=>$description,
												'amt'=>$transAmount		
								   );

				$insertData = $this->db->insert('cheque_transaction_tb',$datatoinsert);
				
									$profileSender = $this->assetsapi_model->profile($assets_id);
									$SenderAssets_type  = $profileSender['assets_type'];
									$senderAssetsType = $this->assetsapi_model->getAssetsType($SenderAssets_type);
									$SenderName  = $profileSender['first_name'].' '.$profileSender['last_name'];
									$email = $profileSender['email'];
									$address = $profileSender['city']." ".$profileSender['state']." ".$profileSender['country']." ".$profileSender['zip_code'];
									$notiData = array(
										'sender'=>$assets_id,
										'receiver'=>$owner_id,
										'message' => $senderAssetsType.' '.$SenderName.' paid the rent of '.$transAmount
										
									);
									$notifyInsert = $this->db->insert('notification_tb',$notiData);
									
							//========================Mail Invoice====================================================
							$settingInfo = $this->assetsapi_model->getEmailSmsSettingInfo($assets_id);
								 
								 if($settingInfo){
									 if($settingInfo['email']==='ON'){
										$to_email = $email;
										$from_email = "info@assetswatch.com";
										$InvoiceFilename = 'invoice_template.txt';
										$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
										$InvoiceSubject = "Invoice For Property";
										
										
										$transData = $this->assetsapi_model->getPropTransactionBy($invoice_number);
					
										 $transactionamount = $transData[0]['transactionamount'];
										if(!empty($transData[0]['assets_address'])){
											 $payeeaddress  = $transData[0]['assets_address'];
										 }else{
											 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
										 }
										
										
										 //$TotAmount = (float) str_replace(',', '', $transactionamount) + (float) str_replace(',', '', $TaxAmount);
										 $paidFor = $transData[0]['paid_for'];
										 $transactiondate = $transData[0]['transactiondate'];
										 
										$PayBy = $transData[0]['paid_by'];

											 $actualAmt = $transData[0]['actual_amt'];
											 
											  $TaxAmount =$transData[0]['tax_amt'];
											
										$payeeName = $transData[0]['name'];
										$payeeMobile = $transData[0]['mobile_no'];
										$payeeEmail = $transData[0]['email'];
										 $paid_for_month = $transData[0]['paid_for_month']?($transData[0]['paid_for_month']).", ".date('Y',strtotime($transactiondate)):date('M, Y',strtotime($transactiondate));
										 
										 $dealInfo = $this->assetsapi_model->deal_agreement_pdf_view($transData[0]['deal_id']);
										 $propertyId = $dealInfo[0]['property_id'];
										 
										 $this->db->select("*");
										$query = $this->db->get_where('property_payment_check',array('user_id'=>$transData[0]['payee_id'],'property_id'=>$propertyId,'status'=>'Active'));
										$rslt = $query->result_array();
										if(count($rslt)>0){
											$paid_to = $rslt[0]['paid_to'];
										
											$paidToProfile = $this->assetsapi_model->profile($paid_to);
											
											$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
											if(!empty($paidToProfile['assets_address'])){
												 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
											 }else{
												 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
											 }
											$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
											$Billed_BY_EMAIL = $paidToProfile['email'];
										
										}else{
											$dataProperty = $this->assetsapi_model->property_details($propertyId);
											$paid_to = $dataProperty[0]['owner_id'];
										
											$paidToProfile = $this->assetsapi_model->profile($paid_to);
											$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
											if(!empty($paidToProfile['assets_address'])){
										$Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
										 }else{
											 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
										 }
													$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
											$Billed_BY_EMAIL = $paidToProfile['email'];
										}
										
										$this->db->select("*");
										$query1 = $this->db->get_where('property_tb',array('id'=>$propertyId,'status'=>'1'));
										$rslt1 = $query1->result_array();
										// echo $this->db->last_query();
										// print_r($rslt1);
										$property = $rslt1[0]['title'];
										$RENT_PAID_DATE = date('m/d/Y H:i:s',strtotime($transactiondate));
										$InvoiceTokensArr = array(
										'PAYEE_NAME' => $payeeName,
										'PAYEE_ADDRESS' => $payeeaddress,
										'PAYEE_MOBILE' => $payeeMobile,
										'PAYEE_EMAIL' => $payeeEmail,
										'Billed_BY_NAME' => $Billed_BY_NAME,
										'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
										'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
										'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
										 'PAID_FOR'=> $paidFor,
										 'PAID_FOR_MONTH'=> $paid_for_month,
										 'RENT_PAID_DATE'=> $RENT_PAID_DATE,
										 'AMOUNT'=> number_format($actualAmt,2),
										 'PROPERTY'=> $property,
										 'TAX_AMOUNT'=> number_format($TaxAmount,2),
										 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
										 'INVOICE'=>$invoice_number,
										 'INVOICE_DATE'=>$transactiondate
										);
										$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate); 
									 }
								 }else{
									 $to_email = $email;
									$from_email = "info@assetswatch.com";
									$InvoiceFilename = 'invoice.txt';
									$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
									$InvoiceSubject = "Invoice For Property";
									
									
									 $InvoiceFilename = 'invoice_template.txt';
										$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
										$InvoiceSubject = "Invoice For Property";
										
										
										$transData = $this->assetsapi_model->getPropTransactionBy($invoice_number);
					
										 $transactionamount = $transData[0]['transactionamount'];
										 if(!empty($transData[0]['assets_address'])){
											 $payeeaddress  = $transData[0]['assets_address'];
										 }else{
											 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
										 }
										
										 //$TotAmount = (float) str_replace(',', '', $transactionamount) + (float) str_replace(',', '', $TaxAmount);
										 $paidFor = $transData[0]['paid_for'];
										 $transactiondate = $transData[0]['transactiondate'];
										 
										$PayBy = $transData[0]['paid_by'];

											 $actualAmt = $transData[0]['actual_amt'];
											 
											  $TaxAmount =$transData[0]['tax_amt'];
											
										$payeeName = $transData[0]['name'];
										$payeeMobile = $transData[0]['mobile_no'];
										$payeeEmail = $transData[0]['email'];
										 $paid_for_month = $transData[0]['paid_for_month']?($transData[0]['paid_for_month']).", ".date('Y',strtotime($transactiondate)):date('M, Y',strtotime($transactiondate));
										 
										 $dealInfo = $this->assetsapi_model->deal_agreement_pdf_view($transData[0]['deal_id']);
										 $propertyId = $dealInfo[0]['property_id'];
										 
										 $this->db->select("*");
										$query = $this->db->get_where('property_payment_check',array('user_id'=>$transData[0]['payee_id'],'property_id'=>$propertyId,'status'=>'Active'));
										$rslt = $query->result_array();
										if(count($rslt)>0){
											$paid_to = $rslt[0]['paid_to'];
										
											$paidToProfile = $this->assetsapi_model->profile($paid_to);
											
											$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
											if(!empty($paidToProfile['assets_address'])){
												 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
											 }else{
												 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
											 }
											$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
											$Billed_BY_EMAIL = $paidToProfile['email'];
										
										}else{
											$dataProperty = $this->assetsapi_model->property_details($propertyId);
											$paid_to = $dataProperty[0]['owner_id'];
										
											$paidToProfile = $this->assetsapi_model->profile($paid_to);
											$Billed_BY_NAME = $paidToProfile['first_name'].' '.$paidToProfile['last_name'];
											if(!empty($paidToProfile['assets_address'])){
												 $Billed_BY_ADDRESS  = $paidToProfile['assets_address'];
											 }else{
												 $Billed_BY_ADDRESS  = $paidToProfile['city'].", ".$paidToProfile['state'].", ".$paidToProfile['country'].", ".$paidToProfile['zip_code'];
											 }
											$Billed_BY_MOBILE = $paidToProfile['mobile_no'];
											$Billed_BY_EMAIL = $paidToProfile['email'];
										}
										
										$this->db->select("*");
										$query1 = $this->db->get_where('property_tb',array('id'=>$propertyId,'status'=>'1'));
										$rslt1 = $query1->result_array();
										// echo $this->db->last_query();
										// print_r($rslt1);
										$property = $rslt1[0]['title'];
										$RENT_PAID_DATE = date('m/d/Y H:i:s',strtotime($transactiondate));
										$InvoiceTokensArr = array(
										'PAYEE_NAME' => $payeeName,
										'PAYEE_ADDRESS' => $payeeaddress,
										'PAYEE_MOBILE' => $payeeMobile,
										'PAYEE_EMAIL' => $payeeEmail,
										'Billed_BY_NAME' => $Billed_BY_NAME,
										'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
										'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
										'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
										 'PAID_FOR'=> $paidFor,
										 'PAID_FOR_MONTH'=> $paid_for_month,
										 'RENT_PAID_DATE'=> $RENT_PAID_DATE,
										 'AMOUNT'=> number_format($actualAmt,2),
										 'PROPERTY'=> $property,
										 'TAX_AMOUNT'=> number_format($TaxAmount,2),
										 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
										 'INVOICE'=>$invoice_number,
										 'INVOICE_DATE'=>$transactiondate
										);
									$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
								 }
									
									
				$retres['success']=1;
				$retres['msg']= "Your cheque submitted successfully.!!!";
			}else{
				$retres['success']=0;
				$retres['msg']= "Something went wrong. Please try later.!!!";
				}
				// echo $this->db->last_query();
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function SendMailForPlanExpireReminder(){
			$PlanExpireInfo = $this->assetsapi_model->getPlanExpireInfo();

			if(count($PlanExpireInfo)>0)
			{
				foreach($PlanExpireInfo as $info){
			//========================Mail Invoice====================================================
				$to_email = $info['Email'];
				$from_email = "info@assetswatch.com";
				$PERFilename = 'plan_expire.txt';
				$PERTemplate = read_file('assets/email_template/'.$PERFilename);
				$PERSubject = "Plan Expire Reminder";
				$title = "Plan Expire Reminder";
				
				$MSG = "As per your current plan will expire on ".date('m/d/Y',strtotime($info['ExpireDate']))." so please pay the plan amount or else will your plan will down grade to Basic Plan.";
				// $reacturl = $this->config->item('reacturl');
				// $url = "<br/><a href='".$reacturl."' style='text-decoration: none;color: #FFFFFF;font-size: 17px;font-weight: 400;line-height: 120%;padding: 9px 26px;margin: 0;text-decoration: none;border-collapse: collapse;border-spacing: 0;border-radius: 4px;-webkit-border-radius: 4px;text-align: -webkit-center;vertical-align: middle;background-color: rgb(87, 187, 87);-moz-border-radius: 4px;-khtml-border-radius: 4px;'>Login</a>";

				$PERTokensArr = array(
						'USER_NAME' => $info['Name'],
						 'MSG'=> $MSG,
						);
				/*
					You can easily have your cron job execute any script like this:
					* * * * * curl --silent --compressed <a href="http://your.site/send/send_email">http://your.site/send/send_email</a> >/dev/null 2>&1
				*/
				$PERMail = $this->send_mail($from_email,$to_email,$PERSubject,$PERTokensArr,$PERTemplate);
					/* if($PERMail){
						echo "Sended";
					}else{
						else "Failed"
					 }*/
				}
			}
		}
		public function downgradingPlan(){
			$downgradingPlan = $this->assetsapi_model->downgradingPlan();
			
			 if(count($downgradingPlan)>0)
			 {
				foreach($downgradingPlan as $info){
					$planId = $info['planId'];
					$assets_id = $info['assets_id'];
					$update = $this->db->update('registration_tb',array('plan_id'=>$planId),array('assets_id'=>$assets_id));
				}
					
			 }
		}
		
		public function change_status_rejected()
		{
			$request = json_decode(file_get_contents('php://input'), true);
			
			
			$agreementData = array(
				'property_id'=>$request['property_id'],
				 'user_id'=>$request['user_id'],
				 'status'=>$request['status']
				);
				
				$retres=array();
			
				$result = $this->assetsapi_model->change_status_rejected($agreementData);
				if($result)
				{
					$retres['success']=1;
					// if($request['status']==="Completed"){
						$retres['msg']="Agreement ".$request['status']." successfully. !!!";
					// }
					
					$dealDetailQ = $this->db->get_where('property_deal_tb',array('sender_id'=>$request['user_id'],'property_id'=>$request['property_id'],'status'=>'Completed'));
					$dealDetail = $dealDetailQ->result_array();
					foreach($dealDetail as $val){
						$profileSender = $this->assetsapi_model->profile($val['receiver_id']);
						$SenderAssets_type  = $profileSender['assets_type'];
						$senderAssetsType = $this->assetsapi_model->getAssetsType($SenderAssets_type);
						$SenderName  = $profileSender['first_name'].' '.$profileSender['last_name'];
						$notiData = array(
											'sender'=>$request['user_id'],
											'receiver'=>$val['receiver_id'],
											'message' => $SenderName.' has '.$request["status"].' property agreement.'
											
										);
						$notifyInsert = $this->db->insert('notification_tb',$notiData);
					}
					
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="Somthing went wrong please try again.!!!";
					
				}
		
			$retres=json_encode($retres);
			echo $retres;
		}
		
		public function agreement_payment(){
			$request = json_decode(file_get_contents('php://input'), true);
			
			 $partnerkey = $this->config->item('partnerkey');
			$partnerid = $this->config->item('partnerid');
			$transactiontype = $this->config->item('transactiontype');
			
			$userData = $this->assetsapi_model->profile($request["userid"]);
			//$planData = $this->assetsapi_model->planDeatilBy($plan_id);
			
			$first_name = $userData['first_name'];
			$last_name = $userData['last_name'];
			$address = $userData['city']." ".$userData['state']." ".$userData['country']." ".$userData['zip_code'];
			$city = $userData['city'];
			
			$state = $userData['state'];
			$StateCodeQ = $this->db->get_where('uvw_country_states',array('state_name'=>$state));
			$stateRslt = $StateCodeQ->result_array();
			if(count($stateRslt)>0){
				$stateCode = $stateRslt[0]['state_2_code'];
			}else{
				$stateCode = null;
			}
			
						
			$country = $userData['country'];
			$CountryQuery = $this->db->get_where('countries',array('name'=>$country));
			$countryRslt = $CountryQuery->result_array();
			if(count($countryRslt)>0){
				$countryCode = $countryRslt[0]['sortname'];
			}else{
				$countryCode = '';
			}
			
			
			$zip = $userData['zip_code'];
			$email = $userData['email'];
			//$orderid = $this->session->userdata('orderid');
			//$explodeName = explode(' ' ,$_POST['name'])
			//$firstName = (!empty($explodeName[0]))?$explodeName[0]:'';
			//$lastName = (!empty($explodeName[1]))?$explodeName[1]:'';
			//$expirymmyy = date('m',strtotime($_POST['month'])).date('y',strtotime($_POST['year']));
			if($request['type']==='CC'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"expirymmyy"=>$request["expirymmyy"],
				"cvv"=>$request["cvv"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
				
			}else if($request['type']==='ACH'){
				$datatosend = array(
				"partnerkey"=>$partnerkey,
				"partnerid"=>$partnerid,
				"transactiontype"=>$transactiontype,
				"tokenizedaccountnumber"=>$request["tokenizedaccountnumber"],
				"paymentmode"=>$request["paymentmode"],
				"transactionamount"=>$request["transactionamount"],
				"routingnumber"=>$request["routingnumber"],
				"surchargeamount"=>$request["surchargeamount"],
				"currency"=>$request["currency"],
				"payeefirstname"=>$first_name,
				"payeelastname"=>$last_name,
				"address"=>$address,
				"city"=>$city,
				"state"=>$stateCode,
				"country"=>$countryCode,
				"zip"=>$zip,
				"email"=>$email,
				"transactionreference"=>$request["transactionreference"],
				"orderid"=>$request["orderid"],
				"payeeid"=>$request["payeeid"],
				"notifypayee"=>$request["notifypayee"],
				"profile"=>$request["profile"],
				"profileid"=>$request["profileid"]
				);
			}
			$this->db->order_by('transactiondate',"desc");
						$this->db->limit(1);
						$query = $this->db->get('transaction_tb');
						 $lastRecord = $query->result_array();
					  if($lastRecord[0]['invoice_number']!='' || $lastRecord[0]['invoice_number']!=null ){
						  $inv = $lastRecord[0]['invoice_number'];
						  
						    $inv_number = ++$inv;
					  }else{
						  $inv_number = 'AWLLC000001';
					  }
					  
					   $invoice_number = $inv_number;
					   $datatoinsertTrans = array( 
									'invoice_number' => $invoice_number,
									'plan_id'=>$userData['plan_id'],
									'user_id'=>$request["userid"],
									'orderid'=> $request["orderid"],
									// 'transactionid'=>$responseArr->transactionid,
									// 'paymentmode'=>$responseArr->paymentmode,
									// 'transaction_type'=>$responseArr->transactiontype,
									// 'transactionamount'=>$responseArr->transactionamount,
									// 'transactionreference'=>$responseArr->transactionreference,
									// 'responsecode'=>$responseArr->responsecode,
									// 'responsestatus'=>$responseArr->responsestatus,
									// 'responsemessage'=>$responseArr->responsemessage,
									// 'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate)),
									'trans_for'=>'Agreement Purchase',
									'paid_by'=>$request['type'],
									'actual_amt'=>$request['actual_amt'],
									'tax_amt'=>$request['extraAmt']
									
					   );
					   // print_r($datatoinsertTrans);
					 // $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					$insertTrans = $this->db->insert('transaction_tb',$datatoinsertTrans);
					$tx_id = $this->db->insert_id();
			//print_r($datatosend);
			//exit();
			 $jsondata = json_encode($datatosend);
			 log_message('debug',print_r($jsondata,TRUE));
				$curl = curl_init();

				curl_setopt_array($curl, array(
				  CURLOPT_URL => "https://api.singularbillpay.com/v1/transaction",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  
				 CURLOPT_POSTFIELDS => $jsondata,
				 CURLOPT_HTTPHEADER => array(
					"Content-Type: application/json"
				  ),
				));

				$response = curl_exec($curl);
				$err = curl_error($curl);

				curl_close($curl);

				if ($err) {
				  echo "cURL Error #:" . $err;
				} else {
					// print_r($response);
				  //echo $response;
				  $txn_id = $this->session->userdata('txn_no');
				   log_message('debug',print_r($response,TRUE));
				   
				  $responseArr = json_decode($response);//
				   if(count($responseArr)>0 ){
				  if($request["orderid"] == $responseArr->orderid)
				  {
					  
					  $datatoupdate = array( 
									
									'transactionid'=>$responseArr->transactionid,
									'paymentmode'=>$responseArr->paymentmode,
									'transaction_type'=>$responseArr->transactiontype,
									'transactionamount'=>$responseArr->transactionamount,
									'transactionreference'=>$responseArr->transactionreference,
									'responsecode'=>$responseArr->responsecode,
									'responsestatus'=>$responseArr->responsestatus,
									'responsemessage'=>$responseArr->responsemessage,
									'transactiondate'=>date('Y-m-d H:i:s',strtotime($responseArr->transactiondate))
									
									
					   );
					   // print_r($datatoinsertTrans);
					  $update = $this->db->update('transaction_tb',$datatoupdate,array('orderid'=>$request["orderid"]));
					  
					$currDate = date('Y-m-d');
					
					if(isset($request['validity']) && !empty($request['validity']))
					{
						if($request['validity']=="Monthly"){
							$expiry_date = date('Y-m-d H:i:s', strtotime('+1 months'));
						}else if($request['validity']=="Yearly"){
							$expiry_date = date('Y-m-d H:i:s', strtotime('+1 Year'));
						}else{
							$expiry_date = '';
						}
					}else{
						$expiry_date = '';
					}
					$datatoinsertAgree = array( 
								'tx_id'=>$tx_id,
									'user_id'=>$request["userid"],
									'agreement_id'=>$request["templateId"],
									  'expiry_date'=>$expiry_date
					   );
					   if($responseArr->responsestatus==='APPROVED'){
					$insert = $this->db->insert('agreement_purchase_tb',$datatoinsertAgree);
					   }
					
				  }
				
			 $retres=array();
			 if($request["orderid"] == $responseArr->orderid && $responseArr->responsestatus==='APPROVED')
			 {
					 $retres['success']=1;
					 $retres['msg']='Agreement Purchased Successfully.!!!';
					 //========================Mail Invoice====================================================
					 $settingInfo = $this->assetsapi_model->getEmailSmsSettingInfo($request["userid"]);
						
						if($settingInfo){
								if($settingInfo['email']==='ON'){
									$to_email = $email;
									$from_email = "info@assetswatch.com";
									$InvoiceFilename = 'invoice_template_transaction.txt';
									$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
									$InvoiceSubject = "Invoice For Agreement Purchase";
									
									$transactionamount = $responseArr->transactionamount;
									$transData = $this->assetsapi_model->getTransactionBy($invoice_number);
					
								 $transactionamount = $transData[0]['transactionamount'];
								 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
								 $TaxAmount = 0;
								 // $TotAmount = $transactionamount + $TaxAmount;
								 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					
						 $this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('agreement_purchase_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('agreement_tb a','a.agreement_id=B.agreement_id','LEFT');
							$this->db->where('invoice_number',$invoice_number);
							$Agquery = $this->db->get();
							$AgRslt = $Agquery->result_array();
							  // print_r($AgRslt);
						  $title = $transData[0]['trans_for'];
						  $relatedTitle = "Agreement";
						  $relatedName = $AgRslt[0]['agreement_title'];
					 
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
									$InvoiceTokensArr = array(
										'PAYEE_NAME' => $payeeName,
										'PAYEE_ADDRESS' => $payeeaddress,
										'PAYEE_MOBILE' => $payeeMobile,
										'PAYEE_EMAIL' => $payeeEmail,
										// 'Billed_BY_NAME' => $Billed_BY_NAME,
										// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
										// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
										// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
										 // 'PAID_FOR'=> $paidFor,
										 // 'PAID_FOR_MONTH'=> $paid_for_month,
										 'RELATED_TITLE'=>$relatedTitle,
										  'RELATED_NAME'=>$relatedName,
										 'AMOUNT'=> number_format($actualAmt,2),
										  'TITLE'=> $title,
										 'TAX_AMOUNT'=> number_format($TaxAmount,2),
										 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
										 'INVOICE'=>$invoice_number,
										 'INVOICE_DATE'=>$transactiondate
										);
									$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
								}
						}else{
							$to_email = $email;
									$from_email = "info@assetswatch.com";
									$InvoiceFilename = 'invoice_template_transaction.txt';
									$InvoiceTemplate = read_file('assets/email_template/'.$InvoiceFilename);
									$InvoiceSubject = "Invoice For Agreement Purchase";
									
									$transactionamount = $responseArr->transactionamount;
									$transData = $this->assetsapi_model->getTransactionBy($invoice_number);
					
								 $transactionamount = $transData[0]['transactionamount'];
								 if(!empty($transData[0]['assets_address'])){
									 $payeeaddress  = $transData[0]['assets_address'];
								 }else{
									 $payeeaddress  = $transData[0]['city'].", ".$transData[0]['state'].", ".$transData[0]['country'].", ".$transData[0]['zip_code'];
								 }
								 
								 $TaxAmount = 0;
								 // $TotAmount = $transactionamount + $TaxAmount;
								 $PlanName =  $this->assetsapi_model->getPlanName($transData[0]['plan_id']);
					 
					
						 $this->db->select("*");
							$this->db->from('transaction_tb T');
							$this->db->join('agreement_purchase_tb B','T.txn_id=B.tx_id','LEFT');
							$this->db->join('agreement_tb a','a.agreement_id=B.agreement_id','LEFT');
							$this->db->where('invoice_number',$invoice_number);
							$Agquery = $this->db->get();
							$AgRslt = $Agquery->result_array();
							  // print_r($AgRslt);
						  $title = $transData[0]['trans_for'];
						  $relatedTitle = "Agreement";
						  $relatedName = $AgRslt[0]['agreement_title'];
					 
					
					 $transactiondate = $transData[0]['transactiondate'];
					 $payeeName = $transData[0]['name'];
					$payeeMobile = $transData[0]['mobile_no'];
					$payeeEmail = $transData[0]['email'];
					
					  $PayBy = $transData[0]['paid_by'];
					  $actualAmt = $transData[0]['actual_amt'];
						 
						  $TaxAmount =$transData[0]['tax_amt'];
									$InvoiceTokensArr = array(
										'PAYEE_NAME' => $payeeName,
										'PAYEE_ADDRESS' => $payeeaddress,
										'PAYEE_MOBILE' => $payeeMobile,
										'PAYEE_EMAIL' => $payeeEmail,
										// 'Billed_BY_NAME' => $Billed_BY_NAME,
										// 'Billed_BY_ADDRESS' => $Billed_BY_ADDRESS,
										// 'Billed_BY_MOBILE' => $Billed_BY_MOBILE,
										// 'Billed_BY_EMAIL' => $Billed_BY_EMAIL,
										 // 'PAID_FOR'=> $paidFor,
										 // 'PAID_FOR_MONTH'=> $paid_for_month,
										 'RELATED_TITLE'=>$relatedTitle,
										  'RELATED_NAME'=>$relatedName,
										 'AMOUNT'=> number_format($actualAmt,2),
										  'TITLE'=> $title,
										 'TAX_AMOUNT'=> number_format($TaxAmount,2),
										 'TOTAL_AMOUNT'=> number_format(floatval(str_replace(",","",$transactionamount)),2),
										 'INVOICE'=>$invoice_number,
										 'INVOICE_DATE'=>$transactiondate
										);
							$InvoceMail = $this->send_mail($from_email,$to_email,$InvoiceSubject,$InvoiceTokensArr,$InvoiceTemplate);
						}
				
					 //$retres['payment']=$responseArr;
								
			 }else{
					 $retres['success']=0;
					 $retres['msg']=$responseArr->responsemessage;
					
				 }
			}else{
					 $retres['success']=0;
					 $retres['msg']=$responseArr->responsemessage;
					
				 }
			} 
				 $retres=json_encode($retres);
				 echo $retres;
		}
	//============================================================================================================
	public function check_agreement_payment($userId,$agreementId){
		
		$rslt = $this->assetsapi_model->check_agreement_payment($userId,$agreementId);
		$retres=array();
				if($rslt)
				{
					$retres['success']=1;
					$retres['agreement_payment']=$rslt;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data available.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//============================================================================================================
	public function plan_upgrade_report($userId){
		
		$rslt = $this->assetsapi_model->plan_upgrade_report($userId);
		$retres=array();
				if($rslt)
				{
					$retres['success']=1;
					$retres['plan_upgrade_report']=$rslt;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data available.!!!";
					
				}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//===========================user search =====================================
	public function service_provider_search($request=array())
	{
		
		$request = json_decode(file_get_contents('php://input'), true);
		
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->service_provider_search($request);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['search_userlist']=$result;
				
			}else{
					$retres['success']=0;
					$retres['msg']="No records found.!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	
	//===========================email_sms_notification =====================================
	public function email_sms_notification($request=array())
	{
		
		$request = json_decode(file_get_contents('php://input'), true);
		
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->email_sms_notification($request);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Setting updated successfully.";
				
			}else{
					$retres['success']=0;
					$retres['msg']="Something went wrong.Please try later!!!";
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
		$retres=json_encode($retres);
		echo $retres;
	}
	 
	 //============================================================================================================
	public function get_settings_information($userId,$session_id){
		
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
		
			$rslt = $this->assetsapi_model->getEmailSmsSettingInfo($userId);
			$retres=array();
				if($rslt)
				{
					$retres['success']=1;
					$retres['settings_information']=$rslt;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data available.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	 //============================================================================================================
	public function manage_branding($request=array()){
		$request = json_decode(file_get_contents('php://input'), true);
		$validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
		
			$result = $this->assetsapi_model->manage_branding($request);
			$retres = array();
			if($result)
			{
				$retres['success']=1;
				$retres['msg']="Setting updated successfully.";
				
			}else{
					$retres['success']=0;
					$retres['msg']="Something went wrong.Please try later!!!";
					
			}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//============================================================================================================
	public function get_branding_information($userId,$session_id){
		
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
		
			$rslt = $this->assetsapi_model->getBrandingInfo($userId);
			$retres=array();
				if($rslt)
				{
					$retres['success']=1;
					$retres['branding_information']=$rslt;
					
					
				}else{
					$retres['success']=0;
					$retres['msg']="No data available.!!!";
					
				}
			}else{
					$retres['success']=0;
					$retres['msg']="Unauthorised User.!!!";
		}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function connection_history($userid,$assets_type,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true);
		// $requestData = array(
				
				// 'assets_type' => $request['assets_type']
				
			// );
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->connection_history($userid,$assets_type);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['connection_history']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function property_history($userid,$session_id)
    {
		// $request = json_decode(file_get_contents('php://input'), true);
		// $requestData = array(
				
				// 'assets_type' => $request['assets_type']
				
			// );
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->property_history($userid);
			$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['property_history']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function getBgvCharges()
	{
		
		$result = $this->assetsapi_model->getBgvCharges();
		$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['bgvInfo']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	public function bgv_info_by($pkgId)
	{
		
		$result = $this->assetsapi_model->bgv_info_by($pkgId);
		$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['bgvPkgInfo']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	public function getPaymentCharges($type)
	{
		
		$result = $this->assetsapi_model->getPaymentCharges($type);
		$retres=array();
			if($result)
			{
				$retres['success']=1;
				//$retres['msg']="Invitation Accepted successfully.";
				$retres['paymentCharges']=$result;
			}
			else{
				$retres['success']=0;
				$retres['msg']='No data found !!!';
					
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function connected_owner_properties($assets_id,$session_id)
	{
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->connected_owner_properties($assets_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['connected_owner_properties']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function property_list_broker_agreement($assets_id,$optionName)
	{

		
			$result = $this->assetsapi_model->property_list_broker_agreement($assets_id,$optionName);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['property_list_broker_agreement']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function propertyOwnerList($assets_id)
	{

		
			$result = $this->assetsapi_model->propertyOwnerList($assets_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['propertyOwnerList']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	//=========================================================================================================
	public function filterowner_property($assets_id)
	{

		
			$result = $this->assetsapi_model->filterowner_property($assets_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['filterowner_property']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//========================================  Agreement PDF ===========================================
	public function  agreement_template_pdf_view($assets_id,$agreement_id,$session_id){
		$validate = $this->assetsapi_model->getSessionValidate($session_id);
			if($validate)
			{
				$record = $this->assetsapi_model->agreement_template_pdf_view($agreement_id);
				
			// print_r($brandingData);
			$pdf = new MyCustomPDFWithWatermark(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
					
					$userId =$assets_id;
					$brandingData = $this->assetsapi_model->getBrandingInfo($userId);
					if($brandingData){
						$branding = $brandingData['branding'];
							$headerContent = $brandingData['header_title'];
							$footerContent = $brandingData['footer_title'];
							$headerImage = $brandingData['branding_logo'];
							$watermarkImage = $brandingData['branding_watermark'];
					}else{
						$branding = 'Default';
						$headerContent = '';
						$footerContent = '';
						$headerImage = '';
						$watermarkImage = '';
					}
					
					$html = $record[0]['description'];
					
					$template = array('headerContent'=>$headerContent,'footerContent'=>$footerContent,'headerImage'=>$headerImage,'watermarkImage'=>$watermarkImage,'branding'=>$branding);
					$pdf->setData($template);
					
					$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 006', PDF_HEADER_STRING);
					
					// set header and footer fonts
						$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
						$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

						// set default monospaced font
						$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
					
					// set margins
					$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
					$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
					$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
					
					$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);//, 70,120, 57, 25, '', '', '', false, 300, '', false, false, 0);
					
					$pdf->SetFont('times', '', 8, '', false); 
						
					$pdf->AddPage();
					$pdf->writeHTML($html, true, false, true, false, '');
					ob_clean();
					
					$fileName = 'agreement_template.pdf';
					 $pdf->Output($fileName,'I'); 
			}else{
					$retres['success']=0;
						$retres['msg']="Unauthorised User.!!!";
			}
		}
		
		//=================================================newsletter============================================================
	public function store_document_information($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->store_document_information($request);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Saved successfully.";
				}
				else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong.!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	//=========================================================================================================
	public function get_document_info($userId,$session_id)
	{
			$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
		
			$result = $this->assetsapi_model->get_document_info($userId);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['documentInfo']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function delete_document($userId,$docId,$session_id)
	{

			$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$dataInfo = $this->assetsapi_model->get_document_info_by($userId,$docId);
			$path_to_file = $dataInfo['doc_path'];
			if(!empty($path_to_file)){
				unlink($path_to_file);
			}
			
			
			 $result = $this->db->delete('document_tb',array('id'=>$docId,'userId'=>$userId));
			
			$retres=array();
				if($result)
				{ 
					
				   $this->db->select("*,DATE_FORMAT(issue_date,'%d %M %Y') as issueDate,DATE_FORMAT(expires_date,'%d %M %Y') as expireDate");
					$query = $this->db->get_where('document_tb',array('userId'=>$userId));
					if($query->num_rows() > 0){
						$rslt = $query->result_array();
						$retres['documentList']=$rslt; 
					}
					$retres['success']=1;
					$retres['msg']="Document deleted successfully.";
					
					
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function get_document_info_by($userId,$docId,$session_id)
	{

			$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->get_document_info_by($userId,$docId);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['doc_info']=$result;
					
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function get_templates_by($userId,$session_id)
	{

			$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->get_templates_by($userId);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['template_list']=$result;
					
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function agreement_replace_values($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->agreement_replace_values($request);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['replacedTemplate']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong.!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function template_agreement_send($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->template_agreement_send($request);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Agreement Send Sucessfully";
				}
				else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong.!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function owner_list($userid,$propertyId,$session_id){
		 $validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->owner_list($userid,$propertyId);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['ownerList']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data available!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function tenant_list($user_id,$session_id){
		 $validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->tenant_list($user_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['tenantList']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data available!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	
	//=============================================================================================================
	public function agreement_partner_signature($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->agreement_partner_signature($request);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Saved Sucessfully";
				}
				else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong.!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function get_partner_detail_by($user_id,$session_id){
		 $validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->get_partner_detail_by($user_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['partnerSignInfo']=$result;
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data available!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function partner_sign_status_update($request=array()){
		 $request = json_decode(file_get_contents('php://input'), true);  
		 $validate = $this->assetsapi_model->getSessionValidate($request['session_id']);
		if($validate)
		{
			$result = $this->assetsapi_model->partner_sign_status_update($request);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Saved Sucessfully";
				}
				else{
					$retres['success']=0;
					$retres['msg']='Somthing went wrong.!!!';
						
				}
		}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=============================================================================================================
	public function partenerinfo_by_deal($deal_id){
		 
			$result = $this->assetsapi_model->partenerinfo_by_deal($deal_id);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					$retres['msg']="Already added partners for this deal.";
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data available!!!';
						
				}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//=========================================================================================================
	public function templates_by($userId,$session_id)
	{

			$validate = $this->assetsapi_model->getSessionValidate($session_id);
		if($validate)
		{
			$result = $this->assetsapi_model->templates_by($userId);
			$retres=array();
				if($result)
				{
					$retres['success']=1;
					//$retres['msg']="Invitation Accepted successfully.";
					$retres['template_list']=$result;
					
				}
				else{
					$retres['success']=0;
					$retres['msg']='No data found !!!';
						
				}
			}else{
					$retres['success']=0;
					$retres['msg']='Unauthorised User !!!';
			}
		
			$retres=json_encode($retres);
			echo $retres;
	}
	
	//============================================================================================
	public function download_document($path){
	
		$file_path = base64_decode($path);
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.$file_path.'"');
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		//header('Content-Length: ' . filesize("http://192.168.1.11/assetsapi/assets/Agent/84/Documents/e9d0e5693dac697ef196c324e9d74f12.png")); //Absolute URL
		ob_clean();
		flush();
		readfile($file_path); //Absolute URL
		exit();
		}
		
		

}