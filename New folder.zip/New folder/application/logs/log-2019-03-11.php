<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-03-11 10:16:09 --> Config Class Initialized
INFO - 2019-03-11 10:16:09 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:16:09 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:16:09 --> Utf8 Class Initialized
INFO - 2019-03-11 10:16:09 --> URI Class Initialized
INFO - 2019-03-11 10:16:09 --> Router Class Initialized
INFO - 2019-03-11 10:16:09 --> Output Class Initialized
INFO - 2019-03-11 10:16:09 --> Security Class Initialized
DEBUG - 2019-03-11 10:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:16:09 --> Input Class Initialized
INFO - 2019-03-11 10:16:10 --> Language Class Initialized
INFO - 2019-03-11 10:16:11 --> Loader Class Initialized
INFO - 2019-03-11 10:16:11 --> Controller Class Initialized
DEBUG - 2019-03-11 10:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:16:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:16:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:16:11 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:16:11 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:16:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:16:12 --> Email Class Initialized
INFO - 2019-03-11 10:16:12 --> Database Driver Class Initialized
INFO - 2019-03-11 10:16:12 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:16:12 --> Helper loaded: file_helper
INFO - 2019-03-11 10:16:12 --> Helper loaded: download_helper
INFO - 2019-03-11 10:16:12 --> Helper loaded: form_helper
INFO - 2019-03-11 10:16:12 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:16:12 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:16:12 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:16:12 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:16:13 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 976281, 0)
INFO - 2019-03-11 10:16:13 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 10:16:33 --> Config Class Initialized
INFO - 2019-03-11 10:16:33 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:16:33 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:16:33 --> Utf8 Class Initialized
INFO - 2019-03-11 10:16:33 --> URI Class Initialized
INFO - 2019-03-11 10:16:33 --> Router Class Initialized
INFO - 2019-03-11 10:16:33 --> Output Class Initialized
INFO - 2019-03-11 10:16:33 --> Security Class Initialized
DEBUG - 2019-03-11 10:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:16:33 --> Input Class Initialized
INFO - 2019-03-11 10:16:33 --> Language Class Initialized
INFO - 2019-03-11 10:16:33 --> Loader Class Initialized
INFO - 2019-03-11 10:16:33 --> Controller Class Initialized
DEBUG - 2019-03-11 10:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:16:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:16:33 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:16:33 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:16:33 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:16:33 --> Email Class Initialized
INFO - 2019-03-11 10:16:33 --> Database Driver Class Initialized
INFO - 2019-03-11 10:16:33 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:16:33 --> Helper loaded: file_helper
INFO - 2019-03-11 10:16:33 --> Helper loaded: download_helper
INFO - 2019-03-11 10:16:33 --> Helper loaded: form_helper
INFO - 2019-03-11 10:16:33 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:16:33 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:16:33 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:16:33 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:16:33 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 159558, 0)
INFO - 2019-03-11 10:16:33 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 10:17:37 --> Config Class Initialized
INFO - 2019-03-11 10:17:37 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:17:37 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:17:37 --> Utf8 Class Initialized
INFO - 2019-03-11 10:17:37 --> URI Class Initialized
INFO - 2019-03-11 10:17:37 --> Router Class Initialized
INFO - 2019-03-11 10:17:37 --> Output Class Initialized
INFO - 2019-03-11 10:17:37 --> Security Class Initialized
DEBUG - 2019-03-11 10:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:17:37 --> Input Class Initialized
INFO - 2019-03-11 10:17:37 --> Language Class Initialized
INFO - 2019-03-11 10:17:37 --> Loader Class Initialized
INFO - 2019-03-11 10:17:37 --> Controller Class Initialized
DEBUG - 2019-03-11 10:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:17:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:17:37 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:17:37 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:17:37 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:17:37 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:17:37 --> Email Class Initialized
INFO - 2019-03-11 10:17:37 --> Database Driver Class Initialized
INFO - 2019-03-11 10:17:37 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:17:37 --> Helper loaded: file_helper
INFO - 2019-03-11 10:17:37 --> Helper loaded: download_helper
INFO - 2019-03-11 10:17:37 --> Helper loaded: form_helper
INFO - 2019-03-11 10:17:37 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:17:37 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:17:37 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:17:38 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:17:38 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 685965, 0)
INFO - 2019-03-11 10:17:38 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 10:23:16 --> Config Class Initialized
INFO - 2019-03-11 10:23:16 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:23:16 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:23:16 --> Utf8 Class Initialized
INFO - 2019-03-11 10:23:16 --> URI Class Initialized
INFO - 2019-03-11 10:23:16 --> Router Class Initialized
INFO - 2019-03-11 10:23:16 --> Output Class Initialized
INFO - 2019-03-11 10:23:16 --> Security Class Initialized
DEBUG - 2019-03-11 10:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:23:16 --> Input Class Initialized
INFO - 2019-03-11 10:23:16 --> Language Class Initialized
INFO - 2019-03-11 10:23:17 --> Loader Class Initialized
INFO - 2019-03-11 10:23:17 --> Controller Class Initialized
DEBUG - 2019-03-11 10:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:23:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:23:17 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:23:17 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:23:17 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:23:17 --> Email Class Initialized
INFO - 2019-03-11 10:23:17 --> Database Driver Class Initialized
INFO - 2019-03-11 10:23:17 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:23:17 --> Helper loaded: file_helper
INFO - 2019-03-11 10:23:17 --> Helper loaded: download_helper
INFO - 2019-03-11 10:23:17 --> Helper loaded: form_helper
INFO - 2019-03-11 10:23:17 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:23:17 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:23:17 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:23:17 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:23:17 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 748892, 0)
INFO - 2019-03-11 10:23:17 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 10:30:58 --> Config Class Initialized
INFO - 2019-03-11 10:30:58 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:30:58 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:30:58 --> Utf8 Class Initialized
INFO - 2019-03-11 10:30:58 --> URI Class Initialized
INFO - 2019-03-11 10:30:58 --> Router Class Initialized
INFO - 2019-03-11 10:30:58 --> Output Class Initialized
INFO - 2019-03-11 10:30:58 --> Security Class Initialized
DEBUG - 2019-03-11 10:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:30:58 --> Input Class Initialized
INFO - 2019-03-11 10:30:58 --> Language Class Initialized
INFO - 2019-03-11 10:30:58 --> Loader Class Initialized
INFO - 2019-03-11 10:30:58 --> Controller Class Initialized
DEBUG - 2019-03-11 10:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:30:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:30:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:30:58 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:30:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:30:58 --> Email Class Initialized
INFO - 2019-03-11 10:30:58 --> Database Driver Class Initialized
INFO - 2019-03-11 10:30:58 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:30:58 --> Helper loaded: file_helper
INFO - 2019-03-11 10:30:58 --> Helper loaded: download_helper
INFO - 2019-03-11 10:30:58 --> Helper loaded: form_helper
INFO - 2019-03-11 10:30:58 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:30:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:30:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:30:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:30:58 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 979543, 0)
INFO - 2019-03-11 10:30:58 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 10:31:41 --> Config Class Initialized
INFO - 2019-03-11 10:31:41 --> Hooks Class Initialized
DEBUG - 2019-03-11 10:31:41 --> UTF-8 Support Enabled
INFO - 2019-03-11 10:31:41 --> Utf8 Class Initialized
INFO - 2019-03-11 10:31:41 --> URI Class Initialized
INFO - 2019-03-11 10:31:41 --> Router Class Initialized
INFO - 2019-03-11 10:31:41 --> Output Class Initialized
INFO - 2019-03-11 10:31:41 --> Security Class Initialized
DEBUG - 2019-03-11 10:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 10:31:41 --> Input Class Initialized
INFO - 2019-03-11 10:31:41 --> Language Class Initialized
INFO - 2019-03-11 10:31:41 --> Loader Class Initialized
INFO - 2019-03-11 10:31:41 --> Controller Class Initialized
DEBUG - 2019-03-11 10:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 10:31:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 10:31:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 10:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 10:31:41 --> Helper loaded: url_helper
DEBUG - 2019-03-11 10:31:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 10:31:41 --> Email Class Initialized
INFO - 2019-03-11 10:31:41 --> Database Driver Class Initialized
INFO - 2019-03-11 10:31:41 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 10:31:41 --> Helper loaded: file_helper
INFO - 2019-03-11 10:31:41 --> Helper loaded: download_helper
INFO - 2019-03-11 10:31:41 --> Helper loaded: form_helper
INFO - 2019-03-11 10:31:41 --> Form Validation Class Initialized
DEBUG - 2019-03-11 10:31:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 10:31:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 10:31:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 10:31:41 --> Query error: Column 'owner_type' cannot be null - Invalid query: INSERT INTO `registration_tb` (`owner_type`, `first_name`, `last_name`, `email`, `password`, `city`, `state`, `country`, `zip_code`, `mobile_no`, `landline_no`, `assets_type`, `company_name`, `website_url`, `agent_type`, `account_id`, `status`) VALUES (NULL, NULL, NULL, NULL, 'T0ZPZHl0VVI0RzlDTjdjbmI0bm5CQT09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', 324467, 0)
INFO - 2019-03-11 10:31:41 --> Language file loaded: language/english/db_lang.php
INFO - 2019-03-11 11:08:08 --> Config Class Initialized
INFO - 2019-03-11 11:08:08 --> Config Class Initialized
INFO - 2019-03-11 11:08:08 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:08:09 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:09 --> Config Class Initialized
INFO - 2019-03-11 11:08:09 --> Config Class Initialized
INFO - 2019-03-11 11:08:09 --> Hooks Class Initialized
INFO - 2019-03-11 11:08:09 --> Hooks Class Initialized
INFO - 2019-03-11 11:08:09 --> Hooks Class Initialized
INFO - 2019-03-11 11:08:09 --> Utf8 Class Initialized
DEBUG - 2019-03-11 11:08:09 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 11:08:09 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 11:08:09 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:09 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:09 --> URI Class Initialized
INFO - 2019-03-11 11:08:09 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:09 --> URI Class Initialized
INFO - 2019-03-11 11:08:09 --> Router Class Initialized
INFO - 2019-03-11 11:08:09 --> Output Class Initialized
INFO - 2019-03-11 11:08:09 --> Security Class Initialized
DEBUG - 2019-03-11 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:09 --> Input Class Initialized
INFO - 2019-03-11 11:08:09 --> Language Class Initialized
INFO - 2019-03-11 11:08:09 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:09 --> URI Class Initialized
INFO - 2019-03-11 11:08:09 --> Loader Class Initialized
INFO - 2019-03-11 11:08:09 --> Router Class Initialized
INFO - 2019-03-11 11:08:09 --> URI Class Initialized
INFO - 2019-03-11 11:08:09 --> Router Class Initialized
INFO - 2019-03-11 11:08:09 --> Output Class Initialized
INFO - 2019-03-11 11:08:09 --> Security Class Initialized
DEBUG - 2019-03-11 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:09 --> Input Class Initialized
INFO - 2019-03-11 11:08:09 --> Language Class Initialized
INFO - 2019-03-11 11:08:09 --> Router Class Initialized
INFO - 2019-03-11 11:08:09 --> Output Class Initialized
INFO - 2019-03-11 11:08:09 --> Loader Class Initialized
INFO - 2019-03-11 11:08:09 --> Security Class Initialized
DEBUG - 2019-03-11 11:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:09 --> Controller Class Initialized
INFO - 2019-03-11 11:08:09 --> Output Class Initialized
INFO - 2019-03-11 11:08:09 --> Controller Class Initialized
INFO - 2019-03-11 11:08:09 --> Input Class Initialized
INFO - 2019-03-11 11:08:09 --> Language Class Initialized
DEBUG - 2019-03-11 11:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 11:08:10 --> Loader Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:10 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:10 --> Security Class Initialized
INFO - 2019-03-11 11:08:10 --> Email Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:10 --> Input Class Initialized
INFO - 2019-03-11 11:08:10 --> Language Class Initialized
INFO - 2019-03-11 11:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 11:08:10 --> Loader Class Initialized
INFO - 2019-03-11 11:08:10 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:10 --> Controller Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:10 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:10 --> Controller Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:10 --> Email Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:10 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 11:08:10 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 11:08:10 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 11:08:10 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 11:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:10 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:10 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:10 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:10 --> Email Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:10 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 11:08:10 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:10 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:10 --> Helper loaded: url_helper
INFO - 2019-03-11 11:08:10 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:10 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:10 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:10 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 11:08:10 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:10 --> Final output sent to browser
INFO - 2019-03-11 11:08:10 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:10 --> Total execution time: 1.9261
INFO - 2019-03-11 11:08:11 --> Email Class Initialized
INFO - 2019-03-11 11:08:11 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:11 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:11 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:11 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:11 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:11 --> Helper loaded: file_helper
INFO - 2019-03-11 11:08:11 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:11 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:11 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 11:08:11 --> Final output sent to browser
INFO - 2019-03-11 11:08:11 --> Final output sent to browser
DEBUG - 2019-03-11 11:08:11 --> Total execution time: 2.4761
DEBUG - 2019-03-11 11:08:11 --> Total execution time: 2.3591
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:11 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:11 --> Final output sent to browser
DEBUG - 2019-03-11 11:08:11 --> Total execution time: 2.7122
INFO - 2019-03-11 11:08:22 --> Config Class Initialized
INFO - 2019-03-11 11:08:22 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:08:22 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:22 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:22 --> URI Class Initialized
INFO - 2019-03-11 11:08:22 --> Router Class Initialized
INFO - 2019-03-11 11:08:22 --> Output Class Initialized
INFO - 2019-03-11 11:08:22 --> Security Class Initialized
DEBUG - 2019-03-11 11:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:22 --> Input Class Initialized
INFO - 2019-03-11 11:08:22 --> Language Class Initialized
INFO - 2019-03-11 11:08:22 --> Loader Class Initialized
INFO - 2019-03-11 11:08:22 --> Controller Class Initialized
DEBUG - 2019-03-11 11:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:08:22 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:22 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:22 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:22 --> Email Class Initialized
INFO - 2019-03-11 11:08:22 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:22 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:22 --> Helper loaded: file_helper
INFO - 2019-03-11 11:08:22 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:22 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:22 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:22 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:22 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:22 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:22 --> Final output sent to browser
DEBUG - 2019-03-11 11:08:22 --> Total execution time: 0.6520
INFO - 2019-03-11 11:08:47 --> Config Class Initialized
INFO - 2019-03-11 11:08:47 --> Config Class Initialized
INFO - 2019-03-11 11:08:47 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:08:47 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:47 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:48 --> URI Class Initialized
INFO - 2019-03-11 11:08:48 --> Hooks Class Initialized
INFO - 2019-03-11 11:08:48 --> Router Class Initialized
INFO - 2019-03-11 11:08:48 --> Output Class Initialized
DEBUG - 2019-03-11 11:08:48 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:48 --> Config Class Initialized
INFO - 2019-03-11 11:08:48 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:48 --> Hooks Class Initialized
INFO - 2019-03-11 11:08:48 --> Security Class Initialized
INFO - 2019-03-11 11:08:48 --> Config Class Initialized
INFO - 2019-03-11 11:08:48 --> URI Class Initialized
INFO - 2019-03-11 11:08:48 --> Router Class Initialized
INFO - 2019-03-11 11:08:48 --> Output Class Initialized
DEBUG - 2019-03-11 11:08:48 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:08:48 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:48 --> Input Class Initialized
INFO - 2019-03-11 11:08:48 --> Security Class Initialized
INFO - 2019-03-11 11:08:48 --> Utf8 Class Initialized
DEBUG - 2019-03-11 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 11:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:48 --> Language Class Initialized
INFO - 2019-03-11 11:08:48 --> Utf8 Class Initialized
INFO - 2019-03-11 11:08:48 --> Input Class Initialized
INFO - 2019-03-11 11:08:48 --> URI Class Initialized
INFO - 2019-03-11 11:08:48 --> URI Class Initialized
INFO - 2019-03-11 11:08:48 --> Router Class Initialized
INFO - 2019-03-11 11:08:48 --> Language Class Initialized
INFO - 2019-03-11 11:08:48 --> Output Class Initialized
INFO - 2019-03-11 11:08:48 --> Router Class Initialized
INFO - 2019-03-11 11:08:48 --> Security Class Initialized
INFO - 2019-03-11 11:08:48 --> Loader Class Initialized
INFO - 2019-03-11 11:08:48 --> Loader Class Initialized
INFO - 2019-03-11 11:08:48 --> Controller Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:08:48 --> Controller Class Initialized
INFO - 2019-03-11 11:08:48 --> Output Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:48 --> Helper loaded: url_helper
INFO - 2019-03-11 11:08:48 --> Security Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:48 --> Input Class Initialized
INFO - 2019-03-11 11:08:48 --> Language Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:48 --> Input Class Initialized
INFO - 2019-03-11 11:08:48 --> Language Class Initialized
INFO - 2019-03-11 11:08:48 --> Email Class Initialized
INFO - 2019-03-11 11:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 11:08:48 --> Loader Class Initialized
INFO - 2019-03-11 11:08:48 --> Controller Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:48 --> Database Driver Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 11:08:48 --> Loader Class Initialized
INFO - 2019-03-11 11:08:48 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 11:08:48 --> Controller Class Initialized
INFO - 2019-03-11 11:08:48 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:48 --> Helper loaded: download_helper
DEBUG - 2019-03-11 11:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:08:48 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:48 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:48 --> Final output sent to browser
INFO - 2019-03-11 11:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 11:08:48 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:08:48 --> Total execution time: 0.9854
DEBUG - 2019-03-11 11:08:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:48 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:49 --> Email Class Initialized
INFO - 2019-03-11 11:08:49 --> Email Class Initialized
INFO - 2019-03-11 11:08:49 --> Database Driver Class Initialized
DEBUG - 2019-03-11 11:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:08:49 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:49 --> Helper loaded: url_helper
INFO - 2019-03-11 11:08:49 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:49 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:49 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:08:49 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:49 --> Helper loaded: file_helper
INFO - 2019-03-11 11:08:49 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:49 --> Email Class Initialized
INFO - 2019-03-11 11:08:49 --> Helper loaded: download_helper
INFO - 2019-03-11 11:08:49 --> Form Validation Class Initialized
INFO - 2019-03-11 11:08:49 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:49 --> Database Driver Class Initialized
INFO - 2019-03-11 11:08:49 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:49 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:08:49 --> Helper loaded: file_helper
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 11:08:49 --> Final output sent to browser
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:49 --> Helper loaded: download_helper
DEBUG - 2019-03-11 11:08:49 --> Total execution time: 1.3762
INFO - 2019-03-11 11:08:49 --> Helper loaded: form_helper
INFO - 2019-03-11 11:08:49 --> Final output sent to browser
INFO - 2019-03-11 11:08:49 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:08:49 --> Total execution time: 1.2982
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:08:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:08:49 --> Final output sent to browser
DEBUG - 2019-03-11 11:08:49 --> Total execution time: 1.3294
INFO - 2019-03-11 11:26:51 --> Config Class Initialized
INFO - 2019-03-11 11:26:51 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:26:51 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:26:51 --> Utf8 Class Initialized
INFO - 2019-03-11 11:26:51 --> URI Class Initialized
INFO - 2019-03-11 11:26:51 --> Router Class Initialized
INFO - 2019-03-11 11:26:51 --> Output Class Initialized
INFO - 2019-03-11 11:26:51 --> Security Class Initialized
DEBUG - 2019-03-11 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:26:51 --> Input Class Initialized
INFO - 2019-03-11 11:26:51 --> Language Class Initialized
INFO - 2019-03-11 11:26:51 --> Loader Class Initialized
INFO - 2019-03-11 11:26:51 --> Controller Class Initialized
DEBUG - 2019-03-11 11:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:26:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:26:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:26:51 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:26:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:26:51 --> Email Class Initialized
INFO - 2019-03-11 11:26:51 --> Database Driver Class Initialized
INFO - 2019-03-11 11:26:51 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:26:51 --> Helper loaded: file_helper
INFO - 2019-03-11 11:26:51 --> Helper loaded: download_helper
INFO - 2019-03-11 11:26:51 --> Helper loaded: form_helper
INFO - 2019-03-11 11:26:51 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:26:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:26:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:26:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 11:26:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\assetsapi\application\models\Assetsapi_model.php 2742
INFO - 2019-03-11 11:26:52 --> Final output sent to browser
DEBUG - 2019-03-11 11:26:52 --> Total execution time: 0.7614
INFO - 2019-03-11 11:26:58 --> Config Class Initialized
INFO - 2019-03-11 11:26:58 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:26:58 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:26:58 --> Utf8 Class Initialized
INFO - 2019-03-11 11:26:58 --> URI Class Initialized
INFO - 2019-03-11 11:26:58 --> Router Class Initialized
INFO - 2019-03-11 11:26:58 --> Output Class Initialized
INFO - 2019-03-11 11:26:58 --> Security Class Initialized
DEBUG - 2019-03-11 11:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:26:58 --> Input Class Initialized
INFO - 2019-03-11 11:26:58 --> Language Class Initialized
INFO - 2019-03-11 11:26:58 --> Loader Class Initialized
INFO - 2019-03-11 11:26:58 --> Controller Class Initialized
DEBUG - 2019-03-11 11:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:26:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:26:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:26:58 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:26:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:26:58 --> Email Class Initialized
INFO - 2019-03-11 11:26:58 --> Database Driver Class Initialized
INFO - 2019-03-11 11:26:58 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:26:58 --> Helper loaded: file_helper
INFO - 2019-03-11 11:26:58 --> Helper loaded: download_helper
INFO - 2019-03-11 11:26:58 --> Helper loaded: form_helper
INFO - 2019-03-11 11:26:58 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:26:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:26:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:26:58 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 11:26:58 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\assetsapi\application\models\Assetsapi_model.php 2742
INFO - 2019-03-11 11:26:58 --> Final output sent to browser
DEBUG - 2019-03-11 11:26:58 --> Total execution time: 0.6152
INFO - 2019-03-11 11:27:47 --> Config Class Initialized
INFO - 2019-03-11 11:27:48 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:27:48 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:27:48 --> Utf8 Class Initialized
INFO - 2019-03-11 11:27:48 --> URI Class Initialized
INFO - 2019-03-11 11:27:48 --> Router Class Initialized
INFO - 2019-03-11 11:27:48 --> Output Class Initialized
INFO - 2019-03-11 11:27:48 --> Security Class Initialized
DEBUG - 2019-03-11 11:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:27:48 --> Input Class Initialized
INFO - 2019-03-11 11:27:48 --> Language Class Initialized
INFO - 2019-03-11 11:27:48 --> Loader Class Initialized
INFO - 2019-03-11 11:27:48 --> Controller Class Initialized
DEBUG - 2019-03-11 11:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:27:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:27:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:27:49 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:27:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:27:49 --> Email Class Initialized
INFO - 2019-03-11 11:27:49 --> Database Driver Class Initialized
INFO - 2019-03-11 11:27:49 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:27:49 --> Helper loaded: file_helper
INFO - 2019-03-11 11:27:49 --> Helper loaded: download_helper
INFO - 2019-03-11 11:27:49 --> Helper loaded: form_helper
INFO - 2019-03-11 11:27:49 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:27:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:27:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:27:49 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:27:49 --> Final output sent to browser
DEBUG - 2019-03-11 11:27:49 --> Total execution time: 1.7861
INFO - 2019-03-11 11:31:04 --> Config Class Initialized
INFO - 2019-03-11 11:31:04 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:31:04 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:31:04 --> Utf8 Class Initialized
INFO - 2019-03-11 11:31:04 --> URI Class Initialized
INFO - 2019-03-11 11:31:04 --> Router Class Initialized
INFO - 2019-03-11 11:31:04 --> Output Class Initialized
INFO - 2019-03-11 11:31:04 --> Security Class Initialized
DEBUG - 2019-03-11 11:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:31:04 --> Input Class Initialized
INFO - 2019-03-11 11:31:04 --> Language Class Initialized
INFO - 2019-03-11 11:31:04 --> Loader Class Initialized
INFO - 2019-03-11 11:31:04 --> Controller Class Initialized
DEBUG - 2019-03-11 11:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:31:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:31:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:31:04 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:31:04 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:31:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:31:04 --> Email Class Initialized
INFO - 2019-03-11 11:31:04 --> Database Driver Class Initialized
INFO - 2019-03-11 11:31:04 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:31:04 --> Helper loaded: file_helper
INFO - 2019-03-11 11:31:05 --> Helper loaded: download_helper
INFO - 2019-03-11 11:31:05 --> Helper loaded: form_helper
INFO - 2019-03-11 11:31:05 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:31:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:31:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:31:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
ERROR - 2019-03-11 11:31:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\assetsapi\application\models\Assetsapi_model.php 2742
INFO - 2019-03-11 11:31:05 --> Final output sent to browser
DEBUG - 2019-03-11 11:31:05 --> Total execution time: 0.5168
INFO - 2019-03-11 11:44:47 --> Config Class Initialized
INFO - 2019-03-11 11:44:47 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:44:47 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:44:47 --> Utf8 Class Initialized
INFO - 2019-03-11 11:44:47 --> URI Class Initialized
DEBUG - 2019-03-11 11:44:47 --> No URI present. Default controller set.
INFO - 2019-03-11 11:44:47 --> Router Class Initialized
INFO - 2019-03-11 11:44:47 --> Output Class Initialized
INFO - 2019-03-11 11:44:47 --> Security Class Initialized
DEBUG - 2019-03-11 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:44:48 --> Input Class Initialized
INFO - 2019-03-11 11:44:48 --> Language Class Initialized
INFO - 2019-03-11 11:44:48 --> Loader Class Initialized
INFO - 2019-03-11 11:44:48 --> Controller Class Initialized
DEBUG - 2019-03-11 11:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:44:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:44:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:44:48 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:44:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:44:48 --> Email Class Initialized
INFO - 2019-03-11 11:44:48 --> Database Driver Class Initialized
INFO - 2019-03-11 11:44:48 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:44:48 --> Helper loaded: file_helper
INFO - 2019-03-11 11:44:48 --> Helper loaded: download_helper
INFO - 2019-03-11 11:44:48 --> Helper loaded: form_helper
INFO - 2019-03-11 11:44:48 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:44:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:44:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:44:48 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:44:48 --> File loaded: D:\xampp\htdocs\assetsapi\application\views\welcome_message.php
INFO - 2019-03-11 11:44:48 --> Final output sent to browser
DEBUG - 2019-03-11 11:44:48 --> Total execution time: 0.6666
INFO - 2019-03-11 11:44:48 --> Config Class Initialized
INFO - 2019-03-11 11:44:48 --> Config Class Initialized
INFO - 2019-03-11 11:44:48 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:44:48 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:44:48 --> Utf8 Class Initialized
INFO - 2019-03-11 11:44:48 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:44:48 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:44:48 --> Utf8 Class Initialized
INFO - 2019-03-11 11:44:48 --> URI Class Initialized
INFO - 2019-03-11 11:44:48 --> Router Class Initialized
INFO - 2019-03-11 11:44:48 --> Output Class Initialized
INFO - 2019-03-11 11:44:48 --> Security Class Initialized
DEBUG - 2019-03-11 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:44:48 --> Input Class Initialized
INFO - 2019-03-11 11:44:48 --> Language Class Initialized
ERROR - 2019-03-11 11:44:48 --> 404 Page Not Found: Assets/images
INFO - 2019-03-11 11:54:24 --> Config Class Initialized
INFO - 2019-03-11 11:54:24 --> Hooks Class Initialized
DEBUG - 2019-03-11 11:54:24 --> UTF-8 Support Enabled
INFO - 2019-03-11 11:54:24 --> Utf8 Class Initialized
INFO - 2019-03-11 11:54:24 --> URI Class Initialized
INFO - 2019-03-11 11:54:24 --> Router Class Initialized
INFO - 2019-03-11 11:54:24 --> Output Class Initialized
INFO - 2019-03-11 11:54:24 --> Security Class Initialized
DEBUG - 2019-03-11 11:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 11:54:24 --> Input Class Initialized
INFO - 2019-03-11 11:54:24 --> Language Class Initialized
INFO - 2019-03-11 11:54:24 --> Loader Class Initialized
INFO - 2019-03-11 11:54:24 --> Controller Class Initialized
DEBUG - 2019-03-11 11:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 11:54:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 11:54:24 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 11:54:24 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 11:54:24 --> Helper loaded: url_helper
DEBUG - 2019-03-11 11:54:24 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 11:54:24 --> Email Class Initialized
INFO - 2019-03-11 11:54:24 --> Database Driver Class Initialized
INFO - 2019-03-11 11:54:24 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 11:54:24 --> Helper loaded: file_helper
INFO - 2019-03-11 11:54:24 --> Helper loaded: download_helper
INFO - 2019-03-11 11:54:24 --> Helper loaded: form_helper
INFO - 2019-03-11 11:54:24 --> Form Validation Class Initialized
DEBUG - 2019-03-11 11:54:24 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 11:54:24 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 11:54:24 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 11:54:24 --> Final output sent to browser
DEBUG - 2019-03-11 11:54:24 --> Total execution time: 0.5798
INFO - 2019-03-11 12:12:40 --> Config Class Initialized
INFO - 2019-03-11 12:12:40 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:12:40 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:40 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:40 --> URI Class Initialized
INFO - 2019-03-11 12:12:40 --> Router Class Initialized
INFO - 2019-03-11 12:12:40 --> Output Class Initialized
INFO - 2019-03-11 12:12:40 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:40 --> Input Class Initialized
INFO - 2019-03-11 12:12:40 --> Language Class Initialized
INFO - 2019-03-11 12:12:40 --> Loader Class Initialized
INFO - 2019-03-11 12:12:40 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:40 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:40 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:40 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:40 --> Email Class Initialized
INFO - 2019-03-11 12:12:40 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:40 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:41 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:41 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:41 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:41 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:41 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:41 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:41 --> Total execution time: 1.1211
INFO - 2019-03-11 12:12:42 --> Config Class Initialized
INFO - 2019-03-11 12:12:42 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:12:42 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:42 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:42 --> URI Class Initialized
INFO - 2019-03-11 12:12:42 --> Router Class Initialized
INFO - 2019-03-11 12:12:42 --> Output Class Initialized
INFO - 2019-03-11 12:12:42 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:42 --> Input Class Initialized
INFO - 2019-03-11 12:12:42 --> Language Class Initialized
INFO - 2019-03-11 12:12:42 --> Loader Class Initialized
INFO - 2019-03-11 12:12:42 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:42 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:42 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:42 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:42 --> Email Class Initialized
INFO - 2019-03-11 12:12:42 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:42 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:42 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:42 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:42 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:42 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:42 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:42 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:42 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:42 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:42 --> Total execution time: 0.5374
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:43 --> Config Class Initialized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:43 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:12:43 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:43 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Input Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> URI Class Initialized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
INFO - 2019-03-11 12:12:43 --> Language Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> Router Class Initialized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Input Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
INFO - 2019-03-11 12:12:43 --> Output Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:43 --> Input Class Initialized
INFO - 2019-03-11 12:12:43 --> Language Class Initialized
INFO - 2019-03-11 12:12:43 --> Loader Class Initialized
INFO - 2019-03-11 12:12:43 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:43 --> Loader Class Initialized
INFO - 2019-03-11 12:12:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:43 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:43 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:43 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:43 --> Language Class Initialized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Input Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:43 --> Security Class Initialized
INFO - 2019-03-11 12:12:43 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:43 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:43 --> Email Class Initialized
INFO - 2019-03-11 12:12:44 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:44 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:44 --> Loader Class Initialized
INFO - 2019-03-11 12:12:44 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:44 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:44 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:44 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:44 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:44 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:44 --> Language Class Initialized
INFO - 2019-03-11 12:12:44 --> Input Class Initialized
DEBUG - 2019-03-11 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:44 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:44 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:44 --> Final output sent to browser
INFO - 2019-03-11 12:12:44 --> Input Class Initialized
INFO - 2019-03-11 12:12:44 --> Language Class Initialized
INFO - 2019-03-11 12:12:44 --> Input Class Initialized
INFO - 2019-03-11 12:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:12:44 --> Total execution time: 1.4141
INFO - 2019-03-11 12:12:44 --> Loader Class Initialized
INFO - 2019-03-11 12:12:44 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:44 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:44 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:45 --> Language Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
ERROR - 2019-03-11 12:12:45 --> 404 Page Not Found: Undefined/index
INFO - 2019-03-11 12:12:45 --> Language Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:12:45 --> Email Class Initialized
INFO - 2019-03-11 12:12:45 --> Loader Class Initialized
INFO - 2019-03-11 12:12:45 --> Controller Class Initialized
INFO - 2019-03-11 12:12:45 --> Loader Class Initialized
INFO - 2019-03-11 12:12:45 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:45 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:45 --> Email Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:45 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:45 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:45 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:45 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:45 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:45 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:45 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:45 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:45 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:45 --> Email Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:45 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:45 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:45 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:45 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:46 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:46 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:46 --> Email Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:46 --> Final output sent to browser
INFO - 2019-03-11 12:12:46 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:46 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Total execution time: 2.9752
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:46 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:46 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:46 --> Email Class Initialized
INFO - 2019-03-11 12:12:46 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:46 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:46 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:46 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:46 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:46 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:46 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:46 --> Total execution time: 3.2932
INFO - 2019-03-11 12:12:46 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:46 --> Form Validation Class Initialized
INFO - 2019-03-11 12:12:46 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:46 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:46 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:46 --> Total execution time: 3.4082
INFO - 2019-03-11 12:12:46 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:46 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:12:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:46 --> Total execution time: 3.4982
INFO - 2019-03-11 12:12:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:46 --> Total execution time: 3.5992
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> Config Class Initialized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:49 --> Utf8 Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> Input Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Input Class Initialized
INFO - 2019-03-11 12:12:49 --> URI Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
INFO - 2019-03-11 12:12:49 --> Language Class Initialized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> Language Class Initialized
INFO - 2019-03-11 12:12:49 --> Router Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
INFO - 2019-03-11 12:12:49 --> Output Class Initialized
INFO - 2019-03-11 12:12:49 --> Input Class Initialized
INFO - 2019-03-11 12:12:49 --> Loader Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:49 --> Input Class Initialized
INFO - 2019-03-11 12:12:49 --> Loader Class Initialized
INFO - 2019-03-11 12:12:49 --> Language Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:49 --> Language Class Initialized
INFO - 2019-03-11 12:12:49 --> Controller Class Initialized
INFO - 2019-03-11 12:12:49 --> Controller Class Initialized
INFO - 2019-03-11 12:12:49 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:49 --> Input Class Initialized
INFO - 2019-03-11 12:12:49 --> Language Class Initialized
INFO - 2019-03-11 12:12:50 --> Loader Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:50 --> Input Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:50 --> Loader Class Initialized
INFO - 2019-03-11 12:12:50 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:12:50 --> Loader Class Initialized
INFO - 2019-03-11 12:12:50 --> Controller Class Initialized
INFO - 2019-03-11 12:12:50 --> Language Class Initialized
INFO - 2019-03-11 12:12:50 --> Input Class Initialized
INFO - 2019-03-11 12:12:50 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:12:50 --> Language Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
INFO - 2019-03-11 12:12:50 --> Loader Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:50 --> Controller Class Initialized
ERROR - 2019-03-11 12:12:50 --> 404 Page Not Found: Undefined/index
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:50 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:50 --> Email Class Initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:50 --> Database Driver Class Initialized
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:50 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:50 --> Final output sent to browser
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
INFO - 2019-03-11 12:12:50 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:50 --> Total execution time: 1.1991
INFO - 2019-03-11 12:12:50 --> Final output sent to browser
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:50 --> Helper loaded: download_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:50 --> Total execution time: 1.2171
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:50 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:50 --> Config Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:50 --> Config Class Initialized
INFO - 2019-03-11 12:12:50 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:50 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:50 --> Total execution time: 1.2911
DEBUG - 2019-03-11 12:12:50 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:50 --> Hooks Class Initialized
INFO - 2019-03-11 12:12:50 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:50 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:12:50 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:12:50 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:50 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:50 --> Total execution time: 1.2421
INFO - 2019-03-11 12:12:50 --> URI Class Initialized
INFO - 2019-03-11 12:12:50 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:50 --> Total execution time: 1.4641
INFO - 2019-03-11 12:12:50 --> URI Class Initialized
INFO - 2019-03-11 12:12:50 --> Router Class Initialized
INFO - 2019-03-11 12:12:50 --> Output Class Initialized
INFO - 2019-03-11 12:12:50 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:50 --> Input Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:51 --> Language Class Initialized
INFO - 2019-03-11 12:12:51 --> Router Class Initialized
INFO - 2019-03-11 12:12:51 --> Output Class Initialized
INFO - 2019-03-11 12:12:51 --> Final output sent to browser
INFO - 2019-03-11 12:12:51 --> Security Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Total execution time: 1.4091
DEBUG - 2019-03-11 12:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:12:51 --> Loader Class Initialized
INFO - 2019-03-11 12:12:51 --> Input Class Initialized
INFO - 2019-03-11 12:12:51 --> Language Class Initialized
INFO - 2019-03-11 12:12:51 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:51 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:51 --> Loader Class Initialized
INFO - 2019-03-11 12:12:51 --> Controller Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:12:51 --> Email Class Initialized
INFO - 2019-03-11 12:12:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:12:51 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:12:51 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:12:51 --> Helper loaded: url_helper
INFO - 2019-03-11 12:12:51 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:12:51 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:51 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:51 --> Email Class Initialized
INFO - 2019-03-11 12:12:51 --> Form Validation Class Initialized
INFO - 2019-03-11 12:12:51 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:12:51 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:12:51 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:51 --> Helper loaded: download_helper
INFO - 2019-03-11 12:12:51 --> Helper loaded: form_helper
INFO - 2019-03-11 12:12:51 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:12:51 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:12:51 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:51 --> Total execution time: 0.7560
INFO - 2019-03-11 12:12:51 --> Final output sent to browser
DEBUG - 2019-03-11 12:12:51 --> Total execution time: 0.8216
INFO - 2019-03-11 12:13:04 --> Config Class Initialized
INFO - 2019-03-11 12:13:04 --> Config Class Initialized
INFO - 2019-03-11 12:13:04 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:04 --> Config Class Initialized
INFO - 2019-03-11 12:13:04 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:04 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:04 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:04 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:13:04 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:04 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:04 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:04 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:04 --> URI Class Initialized
INFO - 2019-03-11 12:13:04 --> Router Class Initialized
INFO - 2019-03-11 12:13:04 --> URI Class Initialized
INFO - 2019-03-11 12:13:04 --> URI Class Initialized
INFO - 2019-03-11 12:13:04 --> Router Class Initialized
INFO - 2019-03-11 12:13:04 --> Router Class Initialized
INFO - 2019-03-11 12:13:04 --> Output Class Initialized
INFO - 2019-03-11 12:13:04 --> Output Class Initialized
INFO - 2019-03-11 12:13:04 --> Security Class Initialized
INFO - 2019-03-11 12:13:04 --> Output Class Initialized
DEBUG - 2019-03-11 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:04 --> Security Class Initialized
INFO - 2019-03-11 12:13:04 --> Security Class Initialized
INFO - 2019-03-11 12:13:04 --> Input Class Initialized
DEBUG - 2019-03-11 12:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:04 --> Input Class Initialized
INFO - 2019-03-11 12:13:04 --> Input Class Initialized
INFO - 2019-03-11 12:13:04 --> Language Class Initialized
INFO - 2019-03-11 12:13:04 --> Language Class Initialized
INFO - 2019-03-11 12:13:04 --> Language Class Initialized
INFO - 2019-03-11 12:13:04 --> Loader Class Initialized
INFO - 2019-03-11 12:13:04 --> Loader Class Initialized
INFO - 2019-03-11 12:13:04 --> Controller Class Initialized
INFO - 2019-03-11 12:13:04 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:04 --> Controller Class Initialized
INFO - 2019-03-11 12:13:04 --> Controller Class Initialized
INFO - 2019-03-11 12:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:04 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:04 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:04 --> Email Class Initialized
INFO - 2019-03-11 12:13:04 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:04 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:13:04 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:04 --> Email Class Initialized
INFO - 2019-03-11 12:13:04 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:04 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:04 --> Email Class Initialized
INFO - 2019-03-11 12:13:04 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:04 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:04 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:05 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:05 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:05 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:05 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:05 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:13:05 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:05 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:05 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:05 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:05 --> Final output sent to browser
INFO - 2019-03-11 12:13:05 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:05 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:05 --> Total execution time: 0.8260
INFO - 2019-03-11 12:13:05 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:05 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:05 --> Total execution time: 0.8771
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:05 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:05 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:05 --> Total execution time: 1.0001
INFO - 2019-03-11 12:13:19 --> Config Class Initialized
INFO - 2019-03-11 12:13:19 --> Config Class Initialized
INFO - 2019-03-11 12:13:19 --> Config Class Initialized
INFO - 2019-03-11 12:13:19 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:19 --> Config Class Initialized
INFO - 2019-03-11 12:13:19 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:19 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:19 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:19 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:19 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:19 --> Utf8 Class Initialized
DEBUG - 2019-03-11 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:19 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:19 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:19 --> URI Class Initialized
INFO - 2019-03-11 12:13:19 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:19 --> URI Class Initialized
INFO - 2019-03-11 12:13:19 --> URI Class Initialized
INFO - 2019-03-11 12:13:19 --> Router Class Initialized
INFO - 2019-03-11 12:13:19 --> URI Class Initialized
INFO - 2019-03-11 12:13:19 --> Router Class Initialized
INFO - 2019-03-11 12:13:19 --> Router Class Initialized
INFO - 2019-03-11 12:13:19 --> Router Class Initialized
INFO - 2019-03-11 12:13:19 --> Output Class Initialized
INFO - 2019-03-11 12:13:19 --> Output Class Initialized
INFO - 2019-03-11 12:13:20 --> Security Class Initialized
INFO - 2019-03-11 12:13:20 --> Output Class Initialized
INFO - 2019-03-11 12:13:20 --> Security Class Initialized
INFO - 2019-03-11 12:13:20 --> Output Class Initialized
INFO - 2019-03-11 12:13:20 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:20 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:20 --> Input Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:20 --> Input Class Initialized
INFO - 2019-03-11 12:13:20 --> Language Class Initialized
INFO - 2019-03-11 12:13:20 --> Input Class Initialized
INFO - 2019-03-11 12:13:20 --> Language Class Initialized
INFO - 2019-03-11 12:13:20 --> Input Class Initialized
INFO - 2019-03-11 12:13:20 --> Language Class Initialized
INFO - 2019-03-11 12:13:20 --> Loader Class Initialized
INFO - 2019-03-11 12:13:20 --> Language Class Initialized
INFO - 2019-03-11 12:13:20 --> Controller Class Initialized
INFO - 2019-03-11 12:13:20 --> Loader Class Initialized
INFO - 2019-03-11 12:13:20 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:20 --> Controller Class Initialized
INFO - 2019-03-11 12:13:20 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:20 --> Controller Class Initialized
INFO - 2019-03-11 12:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:13:20 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:20 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:20 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:20 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:20 --> Email Class Initialized
INFO - 2019-03-11 12:13:20 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:20 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:20 --> Email Class Initialized
INFO - 2019-03-11 12:13:20 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:20 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:20 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:20 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:20 --> Email Class Initialized
INFO - 2019-03-11 12:13:20 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:20 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:20 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:20 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:20 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:20 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:20 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:20 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:20 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:20 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:20 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:20 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: download_helper
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:20 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:13:20 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:20 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:20 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:20 --> Total execution time: 0.9481
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:20 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:13:20 --> Total execution time: 0.8860
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:20 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:20 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:20 --> Total execution time: 0.9841
INFO - 2019-03-11 12:13:20 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:20 --> Total execution time: 1.0201
INFO - 2019-03-11 12:13:24 --> Config Class Initialized
INFO - 2019-03-11 12:13:24 --> Config Class Initialized
INFO - 2019-03-11 12:13:24 --> Config Class Initialized
INFO - 2019-03-11 12:13:24 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:24 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:24 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:24 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:24 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:24 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:24 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:24 --> URI Class Initialized
INFO - 2019-03-11 12:13:24 --> URI Class Initialized
INFO - 2019-03-11 12:13:24 --> Router Class Initialized
INFO - 2019-03-11 12:13:25 --> Router Class Initialized
INFO - 2019-03-11 12:13:25 --> URI Class Initialized
INFO - 2019-03-11 12:13:25 --> Output Class Initialized
INFO - 2019-03-11 12:13:25 --> Output Class Initialized
INFO - 2019-03-11 12:13:25 --> Router Class Initialized
INFO - 2019-03-11 12:13:25 --> Security Class Initialized
INFO - 2019-03-11 12:13:25 --> Output Class Initialized
INFO - 2019-03-11 12:13:25 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:25 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:25 --> Input Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:25 --> Input Class Initialized
INFO - 2019-03-11 12:13:25 --> Language Class Initialized
INFO - 2019-03-11 12:13:25 --> Input Class Initialized
INFO - 2019-03-11 12:13:25 --> Language Class Initialized
INFO - 2019-03-11 12:13:25 --> Language Class Initialized
INFO - 2019-03-11 12:13:25 --> Loader Class Initialized
INFO - 2019-03-11 12:13:25 --> Loader Class Initialized
INFO - 2019-03-11 12:13:25 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:13:25 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:25 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:25 --> Controller Class Initialized
INFO - 2019-03-11 12:13:25 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:13:25 --> Email Class Initialized
INFO - 2019-03-11 12:13:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:25 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:25 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:25 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:25 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:25 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:25 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:25 --> Final output sent to browser
INFO - 2019-03-11 12:13:25 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Total execution time: 0.7560
INFO - 2019-03-11 12:13:25 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:25 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:25 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:25 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:25 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:13:25 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:25 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:25 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:25 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:25 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:25 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:25 --> Total execution time: 1.0021
INFO - 2019-03-11 12:13:25 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:25 --> Total execution time: 1.0273
INFO - 2019-03-11 12:13:27 --> Config Class Initialized
INFO - 2019-03-11 12:13:27 --> Config Class Initialized
INFO - 2019-03-11 12:13:27 --> Config Class Initialized
INFO - 2019-03-11 12:13:27 --> Config Class Initialized
INFO - 2019-03-11 12:13:27 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:27 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:27 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:27 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:27 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:27 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:27 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:27 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:27 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:27 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:27 --> URI Class Initialized
INFO - 2019-03-11 12:13:27 --> URI Class Initialized
INFO - 2019-03-11 12:13:27 --> URI Class Initialized
INFO - 2019-03-11 12:13:27 --> URI Class Initialized
INFO - 2019-03-11 12:13:27 --> Router Class Initialized
INFO - 2019-03-11 12:13:27 --> Router Class Initialized
INFO - 2019-03-11 12:13:27 --> Router Class Initialized
INFO - 2019-03-11 12:13:27 --> Router Class Initialized
INFO - 2019-03-11 12:13:27 --> Output Class Initialized
INFO - 2019-03-11 12:13:27 --> Output Class Initialized
INFO - 2019-03-11 12:13:27 --> Output Class Initialized
INFO - 2019-03-11 12:13:27 --> Output Class Initialized
INFO - 2019-03-11 12:13:27 --> Security Class Initialized
INFO - 2019-03-11 12:13:27 --> Security Class Initialized
INFO - 2019-03-11 12:13:27 --> Security Class Initialized
INFO - 2019-03-11 12:13:27 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:27 --> Input Class Initialized
INFO - 2019-03-11 12:13:27 --> Input Class Initialized
INFO - 2019-03-11 12:13:27 --> Input Class Initialized
INFO - 2019-03-11 12:13:27 --> Input Class Initialized
INFO - 2019-03-11 12:13:27 --> Language Class Initialized
INFO - 2019-03-11 12:13:27 --> Language Class Initialized
INFO - 2019-03-11 12:13:27 --> Language Class Initialized
INFO - 2019-03-11 12:13:28 --> Language Class Initialized
INFO - 2019-03-11 12:13:28 --> Loader Class Initialized
INFO - 2019-03-11 12:13:28 --> Loader Class Initialized
INFO - 2019-03-11 12:13:28 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:13:28 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:28 --> Controller Class Initialized
INFO - 2019-03-11 12:13:28 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:28 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:28 --> Helper loaded: url_helper
INFO - 2019-03-11 12:13:28 --> Loader Class Initialized
INFO - 2019-03-11 12:13:28 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:28 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:28 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-03-11 12:13:28 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:28 --> Database Driver Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:28 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:28 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:28 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:28 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:28 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:28 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:28 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:28 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:28 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:28 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:28 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:28 --> Email Class Initialized
INFO - 2019-03-11 12:13:28 --> Helper loaded: form_helper
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:28 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:28 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
INFO - 2019-03-11 12:13:28 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:28 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:28 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:28 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
INFO - 2019-03-11 12:13:28 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:28 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:28 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:28 --> Helper loaded: file_helper
DEBUG - 2019-03-11 12:13:28 --> Total execution time: 0.8300
INFO - 2019-03-11 12:13:28 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:28 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:28 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:28 --> Final output sent to browser
INFO - 2019-03-11 12:13:28 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:28 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:28 --> Total execution time: 0.8740
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:28 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:28 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:28 --> Total execution time: 0.9981
INFO - 2019-03-11 12:13:28 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:28 --> Total execution time: 1.0101
INFO - 2019-03-11 12:13:38 --> Config Class Initialized
INFO - 2019-03-11 12:13:38 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:38 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:38 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:38 --> URI Class Initialized
INFO - 2019-03-11 12:13:38 --> Router Class Initialized
INFO - 2019-03-11 12:13:38 --> Output Class Initialized
INFO - 2019-03-11 12:13:38 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:38 --> Input Class Initialized
INFO - 2019-03-11 12:13:38 --> Language Class Initialized
INFO - 2019-03-11 12:13:38 --> Loader Class Initialized
INFO - 2019-03-11 12:13:38 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:38 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:38 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:38 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:38 --> Email Class Initialized
INFO - 2019-03-11 12:13:38 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:39 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:39 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:39 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:39 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:39 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:39 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:39 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:39 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:39 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:39 --> Total execution time: 1.1971
INFO - 2019-03-11 12:13:44 --> Config Class Initialized
INFO - 2019-03-11 12:13:44 --> Config Class Initialized
INFO - 2019-03-11 12:13:44 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:44 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:44 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:44 --> URI Class Initialized
INFO - 2019-03-11 12:13:44 --> Router Class Initialized
INFO - 2019-03-11 12:13:44 --> Output Class Initialized
INFO - 2019-03-11 12:13:44 --> Config Class Initialized
INFO - 2019-03-11 12:13:44 --> Config Class Initialized
INFO - 2019-03-11 12:13:44 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:44 --> Input Class Initialized
INFO - 2019-03-11 12:13:44 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:44 --> Language Class Initialized
INFO - 2019-03-11 12:13:44 --> Hooks Class Initialized
INFO - 2019-03-11 12:13:44 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2019-03-11 12:13:44 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:44 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:44 --> URI Class Initialized
INFO - 2019-03-11 12:13:44 --> Router Class Initialized
INFO - 2019-03-11 12:13:44 --> Output Class Initialized
INFO - 2019-03-11 12:13:44 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:44 --> Loader Class Initialized
INFO - 2019-03-11 12:13:44 --> Input Class Initialized
INFO - 2019-03-11 12:13:44 --> Language Class Initialized
INFO - 2019-03-11 12:13:44 --> Controller Class Initialized
INFO - 2019-03-11 12:13:44 --> Loader Class Initialized
DEBUG - 2019-03-11 12:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:44 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:44 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:44 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:45 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:45 --> Controller Class Initialized
INFO - 2019-03-11 12:13:45 --> Email Class Initialized
DEBUG - 2019-03-11 12:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:45 --> URI Class Initialized
INFO - 2019-03-11 12:13:45 --> URI Class Initialized
INFO - 2019-03-11 12:13:45 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:45 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:45 --> Router Class Initialized
INFO - 2019-03-11 12:13:45 --> Email Class Initialized
INFO - 2019-03-11 12:13:45 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:45 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:45 --> Output Class Initialized
INFO - 2019-03-11 12:13:45 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:45 --> Router Class Initialized
INFO - 2019-03-11 12:13:45 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:45 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:45 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:45 --> Final output sent to browser
INFO - 2019-03-11 12:13:45 --> Output Class Initialized
INFO - 2019-03-11 12:13:45 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:45 --> Total execution time: 1.2681
INFO - 2019-03-11 12:13:45 --> Security Class Initialized
INFO - 2019-03-11 12:13:45 --> Model "Assetsapi_model" initialized
DEBUG - 2019-03-11 12:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-03-11 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:45 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:45 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:45 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:45 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:45 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:45 --> Final output sent to browser
INFO - 2019-03-11 12:13:45 --> Input Class Initialized
INFO - 2019-03-11 12:13:45 --> Input Class Initialized
DEBUG - 2019-03-11 12:13:45 --> Total execution time: 1.3101
INFO - 2019-03-11 12:13:45 --> Language Class Initialized
INFO - 2019-03-11 12:13:45 --> Language Class Initialized
INFO - 2019-03-11 12:13:46 --> Loader Class Initialized
INFO - 2019-03-11 12:13:46 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:46 --> Loader Class Initialized
INFO - 2019-03-11 12:13:46 --> Controller Class Initialized
INFO - 2019-03-11 12:13:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
INFO - 2019-03-11 12:13:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:46 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
DEBUG - 2019-03-11 12:13:46 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:46 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:46 --> Email Class Initialized
INFO - 2019-03-11 12:13:46 --> Email Class Initialized
INFO - 2019-03-11 12:13:46 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:46 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:46 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:46 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:46 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:46 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:46 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:46 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:46 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:46 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:46 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:46 --> Form Validation Class Initialized
INFO - 2019-03-11 12:13:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:46 --> Total execution time: 2.5601
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:46 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:46 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:46 --> Total execution time: 2.4761
INFO - 2019-03-11 12:13:56 --> Config Class Initialized
INFO - 2019-03-11 12:13:56 --> Hooks Class Initialized
DEBUG - 2019-03-11 12:13:56 --> UTF-8 Support Enabled
INFO - 2019-03-11 12:13:56 --> Utf8 Class Initialized
INFO - 2019-03-11 12:13:56 --> URI Class Initialized
INFO - 2019-03-11 12:13:56 --> Router Class Initialized
INFO - 2019-03-11 12:13:56 --> Output Class Initialized
INFO - 2019-03-11 12:13:56 --> Security Class Initialized
DEBUG - 2019-03-11 12:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-03-11 12:13:57 --> Input Class Initialized
INFO - 2019-03-11 12:13:57 --> Language Class Initialized
INFO - 2019-03-11 12:13:57 --> Loader Class Initialized
INFO - 2019-03-11 12:13:57 --> Controller Class Initialized
DEBUG - 2019-03-11 12:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-03-11 12:13:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-03-11 12:13:57 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/facebook.php
DEBUG - 2019-03-11 12:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2019-03-11 12:13:57 --> Helper loaded: url_helper
DEBUG - 2019-03-11 12:13:57 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/google.php
INFO - 2019-03-11 12:13:57 --> Email Class Initialized
INFO - 2019-03-11 12:13:57 --> Database Driver Class Initialized
INFO - 2019-03-11 12:13:57 --> Model "Assetsapi_model" initialized
INFO - 2019-03-11 12:13:57 --> Helper loaded: file_helper
INFO - 2019-03-11 12:13:57 --> Helper loaded: download_helper
INFO - 2019-03-11 12:13:57 --> Helper loaded: form_helper
INFO - 2019-03-11 12:13:57 --> Form Validation Class Initialized
DEBUG - 2019-03-11 12:13:57 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/linkedin.php
DEBUG - 2019-03-11 12:13:57 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/twitter.php
DEBUG - 2019-03-11 12:13:57 --> Config file loaded: D:\xampp\htdocs\assetsapi\application\config/singular_payment.php
INFO - 2019-03-11 12:13:57 --> Final output sent to browser
DEBUG - 2019-03-11 12:13:57 --> Total execution time: 0.6250
